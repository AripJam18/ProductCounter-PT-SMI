Imports System.Data.Odbc
Public Class FormLogin

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Login()
    End Sub
    Private Sub Login()
        If UserIDTextBox.TextLength = 0 Or PasswordTextBox.TextLength = 0 Then
            MsgBox("Username dan Password harus diisi!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Try
            ConnectMySQL()

            CMD = New OdbcCommand("SELECT namauser FROM user WHERE iduser='" & UserIDTextBox.Text & "' AND password='" & PasswordTextBox.Text & "' ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("username dan password salah!! ",
                       MsgBoxStyle.Exclamation, "Error Login")
                UserIDTextBox.Clear()
                PasswordTextBox.Clear()
            Else
                iduser = UserIDTextBox.Text
                namauser = DR.Item(0).ToString
                'MsgBox("Login berhasil, Selamat datang " & DR.Item(0).ToString & "!", MsgBoxStyle.Information, "Successfull Login")
                FormMain.Show()
                Me.Hide()
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error Login")
        End Try

    End Sub

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles Me.Load
        GetSettinganAwal()
    End Sub

    Private Sub FormLogin_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        End
    End Sub
End Class

''cara buat user di MYSQL:
'1. CREATE USER 'admin'@'localhost' IDENTIFIED BY '@dminIT2023';
'2. GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' WITH GRANT OPTION;
'3. CREATE USER 'admin'@'%' IDENTIFIED BY '@dminIT2023';
'4. GRANT ALL PRIVILEGES ON *.* TO 'admin'@'%' WITH GRANT OPTION;
'5. FLUSH PRIVILEGES;
