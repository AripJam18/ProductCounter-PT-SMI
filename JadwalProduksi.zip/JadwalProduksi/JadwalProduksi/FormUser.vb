﻿Imports System.Data.Odbc
Public Class FormUser
    Dim statusdata As String
    Private Sub FormModel_Load(sender As Object, e As EventArgs) Handles Me.Load
        LoadDataAll()
        EnabledTextBox(False)
    End Sub


#Region "Function"
    Private Sub LoadDataAll()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT * FROM user", CONN)
            DS = New DataSet
            DA.Fill(DS, "user")
            Dim dt As DataTable = DS.Tables("user")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data user ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVUser.Columns.Clear()
                DGVUser.DataSource = Nothing
            Else
                DGVUser.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error LoadDataAll")
        End Try
    End Sub
    Private Sub Finduser()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT * FROM user WHERE namauser='" & TxtFind.Text & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "finduser")
            Dim dt As DataTable = DS.Tables("finduser")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data user ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVUser.Columns.Clear()
                DGVUser.DataSource = Nothing
            Else
                DGVUser.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error finduser")
        End Try
    End Sub
    Public Sub CekDataSebelumSimpan()
        Try
            ConnectMySQL()

            CMD = New OdbcCommand("SELECT * FROM user WHERE iduser='" & TxtIDUser.Text & "' ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                ''data baru boleh diinsert
                InsertDataUser()
            Else
                ''data sudah ada jadi diupdate saja
                UpdateDataUser()
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error CekDataSebelumSimpan()")
        End Try
    End Sub

    Private Sub InsertDataUser()
        Try
            ConnectMySQL()

            Dim simpan As String = "INSERT INTO user (iduser,namauser,password,bagian,level) VALUES ('" & TxtIDUser.Text & "','" & TxtNamaUser.Text & "','" & TxtPassword.Text & "','" & TxtBagian.Text & "','" & CmbLevel.Text & "')"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil disimpan", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataUser()")
        End Try
    End Sub

    Private Sub UpdateDataUser()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE user SET iduser='" & TxtIDUser.Text & "', namauser='" & TxtNamaUser.Text & "' ,  password='" & TxtPassword.Text & "', bagian='" & TxtBagian.Text & "' ,  level='" & CmbLevel.Text & "' WHERE id=" & TxtIDData.Text & ""
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateDataUser()")
        End Try
    End Sub
    Private Sub DeleteUser()
        Try
            Dim result As DialogResult = MessageBox.Show("Confirm Delete?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

            If (result = DialogResult.Yes) Then
                ConnectMySQL()

                Dim hapus As String = "DELETE FROM user WHERE id='" & TxtIDData.Text & "'"
                CMD = New OdbcCommand(hapus, CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Data berhasil dihapus", vbInformation, "Informasi")
                LoadDataAll()
                KosongkanTextbox()
                KondisiDelete()
            Else
                'Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error DeleteUser()")
        End Try
    End Sub

#End Region

#Region "Kondisi TextBox"
    Private Sub KosongkanTextbox()
        TxtBagian.Clear()
        CmbLevel.Text = ""
        TxtNamaUser.Clear()
        TxtIDUser.Clear()
        TxtPassword.Clear()
        TxtIDUser.Clear()
    End Sub
    Private Sub EnabledTextBox(ByVal tf As Boolean)
        TxtBagian.Enabled = tf
        CmbLevel.Enabled = tf
        TxtNamaUser.Enabled = tf
        TxtIDUser.Enabled = tf
        TxtPassword.Enabled = tf
    End Sub
    Private Sub KondisiAdd()
        KosongkanTextbox()
        EnabledTextBox(True)
        BtnAdd.Enabled = False
        BtnSave.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiSave()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiEdit()
        EnabledTextBox(True)
        BtnSave.Enabled = True
        BtnAdd.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
        BtnEdit.Enabled = False
    End Sub
    Private Sub KondisiCancel()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiDelete()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
#End Region
    Private Sub DGVUser_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVUser.CellContentClick
        If DGVUser.ColumnCount = 6 Then
            TxtNamaUser.Text = DGVUser.Rows(e.RowIndex).Cells.Item("namauser").Value
            TxtIDUser.Text = DGVUser.Rows(e.RowIndex).Cells.Item("iduser").Value
            TxtPassword.Text = DGVUser.Rows(e.RowIndex).Cells.Item("password").Value
            TxtBagian.Text = DGVUser.Rows(e.RowIndex).Cells.Item("bagian").Value
            CmbLevel.Text = DGVUser.Rows(e.RowIndex).Cells.Item("level").Value
            TxtIDData.Text = DGVUser.Rows(e.RowIndex).Cells.Item("id").Value
            BtnEdit.Enabled = True
            BtnDelete.Enabled = True
            statusdata = "edit"
        Else
            Exit Sub
        End If
    End Sub


#Region "Button Action"
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        statusdata = "add"
        KondisiAdd()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        DeleteUser()
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        statusdata = "edit"
        KondisiEdit()
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        KondisiCancel()
    End Sub

    Private Sub BtnShowAll_Click(sender As Object, e As EventArgs) Handles BtnShowAll.Click
        LoadDataAll()
    End Sub

    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If TxtFind.TextLength = 0 Then
            Exit Sub
        End If
        Finduser()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If statusdata = "edit" Then
            UpdateDataUser()
        Else
            CekDataSebelumSimpan()
        End If
        KondisiSave()
    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub FormLine_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
        Me.Hide()
    End Sub

#End Region

End Class