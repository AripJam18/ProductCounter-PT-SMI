﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormDisplay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormDisplay))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.LblAktual = New System.Windows.Forms.Label()
        Me.LblJudulAktual = New System.Windows.Forms.Label()
        Me.LblTarget = New System.Windows.Forms.Label()
        Me.LblJudulTarget = New System.Windows.Forms.Label()
        Me.LblModel = New System.Windows.Forms.Label()
        Me.LblJudulModel = New System.Windows.Forms.Label()
        Me.LblTime = New System.Windows.Forms.Label()
        Me.LblDate = New System.Windows.Forms.Label()
        Me.LblDay = New System.Windows.Forms.Label()
        Me.PanelEfisensi = New System.Windows.Forms.Panel()
        Me.PanelNotifikasi = New System.Windows.Forms.Panel()
        Me.LblIsiNotifikasi = New System.Windows.Forms.Label()
        Me.PanelHeaderNotifikasi = New System.Windows.Forms.Panel()
        Me.LblJudulNotifikasi = New System.Windows.Forms.Label()
        Me.BtnTambahAktual = New System.Windows.Forms.Button()
        Me.PanelPenutupRichTextBox = New System.Windows.Forms.Panel()
        Me.TxtRichTemp = New System.Windows.Forms.RichTextBox()
        Me.RichTextBoxArduino = New System.Windows.Forms.RichTextBox()
        Me.BtnGantiJam = New System.Windows.Forms.Button()
        Me.LblEfisiensi = New System.Windows.Forms.Label()
        Me.LblJudulEfiseinsi = New System.Windows.Forms.Label()
        Me.PanelRunningText = New System.Windows.Forms.Panel()
        Me.LblRunningText = New System.Windows.Forms.Label()
        Me.PanelSetting = New System.Windows.Forms.Panel()
        Me.BtnTambahManual = New System.Windows.Forms.Button()
        Me.BtnContinue = New System.Windows.Forms.Button()
        Me.BtnPause = New System.Windows.Forms.Button()
        Me.TxtBerat = New System.Windows.Forms.TextBox()
        Me.TxtPerintah = New System.Windows.Forms.TextBox()
        Me.BtnSetting = New System.Windows.Forms.Button()
        Me.BtnConnectTimbangan = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.BtnStop = New System.Windows.Forms.Button()
        Me.LblDelayDetik = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtTampung2 = New System.Windows.Forms.TextBox()
        Me.TxtTampung1 = New System.Windows.Forms.TextBox()
        Me.TimerWaktu = New System.Windows.Forms.Timer(Me.components)
        Me.TimerAktual = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPortTimbangan = New System.IO.Ports.SerialPort(Me.components)
        Me.BackgroundWorkerTimbangan = New System.ComponentModel.BackgroundWorker()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.TimerRunningText = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPortArduino = New System.IO.Ports.SerialPort(Me.components)
        Me.BackgroundWorkerArduino = New System.ComponentModel.BackgroundWorker()
        Me.TimerMsgBox = New System.Windows.Forms.Timer(Me.components)
        Me.TimerTambahAktualDariButton = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRealtimeRunningText = New System.Windows.Forms.Timer(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.PanelEfisensi.SuspendLayout()
        Me.PanelNotifikasi.SuspendLayout()
        Me.PanelHeaderNotifikasi.SuspendLayout()
        Me.PanelRunningText.SuspendLayout()
        Me.PanelSetting.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.Controls.Add(Me.LblAktual, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LblJudulAktual, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LblTarget, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LblJudulTarget, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LblModel, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblJudulModel, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblTime, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LblDate, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LblDay, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.PanelEfisensi, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.PanelRunningText, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.PanelSetting, 2, 3)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1370, 746)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'LblAktual
        '
        Me.LblAktual.AutoSize = True
        Me.LblAktual.BackColor = System.Drawing.Color.Transparent
        Me.LblAktual.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblAktual.Font = New System.Drawing.Font("Arial Black", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAktual.ForeColor = System.Drawing.Color.Red
        Me.LblAktual.Location = New System.Drawing.Point(460, 448)
        Me.LblAktual.Name = "LblAktual"
        Me.LblAktual.Size = New System.Drawing.Size(449, 148)
        Me.LblAktual.TabIndex = 10
        Me.LblAktual.Text = "0"
        Me.LblAktual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblJudulAktual
        '
        Me.LblJudulAktual.AutoSize = True
        Me.LblJudulAktual.BackColor = System.Drawing.Color.Transparent
        Me.LblJudulAktual.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblJudulAktual.Font = New System.Drawing.Font("Segoe UI Semibold", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudulAktual.Location = New System.Drawing.Point(4, 448)
        Me.LblJudulAktual.Name = "LblJudulAktual"
        Me.LblJudulAktual.Size = New System.Drawing.Size(449, 148)
        Me.LblJudulAktual.TabIndex = 9
        Me.LblJudulAktual.Text = "AKTUAL"
        Me.LblJudulAktual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTarget
        '
        Me.LblTarget.AutoSize = True
        Me.LblTarget.BackColor = System.Drawing.Color.Transparent
        Me.LblTarget.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblTarget.Font = New System.Drawing.Font("Arial Black", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTarget.ForeColor = System.Drawing.Color.Red
        Me.LblTarget.Location = New System.Drawing.Point(460, 299)
        Me.LblTarget.Name = "LblTarget"
        Me.LblTarget.Size = New System.Drawing.Size(449, 148)
        Me.LblTarget.TabIndex = 7
        Me.LblTarget.Text = "1000"
        Me.LblTarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblJudulTarget
        '
        Me.LblJudulTarget.AutoSize = True
        Me.LblJudulTarget.BackColor = System.Drawing.Color.Transparent
        Me.LblJudulTarget.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblJudulTarget.Font = New System.Drawing.Font("Segoe UI Semibold", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudulTarget.Location = New System.Drawing.Point(4, 299)
        Me.LblJudulTarget.Name = "LblJudulTarget"
        Me.LblJudulTarget.Size = New System.Drawing.Size(449, 148)
        Me.LblJudulTarget.TabIndex = 6
        Me.LblJudulTarget.Text = "TARGET"
        Me.LblJudulTarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblModel
        '
        Me.LblModel.AutoSize = True
        Me.LblModel.BackColor = System.Drawing.Color.Transparent
        Me.LblModel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblModel.Font = New System.Drawing.Font("Arial Black", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblModel.ForeColor = System.Drawing.Color.Red
        Me.LblModel.Location = New System.Drawing.Point(460, 150)
        Me.LblModel.Name = "LblModel"
        Me.LblModel.Size = New System.Drawing.Size(449, 148)
        Me.LblModel.TabIndex = 4
        Me.LblModel.Text = "DA55L"
        Me.LblModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblJudulModel
        '
        Me.LblJudulModel.AutoSize = True
        Me.LblJudulModel.BackColor = System.Drawing.Color.Transparent
        Me.LblJudulModel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblJudulModel.Font = New System.Drawing.Font("Segoe UI Semibold", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudulModel.Location = New System.Drawing.Point(4, 150)
        Me.LblJudulModel.Name = "LblJudulModel"
        Me.LblJudulModel.Size = New System.Drawing.Size(449, 148)
        Me.LblJudulModel.TabIndex = 3
        Me.LblJudulModel.Text = "MODEL"
        Me.LblJudulModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTime
        '
        Me.LblTime.AutoSize = True
        Me.LblTime.BackColor = System.Drawing.Color.Transparent
        Me.LblTime.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblTime.Font = New System.Drawing.Font("Segoe UI Semibold", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTime.ForeColor = System.Drawing.Color.ForestGreen
        Me.LblTime.Location = New System.Drawing.Point(916, 1)
        Me.LblTime.Name = "LblTime"
        Me.LblTime.Size = New System.Drawing.Size(450, 148)
        Me.LblTime.TabIndex = 2
        Me.LblTime.Text = "13:50:31"
        Me.LblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblDate
        '
        Me.LblDate.AutoSize = True
        Me.LblDate.BackColor = System.Drawing.Color.Transparent
        Me.LblDate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 60.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDate.ForeColor = System.Drawing.Color.Blue
        Me.LblDate.Location = New System.Drawing.Point(460, 1)
        Me.LblDate.Name = "LblDate"
        Me.LblDate.Size = New System.Drawing.Size(449, 148)
        Me.LblDate.TabIndex = 1
        Me.LblDate.Text = "29-05-2023"
        Me.LblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblDay
        '
        Me.LblDay.AutoSize = True
        Me.LblDay.BackColor = System.Drawing.Color.Transparent
        Me.LblDay.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblDay.Font = New System.Drawing.Font("Segoe UI Semibold", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDay.ForeColor = System.Drawing.Color.Blue
        Me.LblDay.Location = New System.Drawing.Point(4, 1)
        Me.LblDay.Name = "LblDay"
        Me.LblDay.Size = New System.Drawing.Size(449, 148)
        Me.LblDay.TabIndex = 0
        Me.LblDay.Text = "SENIN"
        Me.LblDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelEfisensi
        '
        Me.PanelEfisensi.BackColor = System.Drawing.SystemColors.Control
        Me.PanelEfisensi.Controls.Add(Me.PanelNotifikasi)
        Me.PanelEfisensi.Controls.Add(Me.BtnTambahAktual)
        Me.PanelEfisensi.Controls.Add(Me.PanelPenutupRichTextBox)
        Me.PanelEfisensi.Controls.Add(Me.TxtRichTemp)
        Me.PanelEfisensi.Controls.Add(Me.RichTextBoxArduino)
        Me.PanelEfisensi.Controls.Add(Me.BtnGantiJam)
        Me.PanelEfisensi.Controls.Add(Me.LblEfisiensi)
        Me.PanelEfisensi.Controls.Add(Me.LblJudulEfiseinsi)
        Me.PanelEfisensi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelEfisensi.Location = New System.Drawing.Point(916, 153)
        Me.PanelEfisensi.Name = "PanelEfisensi"
        Me.TableLayoutPanel1.SetRowSpan(Me.PanelEfisensi, 2)
        Me.PanelEfisensi.Size = New System.Drawing.Size(450, 291)
        Me.PanelEfisensi.TabIndex = 11
        '
        'PanelNotifikasi
        '
        Me.PanelNotifikasi.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PanelNotifikasi.BackColor = System.Drawing.Color.White
        Me.PanelNotifikasi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelNotifikasi.Controls.Add(Me.LblIsiNotifikasi)
        Me.PanelNotifikasi.Controls.Add(Me.PanelHeaderNotifikasi)
        Me.PanelNotifikasi.Location = New System.Drawing.Point(103, 95)
        Me.PanelNotifikasi.Name = "PanelNotifikasi"
        Me.PanelNotifikasi.Size = New System.Drawing.Size(249, 124)
        Me.PanelNotifikasi.TabIndex = 36
        Me.PanelNotifikasi.Visible = False
        '
        'LblIsiNotifikasi
        '
        Me.LblIsiNotifikasi.AutoSize = True
        Me.LblIsiNotifikasi.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIsiNotifikasi.Location = New System.Drawing.Point(31, 58)
        Me.LblIsiNotifikasi.Name = "LblIsiNotifikasi"
        Me.LblIsiNotifikasi.Size = New System.Drawing.Size(191, 21)
        Me.LblIsiNotifikasi.TabIndex = 1
        Me.LblIsiNotifikasi.Text = "Data berhasil disimpan!"
        '
        'PanelHeaderNotifikasi
        '
        Me.PanelHeaderNotifikasi.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.PanelHeaderNotifikasi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelHeaderNotifikasi.Controls.Add(Me.LblJudulNotifikasi)
        Me.PanelHeaderNotifikasi.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelHeaderNotifikasi.Location = New System.Drawing.Point(0, 0)
        Me.PanelHeaderNotifikasi.Name = "PanelHeaderNotifikasi"
        Me.PanelHeaderNotifikasi.Size = New System.Drawing.Size(247, 29)
        Me.PanelHeaderNotifikasi.TabIndex = 0
        '
        'LblJudulNotifikasi
        '
        Me.LblJudulNotifikasi.AutoSize = True
        Me.LblJudulNotifikasi.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudulNotifikasi.ForeColor = System.Drawing.Color.Firebrick
        Me.LblJudulNotifikasi.Location = New System.Drawing.Point(69, -2)
        Me.LblJudulNotifikasi.Name = "LblJudulNotifikasi"
        Me.LblJudulNotifikasi.Size = New System.Drawing.Size(112, 30)
        Me.LblJudulNotifikasi.TabIndex = 0
        Me.LblJudulNotifikasi.Text = "Informasi"
        '
        'BtnTambahAktual
        '
        Me.BtnTambahAktual.BackColor = System.Drawing.Color.Violet
        Me.BtnTambahAktual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnTambahAktual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnTambahAktual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTambahAktual.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTambahAktual.ForeColor = System.Drawing.Color.White
        Me.BtnTambahAktual.Location = New System.Drawing.Point(401, 40)
        Me.BtnTambahAktual.Name = "BtnTambahAktual"
        Me.BtnTambahAktual.Size = New System.Drawing.Size(47, 31)
        Me.BtnTambahAktual.TabIndex = 39
        Me.BtnTambahAktual.Text = "+"
        Me.BtnTambahAktual.UseVisualStyleBackColor = False
        Me.BtnTambahAktual.Visible = False
        '
        'PanelPenutupRichTextBox
        '
        Me.PanelPenutupRichTextBox.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelPenutupRichTextBox.Location = New System.Drawing.Point(0, 180)
        Me.PanelPenutupRichTextBox.Name = "PanelPenutupRichTextBox"
        Me.PanelPenutupRichTextBox.Size = New System.Drawing.Size(450, 45)
        Me.PanelPenutupRichTextBox.TabIndex = 38
        Me.PanelPenutupRichTextBox.Visible = False
        '
        'TxtRichTemp
        '
        Me.TxtRichTemp.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TxtRichTemp.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtRichTemp.Location = New System.Drawing.Point(0, 225)
        Me.TxtRichTemp.Name = "TxtRichTemp"
        Me.TxtRichTemp.Size = New System.Drawing.Size(450, 66)
        Me.TxtRichTemp.TabIndex = 35
        Me.TxtRichTemp.Text = ""
        '
        'RichTextBoxArduino
        '
        Me.RichTextBoxArduino.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RichTextBoxArduino.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBoxArduino.Location = New System.Drawing.Point(346, 267)
        Me.RichTextBoxArduino.MaxLength = 1
        Me.RichTextBoxArduino.Name = "RichTextBoxArduino"
        Me.RichTextBoxArduino.Size = New System.Drawing.Size(81, 21)
        Me.RichTextBoxArduino.TabIndex = 36
        Me.RichTextBoxArduino.Text = ""
        '
        'BtnGantiJam
        '
        Me.BtnGantiJam.BackColor = System.Drawing.Color.Blue
        Me.BtnGantiJam.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnGantiJam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnGantiJam.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGantiJam.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGantiJam.ForeColor = System.Drawing.Color.White
        Me.BtnGantiJam.Location = New System.Drawing.Point(401, 3)
        Me.BtnGantiJam.Name = "BtnGantiJam"
        Me.BtnGantiJam.Size = New System.Drawing.Size(47, 31)
        Me.BtnGantiJam.TabIndex = 37
        Me.BtnGantiJam.Text = "+"
        Me.BtnGantiJam.UseVisualStyleBackColor = False
        Me.BtnGantiJam.Visible = False
        '
        'LblEfisiensi
        '
        Me.LblEfisiensi.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LblEfisiensi.AutoSize = True
        Me.LblEfisiensi.BackColor = System.Drawing.Color.Transparent
        Me.LblEfisiensi.Font = New System.Drawing.Font("Segoe UI", 90.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblEfisiensi.Location = New System.Drawing.Point(120, 85)
        Me.LblEfisiensi.Name = "LblEfisiensi"
        Me.LblEfisiensi.Size = New System.Drawing.Size(171, 159)
        Me.LblEfisiensi.TabIndex = 7
        Me.LblEfisiensi.Text = "%"
        Me.LblEfisiensi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblJudulEfiseinsi
        '
        Me.LblJudulEfiseinsi.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LblJudulEfiseinsi.AutoSize = True
        Me.LblJudulEfiseinsi.BackColor = System.Drawing.Color.Transparent
        Me.LblJudulEfiseinsi.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJudulEfiseinsi.Location = New System.Drawing.Point(159, 12)
        Me.LblJudulEfiseinsi.Name = "LblJudulEfiseinsi"
        Me.LblJudulEfiseinsi.Size = New System.Drawing.Size(120, 30)
        Me.LblJudulEfiseinsi.TabIndex = 6
        Me.LblJudulEfiseinsi.Text = "EFISIENSI :"
        '
        'PanelRunningText
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.PanelRunningText, 3)
        Me.PanelRunningText.Controls.Add(Me.LblRunningText)
        Me.PanelRunningText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelRunningText.Location = New System.Drawing.Point(4, 600)
        Me.PanelRunningText.Name = "PanelRunningText"
        Me.PanelRunningText.Size = New System.Drawing.Size(1362, 142)
        Me.PanelRunningText.TabIndex = 13
        '
        'LblRunningText
        '
        Me.LblRunningText.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.LblRunningText.AutoSize = True
        Me.LblRunningText.Font = New System.Drawing.Font("Segoe UI Black", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRunningText.Location = New System.Drawing.Point(8, 5)
        Me.LblRunningText.Name = "LblRunningText"
        Me.LblRunningText.Size = New System.Drawing.Size(1456, 128)
        Me.LblRunningText.TabIndex = 0
        Me.LblRunningText.Text = "Utamakan keselamatan kerja!"
        '
        'PanelSetting
        '
        Me.PanelSetting.BackColor = System.Drawing.Color.Transparent
        Me.PanelSetting.Controls.Add(Me.BtnTambahManual)
        Me.PanelSetting.Controls.Add(Me.BtnContinue)
        Me.PanelSetting.Controls.Add(Me.BtnPause)
        Me.PanelSetting.Controls.Add(Me.TxtBerat)
        Me.PanelSetting.Controls.Add(Me.TxtPerintah)
        Me.PanelSetting.Controls.Add(Me.BtnSetting)
        Me.PanelSetting.Controls.Add(Me.BtnConnectTimbangan)
        Me.PanelSetting.Controls.Add(Me.Label8)
        Me.PanelSetting.Controls.Add(Me.BtnStop)
        Me.PanelSetting.Controls.Add(Me.LblDelayDetik)
        Me.PanelSetting.Controls.Add(Me.Label11)
        Me.PanelSetting.Controls.Add(Me.TxtTampung2)
        Me.PanelSetting.Controls.Add(Me.TxtTampung1)
        Me.PanelSetting.Location = New System.Drawing.Point(916, 451)
        Me.PanelSetting.Name = "PanelSetting"
        Me.PanelSetting.Size = New System.Drawing.Size(450, 142)
        Me.PanelSetting.TabIndex = 12
        '
        'BtnTambahManual
        '
        Me.BtnTambahManual.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnTambahManual.BackColor = System.Drawing.Color.SeaShell
        Me.BtnTambahManual.Enabled = False
        Me.BtnTambahManual.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.BtnTambahManual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTambahManual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnTambahManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTambahManual.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTambahManual.ForeColor = System.Drawing.Color.White
        Me.BtnTambahManual.Image = Global.JadwalProduksi.My.Resources.Resources.b_add
        Me.BtnTambahManual.Location = New System.Drawing.Point(213, 97)
        Me.BtnTambahManual.Name = "BtnTambahManual"
        Me.BtnTambahManual.Size = New System.Drawing.Size(40, 38)
        Me.BtnTambahManual.TabIndex = 42
        Me.BtnTambahManual.UseVisualStyleBackColor = False
        '
        'BtnContinue
        '
        Me.BtnContinue.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnContinue.BackColor = System.Drawing.Color.Orchid
        Me.BtnContinue.Enabled = False
        Me.BtnContinue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green
        Me.BtnContinue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnContinue.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnContinue.ForeColor = System.Drawing.Color.White
        Me.BtnContinue.Location = New System.Drawing.Point(417, 4)
        Me.BtnContinue.Name = "BtnContinue"
        Me.BtnContinue.Size = New System.Drawing.Size(30, 130)
        Me.BtnContinue.TabIndex = 41
        Me.BtnContinue.Text = "C" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "o" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "n" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "t" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "i"
        Me.BtnContinue.UseVisualStyleBackColor = False
        '
        'BtnPause
        '
        Me.BtnPause.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnPause.BackColor = System.Drawing.Color.Blue
        Me.BtnPause.Enabled = False
        Me.BtnPause.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green
        Me.BtnPause.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPause.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPause.ForeColor = System.Drawing.Color.White
        Me.BtnPause.Location = New System.Drawing.Point(380, 4)
        Me.BtnPause.Name = "BtnPause"
        Me.BtnPause.Size = New System.Drawing.Size(30, 130)
        Me.BtnPause.TabIndex = 40
        Me.BtnPause.Text = "P" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "u" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "s" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "e"
        Me.BtnPause.UseVisualStyleBackColor = False
        '
        'TxtBerat
        '
        Me.TxtBerat.BackColor = System.Drawing.Color.White
        Me.TxtBerat.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBerat.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBerat.ForeColor = System.Drawing.Color.Red
        Me.TxtBerat.Location = New System.Drawing.Point(6, 10)
        Me.TxtBerat.MaxLength = 4
        Me.TxtBerat.Name = "TxtBerat"
        Me.TxtBerat.ReadOnly = True
        Me.TxtBerat.Size = New System.Drawing.Size(148, 64)
        Me.TxtBerat.TabIndex = 0
        Me.TxtBerat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TxtPerintah
        '
        Me.TxtPerintah.Font = New System.Drawing.Font("Segoe UI Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPerintah.Location = New System.Drawing.Point(215, 61)
        Me.TxtPerintah.MaxLength = 1
        Me.TxtPerintah.Name = "TxtPerintah"
        Me.TxtPerintah.Size = New System.Drawing.Size(38, 25)
        Me.TxtPerintah.TabIndex = 37
        Me.TxtPerintah.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BtnSetting
        '
        Me.BtnSetting.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnSetting.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnSetting.FlatAppearance.BorderSize = 0
        Me.BtnSetting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSetting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetting.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSetting.ForeColor = System.Drawing.Color.White
        Me.BtnSetting.Image = CType(resources.GetObject("BtnSetting.Image"), System.Drawing.Image)
        Me.BtnSetting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnSetting.Location = New System.Drawing.Point(256, 4)
        Me.BtnSetting.Name = "BtnSetting"
        Me.BtnSetting.Size = New System.Drawing.Size(114, 39)
        Me.BtnSetting.TabIndex = 1
        Me.BtnSetting.Text = "SETTING"
        Me.BtnSetting.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSetting.UseVisualStyleBackColor = False
        '
        'BtnConnectTimbangan
        '
        Me.BtnConnectTimbangan.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnConnectTimbangan.BackColor = System.Drawing.Color.Green
        Me.BtnConnectTimbangan.FlatAppearance.BorderSize = 0
        Me.BtnConnectTimbangan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnConnectTimbangan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnConnectTimbangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnConnectTimbangan.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnConnectTimbangan.ForeColor = System.Drawing.Color.White
        Me.BtnConnectTimbangan.Image = CType(resources.GetObject("BtnConnectTimbangan.Image"), System.Drawing.Image)
        Me.BtnConnectTimbangan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnConnectTimbangan.Location = New System.Drawing.Point(256, 50)
        Me.BtnConnectTimbangan.Name = "BtnConnectTimbangan"
        Me.BtnConnectTimbangan.Size = New System.Drawing.Size(114, 40)
        Me.BtnConnectTimbangan.TabIndex = 10
        Me.BtnConnectTimbangan.Text = "START"
        Me.BtnConnectTimbangan.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnConnectTimbangan.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(160, 37)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 37)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "KG"
        '
        'BtnStop
        '
        Me.BtnStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnStop.BackColor = System.Drawing.Color.Gray
        Me.BtnStop.FlatAppearance.BorderSize = 0
        Me.BtnStop.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnStop.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnStop.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStop.ForeColor = System.Drawing.Color.White
        Me.BtnStop.Image = CType(resources.GetObject("BtnStop.Image"), System.Drawing.Image)
        Me.BtnStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnStop.Location = New System.Drawing.Point(256, 97)
        Me.BtnStop.Name = "BtnStop"
        Me.BtnStop.Size = New System.Drawing.Size(114, 38)
        Me.BtnStop.TabIndex = 3
        Me.BtnStop.Text = "STOP"
        Me.BtnStop.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnStop.UseVisualStyleBackColor = False
        '
        'LblDelayDetik
        '
        Me.LblDelayDetik.AutoSize = True
        Me.LblDelayDetik.BackColor = System.Drawing.Color.Transparent
        Me.LblDelayDetik.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDelayDetik.ForeColor = System.Drawing.Color.Red
        Me.LblDelayDetik.Location = New System.Drawing.Point(159, 78)
        Me.LblDelayDetik.Name = "LblDelayDetik"
        Me.LblDelayDetik.Size = New System.Drawing.Size(43, 50)
        Me.LblDelayDetik.TabIndex = 9
        Me.LblDelayDetik.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(7, 87)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(117, 37)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "DELAY  :"
        '
        'TxtTampung2
        '
        Me.TxtTampung2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTampung2.Location = New System.Drawing.Point(215, 4)
        Me.TxtTampung2.Name = "TxtTampung2"
        Me.TxtTampung2.Size = New System.Drawing.Size(38, 25)
        Me.TxtTampung2.TabIndex = 8
        Me.TxtTampung2.Visible = False
        '
        'TxtTampung1
        '
        Me.TxtTampung1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTampung1.Location = New System.Drawing.Point(215, 32)
        Me.TxtTampung1.Name = "TxtTampung1"
        Me.TxtTampung1.Size = New System.Drawing.Size(38, 25)
        Me.TxtTampung1.TabIndex = 7
        Me.TxtTampung1.Visible = False
        '
        'TimerWaktu
        '
        Me.TimerWaktu.Enabled = True
        Me.TimerWaktu.Interval = 1000
        '
        'TimerAktual
        '
        Me.TimerAktual.Interval = 1000
        '
        'SerialPortTimbangan
        '
        '
        'BackgroundWorkerTimbangan
        '
        '
        'TimerRunningText
        '
        Me.TimerRunningText.Interval = 400
        '
        'SerialPortArduino
        '
        '
        'BackgroundWorkerArduino
        '
        '
        'TimerMsgBox
        '
        Me.TimerMsgBox.Interval = 1000
        '
        'TimerTambahAktualDariButton
        '
        Me.TimerTambahAktualDariButton.Interval = 1000
        '
        'TimerRealtimeRunningText
        '
        Me.TimerRealtimeRunningText.Interval = 5000
        '
        'FormDisplay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 746)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormDisplay"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Product Counter"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.PanelEfisensi.ResumeLayout(False)
        Me.PanelEfisensi.PerformLayout()
        Me.PanelNotifikasi.ResumeLayout(False)
        Me.PanelNotifikasi.PerformLayout()
        Me.PanelHeaderNotifikasi.ResumeLayout(False)
        Me.PanelHeaderNotifikasi.PerformLayout()
        Me.PanelRunningText.ResumeLayout(False)
        Me.PanelRunningText.PerformLayout()
        Me.PanelSetting.ResumeLayout(False)
        Me.PanelSetting.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LblAktual As Label
    Friend WithEvents LblJudulAktual As Label
    Friend WithEvents LblTarget As Label
    Friend WithEvents LblJudulTarget As Label
    Friend WithEvents LblModel As Label
    Friend WithEvents LblJudulModel As Label
    Friend WithEvents LblDate As Label
    Friend WithEvents LblDay As Label
    Friend WithEvents TimerWaktu As Timer
    Friend WithEvents TimerAktual As Timer
    Friend WithEvents SerialPortTimbangan As IO.Ports.SerialPort
    Friend WithEvents BackgroundWorkerTimbangan As System.ComponentModel.BackgroundWorker
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents LblTime As Label
    Friend WithEvents PanelEfisensi As Panel
    Friend WithEvents PanelSetting As Panel
    Friend WithEvents BtnConnectTimbangan As Button
    Friend WithEvents BtnSetting As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents BtnStop As Button
    Friend WithEvents LblDelayDetik As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TxtTampung2 As TextBox
    Friend WithEvents TxtTampung1 As TextBox
    Friend WithEvents PanelRunningText As Panel
    Friend WithEvents LblRunningText As Label
    Friend WithEvents TimerRunningText As Timer
    Friend WithEvents LblEfisiensi As Label
    Friend WithEvents LblJudulEfiseinsi As Label
    Friend WithEvents TxtRichTemp As RichTextBox
    Friend WithEvents RichTextBoxArduino As RichTextBox
    Friend WithEvents SerialPortArduino As IO.Ports.SerialPort
    Friend WithEvents BackgroundWorkerArduino As System.ComponentModel.BackgroundWorker
    Friend WithEvents TxtPerintah As TextBox
    Friend WithEvents PanelNotifikasi As Panel
    Friend WithEvents LblIsiNotifikasi As Label
    Friend WithEvents PanelHeaderNotifikasi As Panel
    Friend WithEvents LblJudulNotifikasi As Label
    Friend WithEvents TimerMsgBox As Timer
    Friend WithEvents BtnGantiJam As Button
    Friend WithEvents TimerTambahAktualDariButton As Timer
    Friend WithEvents TxtBerat As TextBox
    Friend WithEvents PanelPenutupRichTextBox As Panel
    Friend WithEvents BtnTambahAktual As Button
    Friend WithEvents BtnPause As Button
    Friend WithEvents BtnContinue As Button
    Friend WithEvents BtnTambahManual As Button
    Friend WithEvents TimerRealtimeRunningText As Timer
End Class
