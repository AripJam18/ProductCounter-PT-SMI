﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIstirahat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormIstirahat))
        Me.PanelBawah = New System.Windows.Forms.Panel()
        Me.LblJumlahData = New System.Windows.Forms.Label()
        Me.PanelTengah = New System.Windows.Forms.Panel()
        Me.DGVIstirahat = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.BtnMain = New System.Windows.Forms.Button()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.BtnEdit = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TxtFind = New System.Windows.Forms.TextBox()
        Me.BtnShowAll = New System.Windows.Forms.Button()
        Me.BtnFind = New System.Windows.Forms.Button()
        Me.TxtDurasi1 = New System.Windows.Forms.TextBox()
        Me.TxtSelesai1 = New System.Windows.Forms.TextBox()
        Me.TxtMulai1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtIDIstirahat = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtDurasi3 = New System.Windows.Forms.TextBox()
        Me.TxtSelesai3 = New System.Windows.Forms.TextBox()
        Me.TxtMulai3 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RBOn = New System.Windows.Forms.RadioButton()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.RBOff = New System.Windows.Forms.RadioButton()
        Me.TxtDurasi2 = New System.Windows.Forms.TextBox()
        Me.TxtSelesai2 = New System.Windows.Forms.TextBox()
        Me.TxtMulai2 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CmbNamaWaktu = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelAtas = New System.Windows.Forms.Panel()
        Me.PanelBawah.SuspendLayout()
        Me.PanelTengah.SuspendLayout()
        CType(Me.DGVIstirahat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.PanelAtas.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelBawah
        '
        Me.PanelBawah.BackColor = System.Drawing.Color.LightGray
        Me.PanelBawah.Controls.Add(Me.LblJumlahData)
        Me.PanelBawah.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBawah.Location = New System.Drawing.Point(0, 664)
        Me.PanelBawah.Name = "PanelBawah"
        Me.PanelBawah.Size = New System.Drawing.Size(1232, 38)
        Me.PanelBawah.TabIndex = 4
        '
        'LblJumlahData
        '
        Me.LblJumlahData.AutoSize = True
        Me.LblJumlahData.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJumlahData.Location = New System.Drawing.Point(8, 10)
        Me.LblJumlahData.Name = "LblJumlahData"
        Me.LblJumlahData.Size = New System.Drawing.Size(90, 17)
        Me.LblJumlahData.TabIndex = 0
        Me.LblJumlahData.Text = "Jumlah Data :"
        '
        'PanelTengah
        '
        Me.PanelTengah.BackColor = System.Drawing.Color.White
        Me.PanelTengah.Controls.Add(Me.DGVIstirahat)
        Me.PanelTengah.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelTengah.Location = New System.Drawing.Point(0, 176)
        Me.PanelTengah.Name = "PanelTengah"
        Me.PanelTengah.Size = New System.Drawing.Size(1232, 526)
        Me.PanelTengah.TabIndex = 3
        '
        'DGVIstirahat
        '
        Me.DGVIstirahat.AllowUserToAddRows = False
        Me.DGVIstirahat.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.DGVIstirahat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVIstirahat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGVIstirahat.Location = New System.Drawing.Point(0, 0)
        Me.DGVIstirahat.Name = "DGVIstirahat"
        Me.DGVIstirahat.Size = New System.Drawing.Size(1232, 526)
        Me.DGVIstirahat.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.BtnSave)
        Me.GroupBox2.Controls.Add(Me.BtnMain)
        Me.GroupBox2.Controls.Add(Me.BtnCancel)
        Me.GroupBox2.Controls.Add(Me.BtnDelete)
        Me.GroupBox2.Controls.Add(Me.BtnEdit)
        Me.GroupBox2.Controls.Add(Me.BtnAdd)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(820, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(201, 148)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Action"
        '
        'BtnSave
        '
        Me.BtnSave.Enabled = False
        Me.BtnSave.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSave.Image = Global.JadwalProduksi.My.Resources.Resources.b_save
        Me.BtnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnSave.Location = New System.Drawing.Point(101, 17)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(83, 38)
        Me.BtnSave.TabIndex = 5
        Me.BtnSave.Text = "Save"
        Me.BtnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'BtnMain
        '
        Me.BtnMain.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnMain.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnMain.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMain.ForeColor = System.Drawing.Color.White
        Me.BtnMain.Image = Global.JadwalProduksi.My.Resources.Resources.b_home
        Me.BtnMain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnMain.Location = New System.Drawing.Point(101, 105)
        Me.BtnMain.Name = "BtnMain"
        Me.BtnMain.Size = New System.Drawing.Size(83, 38)
        Me.BtnMain.TabIndex = 4
        Me.BtnMain.Text = "Main"
        Me.BtnMain.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnMain.UseVisualStyleBackColor = False
        '
        'BtnCancel
        '
        Me.BtnCancel.Enabled = False
        Me.BtnCancel.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCancel.Image = CType(resources.GetObject("BtnCancel.Image"), System.Drawing.Image)
        Me.BtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnCancel.Location = New System.Drawing.Point(101, 61)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(83, 38)
        Me.BtnCancel.TabIndex = 3
        Me.BtnCancel.Text = "Cancel"
        Me.BtnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCancel.UseVisualStyleBackColor = True
        '
        'BtnDelete
        '
        Me.BtnDelete.Enabled = False
        Me.BtnDelete.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDelete.Image = CType(resources.GetObject("BtnDelete.Image"), System.Drawing.Image)
        Me.BtnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnDelete.Location = New System.Drawing.Point(12, 105)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(83, 38)
        Me.BtnDelete.TabIndex = 2
        Me.BtnDelete.Text = "Delete"
        Me.BtnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnDelete.UseVisualStyleBackColor = True
        '
        'BtnEdit
        '
        Me.BtnEdit.Enabled = False
        Me.BtnEdit.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnEdit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnEdit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEdit.Image = CType(resources.GetObject("BtnEdit.Image"), System.Drawing.Image)
        Me.BtnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnEdit.Location = New System.Drawing.Point(12, 61)
        Me.BtnEdit.Name = "BtnEdit"
        Me.BtnEdit.Size = New System.Drawing.Size(83, 38)
        Me.BtnEdit.TabIndex = 1
        Me.BtnEdit.Text = "Edit"
        Me.BtnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnEdit.UseVisualStyleBackColor = True
        '
        'BtnAdd
        '
        Me.BtnAdd.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdd.Image = CType(resources.GetObject("BtnAdd.Image"), System.Drawing.Image)
        Me.BtnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAdd.Location = New System.Drawing.Point(12, 17)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(83, 38)
        Me.BtnAdd.TabIndex = 0
        Me.BtnAdd.Text = "Add"
        Me.BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.TxtFind)
        Me.GroupBox3.Controls.Add(Me.BtnShowAll)
        Me.GroupBox3.Controls.Add(Me.BtnFind)
        Me.GroupBox3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(1027, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(201, 148)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Search"
        '
        'TxtFind
        '
        Me.TxtFind.Location = New System.Drawing.Point(18, 30)
        Me.TxtFind.MaxLength = 10
        Me.TxtFind.Name = "TxtFind"
        Me.TxtFind.Size = New System.Drawing.Size(175, 25)
        Me.TxtFind.TabIndex = 11
        '
        'BtnShowAll
        '
        Me.BtnShowAll.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnShowAll.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnShowAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnShowAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnShowAll.Image = CType(resources.GetObject("BtnShowAll.Image"), System.Drawing.Image)
        Me.BtnShowAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnShowAll.Location = New System.Drawing.Point(96, 78)
        Me.BtnShowAll.Name = "BtnShowAll"
        Me.BtnShowAll.Size = New System.Drawing.Size(97, 38)
        Me.BtnShowAll.TabIndex = 2
        Me.BtnShowAll.Text = "Show All"
        Me.BtnShowAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnShowAll.UseVisualStyleBackColor = True
        '
        'BtnFind
        '
        Me.BtnFind.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnFind.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnFind.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFind.Image = CType(resources.GetObject("BtnFind.Image"), System.Drawing.Image)
        Me.BtnFind.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnFind.Location = New System.Drawing.Point(18, 78)
        Me.BtnFind.Name = "BtnFind"
        Me.BtnFind.Size = New System.Drawing.Size(72, 38)
        Me.BtnFind.TabIndex = 0
        Me.BtnFind.Text = "Find"
        Me.BtnFind.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnFind.UseVisualStyleBackColor = True
        '
        'TxtDurasi1
        '
        Me.TxtDurasi1.Location = New System.Drawing.Point(128, 110)
        Me.TxtDurasi1.MaxLength = 3
        Me.TxtDurasi1.Name = "TxtDurasi1"
        Me.TxtDurasi1.Size = New System.Drawing.Size(135, 25)
        Me.TxtDurasi1.TabIndex = 10
        '
        'TxtSelesai1
        '
        Me.TxtSelesai1.Location = New System.Drawing.Point(128, 81)
        Me.TxtSelesai1.MaxLength = 12
        Me.TxtSelesai1.Name = "TxtSelesai1"
        Me.TxtSelesai1.Size = New System.Drawing.Size(135, 25)
        Me.TxtSelesai1.TabIndex = 9
        '
        'TxtMulai1
        '
        Me.TxtMulai1.Location = New System.Drawing.Point(128, 52)
        Me.TxtMulai1.MaxLength = 12
        Me.TxtMulai1.Name = "TxtMulai1"
        Me.TxtMulai1.Size = New System.Drawing.Size(135, 25)
        Me.TxtMulai1.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 111)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Durasi (menit) :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 83)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Selesai (1) :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Mulai (1) :"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.TxtIDIstirahat)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TxtDurasi3)
        Me.GroupBox1.Controls.Add(Me.TxtSelesai3)
        Me.GroupBox1.Controls.Add(Me.TxtMulai3)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.RBOn)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.RBOff)
        Me.GroupBox1.Controls.Add(Me.TxtDurasi2)
        Me.GroupBox1.Controls.Add(Me.TxtSelesai2)
        Me.GroupBox1.Controls.Add(Me.TxtMulai2)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.CmbNamaWaktu)
        Me.GroupBox1.Controls.Add(Me.TxtDurasi1)
        Me.GroupBox1.Controls.Add(Me.TxtSelesai1)
        Me.GroupBox1.Controls.Add(Me.TxtMulai1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(11, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(803, 148)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data"
        '
        'TxtIDIstirahat
        '
        Me.TxtIDIstirahat.Location = New System.Drawing.Point(394, 20)
        Me.TxtIDIstirahat.MaxLength = 3
        Me.TxtIDIstirahat.Name = "TxtIDIstirahat"
        Me.TxtIDIstirahat.ReadOnly = True
        Me.TxtIDIstirahat.Size = New System.Drawing.Size(135, 25)
        Me.TxtIDIstirahat.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(314, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 17)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "id Istirahat :"
        '
        'TxtDurasi3
        '
        Me.TxtDurasi3.Location = New System.Drawing.Point(656, 110)
        Me.TxtDurasi3.MaxLength = 3
        Me.TxtDurasi3.Name = "TxtDurasi3"
        Me.TxtDurasi3.Size = New System.Drawing.Size(135, 25)
        Me.TxtDurasi3.TabIndex = 33
        '
        'TxtSelesai3
        '
        Me.TxtSelesai3.Location = New System.Drawing.Point(656, 81)
        Me.TxtSelesai3.MaxLength = 12
        Me.TxtSelesai3.Name = "TxtSelesai3"
        Me.TxtSelesai3.Size = New System.Drawing.Size(135, 25)
        Me.TxtSelesai3.TabIndex = 32
        '
        'TxtMulai3
        '
        Me.TxtMulai3.Location = New System.Drawing.Point(656, 52)
        Me.TxtMulai3.MaxLength = 12
        Me.TxtMulai3.Name = "TxtMulai3"
        Me.TxtMulai3.Size = New System.Drawing.Size(135, 25)
        Me.TxtMulai3.TabIndex = 31
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(547, 115)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 17)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Durasi (menit) :"
        '
        'RBOn
        '
        Me.RBOn.AutoSize = True
        Me.RBOn.Location = New System.Drawing.Point(665, 19)
        Me.RBOn.Name = "RBOn"
        Me.RBOn.Size = New System.Drawing.Size(44, 21)
        Me.RBOn.TabIndex = 19
        Me.RBOn.TabStop = True
        Me.RBOn.Text = "On"
        Me.RBOn.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(573, 89)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 17)
        Me.Label12.TabIndex = 29
        Me.Label12.Text = "Selesai (3) :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(587, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 17)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Rolling  :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(580, 53)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(67, 17)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "Mulai (3) :"
        '
        'RBOff
        '
        Me.RBOff.AutoSize = True
        Me.RBOff.Location = New System.Drawing.Point(747, 19)
        Me.RBOff.Name = "RBOff"
        Me.RBOff.Size = New System.Drawing.Size(44, 21)
        Me.RBOff.TabIndex = 20
        Me.RBOff.TabStop = True
        Me.RBOff.Text = "Off"
        Me.RBOff.UseVisualStyleBackColor = True
        '
        'TxtDurasi2
        '
        Me.TxtDurasi2.Location = New System.Drawing.Point(394, 110)
        Me.TxtDurasi2.MaxLength = 3
        Me.TxtDurasi2.Name = "TxtDurasi2"
        Me.TxtDurasi2.Size = New System.Drawing.Size(135, 25)
        Me.TxtDurasi2.TabIndex = 27
        '
        'TxtSelesai2
        '
        Me.TxtSelesai2.Location = New System.Drawing.Point(394, 81)
        Me.TxtSelesai2.MaxLength = 12
        Me.TxtSelesai2.Name = "TxtSelesai2"
        Me.TxtSelesai2.Size = New System.Drawing.Size(135, 25)
        Me.TxtSelesai2.TabIndex = 26
        '
        'TxtMulai2
        '
        Me.TxtMulai2.Location = New System.Drawing.Point(394, 52)
        Me.TxtMulai2.MaxLength = 12
        Me.TxtMulai2.Name = "TxtMulai2"
        Me.TxtMulai2.Size = New System.Drawing.Size(135, 25)
        Me.TxtMulai2.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(288, 113)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 17)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Durasi (menit) :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(314, 85)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 17)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Selesai (2) :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(321, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 17)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Mulai (2) :"
        '
        'CmbNamaWaktu
        '
        Me.CmbNamaWaktu.FormattingEnabled = True
        Me.CmbNamaWaktu.Items.AddRange(New Object() {"Pagi", "Siang", "Sore", "Maghrib"})
        Me.CmbNamaWaktu.Location = New System.Drawing.Point(128, 23)
        Me.CmbNamaWaktu.Name = "CmbNamaWaktu"
        Me.CmbNamaWaktu.Size = New System.Drawing.Size(135, 25)
        Me.CmbNamaWaktu.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama Waktu :"
        '
        'PanelAtas
        '
        Me.PanelAtas.BackColor = System.Drawing.Color.LightGray
        Me.PanelAtas.Controls.Add(Me.GroupBox3)
        Me.PanelAtas.Controls.Add(Me.GroupBox2)
        Me.PanelAtas.Controls.Add(Me.GroupBox1)
        Me.PanelAtas.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelAtas.Location = New System.Drawing.Point(0, 0)
        Me.PanelAtas.Name = "PanelAtas"
        Me.PanelAtas.Size = New System.Drawing.Size(1232, 176)
        Me.PanelAtas.TabIndex = 2
        '
        'FormIstirahat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1232, 702)
        Me.Controls.Add(Me.PanelBawah)
        Me.Controls.Add(Me.PanelTengah)
        Me.Controls.Add(Me.PanelAtas)
        Me.Name = "FormIstirahat"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Istirahat"
        Me.PanelBawah.ResumeLayout(False)
        Me.PanelBawah.PerformLayout()
        Me.PanelTengah.ResumeLayout(False)
        CType(Me.DGVIstirahat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.PanelAtas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelBawah As Panel
    Friend WithEvents LblJumlahData As Label
    Friend WithEvents PanelTengah As Panel
    Friend WithEvents DGVIstirahat As DataGridView
    Friend WithEvents BtnShowAll As Button
    Friend WithEvents TxtDurasi1 As TextBox
    Friend WithEvents BtnSave As Button
    Friend WithEvents BtnMain As Button
    Friend WithEvents TxtSelesai1 As TextBox
    Friend WithEvents TxtMulai1 As TextBox
    Friend WithEvents BtnCancel As Button
    Friend WithEvents BtnDelete As Button
    Friend WithEvents BtnFind As Button
    Friend WithEvents BtnAdd As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnEdit As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtFind As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents PanelAtas As Panel
    Friend WithEvents CmbNamaWaktu As ComboBox
    Friend WithEvents TxtIDIstirahat As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents RBOff As RadioButton
    Friend WithEvents RBOn As RadioButton
    Friend WithEvents TxtDurasi3 As TextBox
    Friend WithEvents TxtSelesai3 As TextBox
    Friend WithEvents TxtMulai3 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TxtDurasi2 As TextBox
    Friend WithEvents TxtSelesai2 As TextBox
    Friend WithEvents TxtMulai2 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
End Class
