﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnWeb = New System.Windows.Forms.Button()
        Me.BtnMonitoring = New System.Windows.Forms.Button()
        Me.Lblaktivasi = New System.Windows.Forms.Label()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnReport = New System.Windows.Forms.Button()
        Me.BtnDisplay = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Lblpesan = New System.Windows.Forms.Label()
        Me.BtnUser = New System.Windows.Forms.Button()
        Me.BtnLine = New System.Windows.Forms.Button()
        Me.BtnSetting = New System.Windows.Forms.Button()
        Me.BtnIstirahat = New System.Windows.Forms.Button()
        Me.BtnModel = New System.Windows.Forms.Button()
        Me.TimerTrial = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1097, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem, Me.ToolStripSeparator1, Me.HelpToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(100, 6)
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 24)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1097, 389)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel1, 2)
        Me.Panel1.Controls.Add(Me.BtnWeb)
        Me.Panel1.Controls.Add(Me.BtnMonitoring)
        Me.Panel1.Controls.Add(Me.Lblaktivasi)
        Me.Panel1.Controls.Add(Me.BtnLogout)
        Me.Panel1.Controls.Add(Me.BtnReport)
        Me.Panel1.Controls.Add(Me.BtnDisplay)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1091, 188)
        Me.Panel1.TabIndex = 0
        '
        'BtnWeb
        '
        Me.BtnWeb.Enabled = False
        Me.BtnWeb.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnWeb.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnWeb.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnWeb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWeb.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWeb.Image = Global.JadwalProduksi.My.Resources.Resources.website
        Me.BtnWeb.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnWeb.Location = New System.Drawing.Point(895, 21)
        Me.BtnWeb.Name = "BtnWeb"
        Me.BtnWeb.Size = New System.Drawing.Size(187, 130)
        Me.BtnWeb.TabIndex = 6
        Me.BtnWeb.Text = "Website"
        Me.BtnWeb.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnWeb.UseVisualStyleBackColor = True
        '
        'BtnMonitoring
        '
        Me.BtnMonitoring.Enabled = False
        Me.BtnMonitoring.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnMonitoring.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnMonitoring.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnMonitoring.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMonitoring.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMonitoring.Image = CType(resources.GetObject("BtnMonitoring.Image"), System.Drawing.Image)
        Me.BtnMonitoring.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnMonitoring.Location = New System.Drawing.Point(671, 21)
        Me.BtnMonitoring.Name = "BtnMonitoring"
        Me.BtnMonitoring.Size = New System.Drawing.Size(187, 130)
        Me.BtnMonitoring.TabIndex = 5
        Me.BtnMonitoring.Text = "Monitoring"
        Me.BtnMonitoring.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnMonitoring.UseVisualStyleBackColor = True
        '
        'Lblaktivasi
        '
        Me.Lblaktivasi.AutoSize = True
        Me.Lblaktivasi.Dock = System.Windows.Forms.DockStyle.Top
        Me.Lblaktivasi.Location = New System.Drawing.Point(0, 0)
        Me.Lblaktivasi.Name = "Lblaktivasi"
        Me.Lblaktivasi.Size = New System.Drawing.Size(57, 13)
        Me.Lblaktivasi.TabIndex = 2
        Me.Lblaktivasi.Text = "Aktivasi : "
        Me.Lblaktivasi.Visible = False
        '
        'BtnLogout
        '
        Me.BtnLogout.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogout.Image = Global.JadwalProduksi.My.Resources.Resources.logout
        Me.BtnLogout.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnLogout.Location = New System.Drawing.Point(450, 21)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(187, 130)
        Me.BtnLogout.TabIndex = 4
        Me.BtnLogout.Text = "Log Out"
        Me.BtnLogout.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'BtnReport
        '
        Me.BtnReport.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReport.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReport.Image = CType(resources.GetObject("BtnReport.Image"), System.Drawing.Image)
        Me.BtnReport.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnReport.Location = New System.Drawing.Point(232, 21)
        Me.BtnReport.Name = "BtnReport"
        Me.BtnReport.Size = New System.Drawing.Size(187, 130)
        Me.BtnReport.TabIndex = 3
        Me.BtnReport.Text = "Report"
        Me.BtnReport.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnReport.UseVisualStyleBackColor = True
        '
        'BtnDisplay
        '
        Me.BtnDisplay.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnDisplay.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnDisplay.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDisplay.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDisplay.Image = CType(resources.GetObject("BtnDisplay.Image"), System.Drawing.Image)
        Me.BtnDisplay.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnDisplay.Location = New System.Drawing.Point(13, 21)
        Me.BtnDisplay.Name = "BtnDisplay"
        Me.BtnDisplay.Size = New System.Drawing.Size(187, 130)
        Me.BtnDisplay.TabIndex = 0
        Me.BtnDisplay.Text = "Display "
        Me.BtnDisplay.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnDisplay.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel2, 2)
        Me.Panel2.Controls.Add(Me.Lblpesan)
        Me.Panel2.Controls.Add(Me.BtnUser)
        Me.Panel2.Controls.Add(Me.BtnLine)
        Me.Panel2.Controls.Add(Me.BtnSetting)
        Me.Panel2.Controls.Add(Me.BtnIstirahat)
        Me.Panel2.Controls.Add(Me.BtnModel)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 197)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1091, 189)
        Me.Panel2.TabIndex = 1
        '
        'Lblpesan
        '
        Me.Lblpesan.AutoSize = True
        Me.Lblpesan.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Lblpesan.ForeColor = System.Drawing.Color.Maroon
        Me.Lblpesan.Location = New System.Drawing.Point(0, 176)
        Me.Lblpesan.Name = "Lblpesan"
        Me.Lblpesan.Size = New System.Drawing.Size(19, 13)
        Me.Lblpesan.TabIndex = 3
        Me.Lblpesan.Text = "---"
        Me.Lblpesan.Visible = False
        '
        'BtnUser
        '
        Me.BtnUser.Enabled = False
        Me.BtnUser.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUser.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUser.Image = Global.JadwalProduksi.My.Resources.Resources.user
        Me.BtnUser.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnUser.Location = New System.Drawing.Point(889, 19)
        Me.BtnUser.Name = "BtnUser"
        Me.BtnUser.Size = New System.Drawing.Size(187, 130)
        Me.BtnUser.TabIndex = 6
        Me.BtnUser.Text = "User"
        Me.BtnUser.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnUser.UseVisualStyleBackColor = True
        '
        'BtnLine
        '
        Me.BtnLine.Enabled = False
        Me.BtnLine.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnLine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnLine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLine.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLine.Image = CType(resources.GetObject("BtnLine.Image"), System.Drawing.Image)
        Me.BtnLine.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnLine.Location = New System.Drawing.Point(450, 19)
        Me.BtnLine.Name = "BtnLine"
        Me.BtnLine.Size = New System.Drawing.Size(187, 130)
        Me.BtnLine.TabIndex = 5
        Me.BtnLine.Text = "Line"
        Me.BtnLine.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnLine.UseVisualStyleBackColor = True
        '
        'BtnSetting
        '
        Me.BtnSetting.Enabled = False
        Me.BtnSetting.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnSetting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnSetting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetting.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSetting.Image = CType(resources.GetObject("BtnSetting.Image"), System.Drawing.Image)
        Me.BtnSetting.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnSetting.Location = New System.Drawing.Point(13, 19)
        Me.BtnSetting.Name = "BtnSetting"
        Me.BtnSetting.Size = New System.Drawing.Size(187, 130)
        Me.BtnSetting.TabIndex = 1
        Me.BtnSetting.Text = "Setting"
        Me.BtnSetting.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnSetting.UseVisualStyleBackColor = True
        '
        'BtnIstirahat
        '
        Me.BtnIstirahat.Enabled = False
        Me.BtnIstirahat.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnIstirahat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnIstirahat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnIstirahat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnIstirahat.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnIstirahat.Image = CType(resources.GetObject("BtnIstirahat.Image"), System.Drawing.Image)
        Me.BtnIstirahat.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnIstirahat.Location = New System.Drawing.Point(232, 19)
        Me.BtnIstirahat.Name = "BtnIstirahat"
        Me.BtnIstirahat.Size = New System.Drawing.Size(187, 130)
        Me.BtnIstirahat.TabIndex = 4
        Me.BtnIstirahat.Text = "Istirahat"
        Me.BtnIstirahat.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnIstirahat.UseVisualStyleBackColor = True
        '
        'BtnModel
        '
        Me.BtnModel.Enabled = False
        Me.BtnModel.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnModel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnModel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnModel.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModel.Image = CType(resources.GetObject("BtnModel.Image"), System.Drawing.Image)
        Me.BtnModel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnModel.Location = New System.Drawing.Point(671, 19)
        Me.BtnModel.Name = "BtnModel"
        Me.BtnModel.Size = New System.Drawing.Size(187, 130)
        Me.BtnModel.TabIndex = 2
        Me.BtnModel.Text = "Model"
        Me.BtnModel.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnModel.UseVisualStyleBackColor = True
        '
        'TimerTrial
        '
        Me.TimerTrial.Interval = 1000
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1097, 413)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Form"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnDisplay As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents BtnModel As Button
    Friend WithEvents BtnSetting As Button
    Friend WithEvents BtnReport As Button
    Friend WithEvents BtnIstirahat As Button
    Friend WithEvents BtnLine As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents BtnUser As Button
    Friend WithEvents CloseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Lblaktivasi As Label
    Friend WithEvents Lblpesan As Label
    Friend WithEvents TimerTrial As Timer
    Friend WithEvents BtnMonitoring As Button
    Friend WithEvents BtnWeb As Button
End Class
