﻿Imports System.Data.Odbc
Public Class FormIstirahat
    Dim statusdata As String
    Private Sub FormModel_Load(sender As Object, e As EventArgs) Handles Me.Load
        LoadDataAll()
        LoadNamaIstirhat()
        EnabledTextBox(False)
    End Sub


#Region "Function"
    Private Sub LoadNamaIstirhat()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT DISTINCT istirahat FROM setistirahat", CONN)
            DS = New DataSet
            DA.Fill(DS, "namaistirahat")
            Dim dt As DataTable = DS.Tables("namaistirahat")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data setistirahat ",
                       MsgBoxStyle.Exclamation, "Warning")
                CmbNamaWaktu.Text = ""
                CmbNamaWaktu.DataSource = Nothing
            Else
                CmbNamaWaktu.DataSource = dt
                CmbNamaWaktu.ValueMember = "istirahat"
                CmbNamaWaktu.DisplayMember = "istirahat"
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error LoadDataAll")
        End Try
    End Sub
    Private Sub LoadDataAll()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT `id` as ID, `istirahat` as 'Istirahat', `mulai1` as 'Mulai (Shift 1)', `selesai1` as 'Selesai (Shift 1)', `durasi1` as 'Durasi (Shift 1)', `mulai2` as 'Mulai (Shift 2)', `selesai2` as 'Selesai (Shift 2)', `durasi2` as 'Durasi (Shift 2)', `mulai3` as 'Mulai (Shift 3)', `selesai3` as 'Selesai (Shift 3)', `durasi3`as 'Durasi (Shift 3)', `rolling` as 'Rolling' FROM `setistirahat`", CONN)
            DS = New DataSet
            DA.Fill(DS, "istirahat")
            Dim dt As DataTable = DS.Tables("istirahat")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data setistirahat ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVIstirahat.Columns.Clear()
                DGVIstirahat.DataSource = Nothing
            Else
                DGVIstirahat.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error LoadDataAll")
        End Try
    End Sub
    Private Sub FindIstirahat()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT `id` as ID, `istirahat` as 'Istirahat', `mulai1` as 'Mulai (Shift 1)', `selesai1` as 'Selesai (Shift 1)', `durasi1` as 'Durasi (Shift 1)', `mulai2` as 'Mulai (Shift 2)', `selesai2` as 'Selesai (Shift 2)', `durasi2` as 'Durasi (Shift 2)', `mulai3` as 'Mulai (Shift 3)', `selesai3` as 'Selesai (Shift 3)', `durasi3`as 'Durasi (Shift 3)', `rolling` as 'Rolling' FROM `setistirahat`  WHERE istirahat='" & TxtFind.Text & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "findistirahat")
            Dim dt As DataTable = DS.Tables("findistirahat")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data istirahat ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVIstirahat.Columns.Clear()
                DGVIstirahat.DataSource = Nothing
            Else
                DGVIstirahat.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error Findistirahat")
        End Try
    End Sub
    Public Sub CekDataSebelumSimpan()
        Try
            ConnectMySQL()

            CMD = New OdbcCommand("SELECT `id` as ID, `istirahat` as 'Istirahat', `mulai1` as 'Mulai (Shift 1)', `selesai1` as 'Selesai (Shift 1)', `durasi1` as 'Durasi (Shift 1)', `mulai2` as 'Mulai (Shift 2)', `selesai2` as 'Selesai (Shift 2)', `durasi2` as 'Durasi (Shift 2)', `mulai3` as 'Mulai (Shift 3)', `selesai3` as 'Selesai (Shift 3)', `durasi3`as 'Durasi (Shift 3)', `rolling` as 'Rolling' FROM `setistirahat`  WHERE istirahat='" & CmbNamaWaktu.Text & "' ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                ''data baru boleh diinsert
                InsertDataIstrirahat()
            Else
                ''data sudah ada jadi diupdate saja
                UpdateDataIstrirahat()
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error CekDataSebelumSimpan()")
        End Try
    End Sub

    Private Sub InsertDataIstrirahat()
        Try
            ConnectMySQL()

            Dim simpan As String = "INSERT INTO setistirahat (istirahat, mulai1, selesai1, durasi1,mulai2, selesai2, durasi2, mulai3, selesai3, durasi3,rolling) VALUES ('" & CmbNamaWaktu.Text & "','" & TxtMulai1.Text & "','" & TxtSelesai1.Text & "'," & TxtDurasi1.Text & ",'" & TxtMulai2.Text & "','" & TxtSelesai2.Text & "'," & TxtDurasi2.Text & ",'" & TxtMulai3.Text & "','" & TxtSelesai3.Text & "'," & TxtDurasi3.Text & ",'" & CmbNamaWaktu.Text & "','" & RollingIstirahat & "')"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil disimpan", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataIstrirahat()")
        End Try
    End Sub

    Private Sub UpdateDataIstrirahat()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setistirahat SET istirahat='" & CmbNamaWaktu.Text & "', mulai1='" & TxtMulai1.Text & "',selesai1='" & TxtSelesai1.Text & "',durasi1=" & TxtDurasi1.Text & " , mulai2='" & TxtMulai2.Text & "',selesai2='" & TxtSelesai2.Text & "',durasi2=" & TxtDurasi2.Text & " , mulai3='" & TxtMulai3.Text & "',selesai3='" & TxtSelesai3.Text & "',durasi3=" & TxtDurasi3.Text & " ,rolling='" & RollingIstirahat & "' WHERE id='" & TxtIDIstirahat.Text & "'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateDataIstrirahat()")
        End Try
    End Sub
    Private Sub DeleteIstirahat()
        Try
            Dim result As DialogResult = MessageBox.Show("Confirm Delete?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

            If (result = DialogResult.Yes) Then
                ConnectMySQL()

                Dim hapus As String = "DELETE FROM setistirahat WHERE id='" & TxtIDIstirahat.Text & "'"
                CMD = New OdbcCommand(hapus, CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Data berhasil dihapus", vbInformation, "Informasi")
                LoadDataAll()
                KosongkanTextbox()
                KondisiDelete()
            Else
                'Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error DeleteIstirahat()")
        End Try
    End Sub

#End Region

#Region "Kondisi TextBox"
    Private Sub KosongkanTextbox()
        CmbNamaWaktu.Text = ""
        TxtMulai1.Clear()
        TxtSelesai1.Clear()
        TxtDurasi1.Clear()
        TxtMulai2.Clear()
        TxtSelesai2.Clear()
        TxtDurasi2.Clear()
        TxtMulai3.Clear()
        TxtSelesai3.Clear()
        TxtDurasi3.Clear()
        RBOn.Checked = False
        RBOff.Checked = False
    End Sub
    Private Sub EnabledTextBox(ByVal tf As Boolean)
        CmbNamaWaktu.Enabled = tf
        TxtMulai1.Enabled = tf
        TxtSelesai1.Enabled = tf
        TxtDurasi1.Enabled = tf
        TxtMulai2.Enabled = tf
        TxtSelesai2.Enabled = tf
        TxtDurasi2.Enabled = tf
        TxtMulai3.Enabled = tf
        TxtSelesai3.Enabled = tf
        TxtDurasi3.Enabled = tf
    End Sub
    Private Sub KondisiAdd()
        KosongkanTextbox()
        EnabledTextBox(True)
        BtnAdd.Enabled = False
        BtnSave.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiSave()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiEdit()
        EnabledTextBox(True)
        BtnSave.Enabled = True
        BtnAdd.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiCancel()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiDelete()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
#End Region
    Private Sub DGVModel_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVIstirahat.CellContentClick
        If DGVIstirahat.ColumnCount = 12 Then
            CmbNamaWaktu.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Istirahat").Value

            TxtMulai1.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Mulai (Shift 1)").Value
            TxtSelesai1.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Selesai (Shift 1)").Value
            TxtDurasi1.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Durasi (Shift 1)").Value

            TxtMulai2.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Mulai (Shift 2)").Value
            TxtSelesai2.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Selesai (Shift 2)").Value
            TxtDurasi2.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Durasi (Shift 2)").Value

            TxtMulai3.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Mulai (Shift 3)").Value
            TxtSelesai3.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Selesai (Shift 3)").Value
            TxtDurasi3.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("Durasi (Shift 3)").Value


            TxtIDIstirahat.Text = DGVIstirahat.Rows(e.RowIndex).Cells.Item("ID").Value
            If DGVIstirahat.Rows(e.RowIndex).Cells.Item("Rolling").Value = "On" Then
                RBOn.Checked = True
                RBOff.Checked = False
            Else
                RBOn.Checked = False
                RBOff.Checked = True
            End If
            BtnEdit.Enabled = True
            BtnDelete.Enabled = True
            statusdata = "edit"
        Else
            Exit Sub
            Exit Sub
        End If
    End Sub


#Region "Button Action"
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        statusdata = "add"
        KondisiAdd()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        DeleteIstirahat()
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        statusdata = "edit"
        KondisiEdit()
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        KondisiCancel()
    End Sub

    Private Sub BtnShowAll_Click(sender As Object, e As EventArgs) Handles BtnShowAll.Click
        LoadDataAll()
    End Sub

    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If TxtFind.TextLength = 0 Then
            Exit Sub
        End If
        FindIstirahat()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If statusdata = "edit" Then
            UpdateDataIstrirahat()
        Else
            CekDataSebelumSimpan()
        End If
        KondisiSave()
    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub RBOn_CheckedChanged(sender As Object, e As EventArgs) Handles RBOn.CheckedChanged
        If RBOn.Checked = True Then
            RollingIstirahat = "On"
        Else
            RollingIstirahat = "Off"
        End If
    End Sub

    Private Sub RBOff_CheckedChanged(sender As Object, e As EventArgs) Handles RBOff.CheckedChanged
        If RBOff.Checked = True Then
            RollingIstirahat = "Off"
        Else
            RollingIstirahat = "On"
        End If
    End Sub

#End Region

End Class
