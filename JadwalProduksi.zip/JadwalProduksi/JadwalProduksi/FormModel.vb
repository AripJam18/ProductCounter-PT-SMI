﻿Imports System.Data.Odbc
Public Class FormModel
    Dim statusdata As String
    Private Sub FormModel_Load(sender As Object, e As EventArgs) Handles Me.Load
        LoadDataAll()
        EnabledTextBox(False)
    End Sub


#Region "Function"
    Private Sub LoadDataAll()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT * FROM setmodel", CONN)
            DS = New DataSet
            DA.Fill(DS, "model")
            Dim dt As DataTable = DS.Tables("model")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data setmodel ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVModel.Columns.Clear()
                DGVModel.DataSource = Nothing
            Else
                DGVModel.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error LoadDataAll")
        End Try
    End Sub
    Private Sub FindModel()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT * FROM setmodel WHERE model='" & TxtFind.Text & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "findmodel")
            Dim dt As DataTable = DS.Tables("findmodel")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data model ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVModel.Columns.Clear()
                DGVModel.DataSource = Nothing
            Else
                DGVModel.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error FindModel")
        End Try
    End Sub
    Public Sub CekDataSebelumSimpan()
        Try
            ConnectMySQL()

            CMD = New OdbcCommand("SELECT * FROM setmodel WHERE model='" & TxtModel.Text & "' ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                ''data baru boleh diinsert
                InsertDataModel()
            Else
                ''data sudah ada jadi diupdate saja
                UpdateDataModel()
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error CekDataSebelumSimpan()")
        End Try
    End Sub

    Private Sub InsertDataModel()
        Try
            ConnectMySQL()

            Dim simpan As String = "INSERT INTO setmodel(model, target, plan, kelipatan, delay, minberat, maxberat) VALUES ('" & TxtModel.Text & "'," & TxtTarget.Text & "," & TxtPlan.Text & "," & TxtKelipatan.Text & "," & TxtDelay.Text & ",'" & TxtBeratMin.Text & "','" & TxtBeratMax.Text & "')"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil disimpan", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataModel()")
        End Try
    End Sub

    Private Sub UpdateDataModel()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setmodel SET model='" & TxtModel.Text & "', target=" & TxtTarget.Text & ",plan=" & TxtPlan.Text & ",kelipatan=" & TxtKelipatan.Text & ",delay=" & TxtDelay.Text & ",minberat='" & TxtBeratMin.Text & "',maxberat='" & TxtBeratMax.Text & "' WHERE id='" & TxtIDModel.Text & "'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateDataModel()")
        End Try
    End Sub
    Private Sub DeleteModel()
        Try
            Dim result As DialogResult = MessageBox.Show("Confirm Delete?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

            If (result = DialogResult.Yes) Then
                ConnectMySQL()

                Dim hapus As String = "DELETE FROM setmodel WHERE id='" & TxtIDModel.Text & "'"
                CMD = New OdbcCommand(hapus, CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Data berhasil dihapus", vbInformation, "Informasi")
                LoadDataAll()
                KosongkanTextbox()
                KondisiDelete()
            Else
                'Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error DeleteModel()")
        End Try
    End Sub

#End Region

#Region "Kondisi TextBox"
    Private Sub KosongkanTextbox()
        TxtModel.Clear()
        TxtTarget.Clear()
        TxtPlan.Clear()
        TxtKelipatan.Clear()
        TxtDelay.Clear()
        TxtBeratMin.Clear()
        TxtBeratMax.Clear()
    End Sub
    Private Sub EnabledTextBox(ByVal tf As Boolean)
        TxtModel.Enabled = tf
        TxtTarget.Enabled = tf
        TxtPlan.Enabled = tf
        TxtKelipatan.Enabled = tf
        TxtDelay.Enabled = tf
        TxtBeratMin.Enabled = tf
        TxtBeratMax.Enabled = tf
    End Sub
    Private Sub KondisiAdd()
        KosongkanTextbox()
        EnabledTextBox(True)
        BtnAdd.Enabled = False
        BtnSave.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiSave()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiEdit()
        EnabledTextBox(True)
        BtnSave.Enabled = True
        BtnAdd.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiCancel()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiDelete()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
#End Region
    Private Sub DGVModel_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVModel.CellContentClick
        If DGVModel.ColumnCount = 9 Then
            TxtModel.Text = DGVModel.Rows(e.RowIndex).Cells.Item("model").Value
            TxtTarget.Text = DGVModel.Rows(e.RowIndex).Cells.Item("target").Value
            TxtPlan.Text = DGVModel.Rows(e.RowIndex).Cells.Item("plan").Value
            TxtKelipatan.Text = DGVModel.Rows(e.RowIndex).Cells.Item("kelipatan").Value
            TxtDelay.Text = DGVModel.Rows(e.RowIndex).Cells.Item("delay").Value
            TxtBeratMin.Text = DGVModel.Rows(e.RowIndex).Cells.Item("minberat").Value
            TxtBeratMax.Text = DGVModel.Rows(e.RowIndex).Cells.Item("maxberat").Value
            TxtIDModel.Text = DGVModel.Rows(e.RowIndex).Cells.Item("id").Value
            BtnEdit.Enabled = True
            BtnDelete.Enabled = True
            statusdata = "edit"
        Else
            Exit Sub
        End If
    End Sub


#Region "Button Action"
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        statusdata = "add"
        KondisiAdd()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        DeleteModel()
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        statusdata = "edit"
        KondisiEdit()
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        KondisiCancel()
    End Sub

    Private Sub BtnShowAll_Click(sender As Object, e As EventArgs) Handles BtnShowAll.Click
        LoadDataAll()
    End Sub

    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If TxtFind.TextLength = 0 Then
            Exit Sub
        End If
        FindModel()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If statusdata = "edit" Then
            UpdateDataModel()
        Else
            CekDataSebelumSimpan()
        End If
        KondisiSave()
    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub FormModel_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
    End Sub
#End Region

End Class