﻿Imports MySql.Data.MySqlClient
Public Class UCMonitor


    Private Sub AmbilDataMonitoring(ByVal nomormesin As String)



        'Dim connect As New MySqlConnection("Server=localhost; user=root; password=; database=produk")

        'connect.Open()

        'Dim sqlcmd As New MySqlCommand("SELECT * FROM monitoring WHERE nomesin='" & nomormesin & "'")
        'Dim sqladapter As New MySqlDataAdapter(sqlcmd, connect)
        'Dim dt As New DataTable
        'sqladapter.Fill(dt)

        ''Datagridview1.Datasource = dt
        'lblnomesin.Text = dt.Rows(0).Item("nomesin")
        'lbltanggal.Text = dt.Rows(0).Item("tgl")
        'lblhari.Text = dt.Rows(0).Item("hari")
        'lblmodel.Text = dt.Rows(0).Item("model")
        'lbltarget.Text = dt.Rows(0).Item("target")
        'lblaktual.Text = dt.Rows(0).Item("aktual")
        'lblefisiensi.Text = dt.Rows(0).Item("efisiensi")
        'lblstatus.Text = dt.Rows(0).Item("status")

        'connect.Close()




    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If lagikirimdatakeserver = False Then
            AmbilDataMonitoring("M01")
        End If
    End Sub

    Private Sub UCMonitor_Load(sender As Object, e As EventArgs) Handles Me.Load
        Timer1.Start()
    End Sub
End Class
