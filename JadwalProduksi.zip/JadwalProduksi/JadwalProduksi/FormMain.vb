﻿Imports System.Data.Odbc
'Imports FireSharp.Config
'Imports FireSharp.Response
'Imports FireSharp.Interfaces
'Imports System.Threading.Tasks
'Imports Newtonsoft.Json
Public Class FormMain
    Dim alamatpage As String = "http://localhost/monitoringcounter/monitoring.php"
    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ReLoad()
    End Sub
    Private Sub ReLoad()
        getLevelUser()
        AmbilSettinganArduino()
        If setArduinoAktif = 1 Then
            Me.Text = "FormMain" & " - Selamat Datang " & namauser & " - Arduino available"
        Else
            Me.Text = "FormMain" & " - Selamat Datang " & namauser & " - Arduino isn't available !"
        End If
        'KonekFireBase()
        xwaktutrial = My.Settings.waktutrial
        xhitungmundur = My.Settings.hitungmundur
        TimerTrial.Start()

        If My.Settings.serialnumber <> "SMD7-9UIK-VB85" Then
            'Lblpesan.Visible = True
            'Lblpesan.Text = "You're in Trial Version"
            'Lblpesan.Text = "Trial Version"
        End If

        If leveluser = "Admin" Then
            BtnMonitoring.Enabled = True
            BtnSetting.Enabled = True
            BtnIstirahat.Enabled = True
            BtnModel.Enabled = True
            BtnUser.Enabled = True
            BtnLine.Enabled = True
            BtnWeb.Enabled = True
        Else
            BtnMonitoring.Enabled = False
            BtnSetting.Enabled = False
            BtnIstirahat.Enabled = False
            BtnModel.Enabled = False
            BtnUser.Enabled = False
            BtnLine.Enabled = False
            BtnWeb.Enabled = False
        End If
    End Sub
    Private Sub getLevelUser()
        Try
            ConnectMySQL()
            CMD = New OdbcCommand("SELECT * FROM user WHERE iduser='" & iduser & "' ", CONN)
            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                Exit Sub
                MsgBox("tidak ada level untuk user ini " & iduser & " !! ",
                       MsgBoxStyle.Exclamation, "Error Login")
            Else
                leveluser = DR.Item("level").ToString
                namauser = DR.Item("namauser").ToString
                'MsgBox("Level anda adalah : " & leveluser)
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error getLevelUser")
        End Try
    End Sub

    Private Sub BtnDisplay_Click(sender As Object, e As EventArgs) Handles BtnDisplay.Click
        FormDisplay.Show()
        Me.Hide()
    End Sub

    Private Sub BtnSetting_Click(sender As Object, e As EventArgs) Handles BtnSetting.Click
        FormSetting.Show()
        Me.Hide()
    End Sub

    Private Sub BtnMaster_Click(sender As Object, e As EventArgs) Handles BtnModel.Click
        FormModel.Show()
        Me.Hide()
    End Sub

    Private Sub BtnReport_Click(sender As Object, e As EventArgs) Handles BtnReport.Click
        FormReport.Show()
        Me.Hide()
    End Sub

    Private Sub BtnIstirahat_Click(sender As Object, e As EventArgs) Handles BtnIstirahat.Click
        FormIstirahat.Show()
        Me.Hide()
    End Sub

    Private Sub BtnLine_Click(sender As Object, e As EventArgs) Handles BtnLine.Click
        FormLine.Show()
        Me.Hide()
    End Sub

    Private Sub FormMain_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        UpdateKondisiMesin("Tidak", My.Settings.nomesin)
        My.Settings.hitungmundur = xhitungmundur
        My.Settings.Save()
        My.Settings.waktutrial = xwaktutrial - xhitungmundur
        My.Settings.Save()
        TimerTrial.Stop()
        End
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        FormLogin.PasswordTextBox.Clear()
        FormLogin.UserIDTextBox.Clear()
        FormLogin.Show()
        Me.Hide()
    End Sub

    Private Sub BtnUser_Click(sender As Object, e As EventArgs) Handles BtnUser.Click
        FormUser.Show()
        Me.Hide()
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        End
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click

    End Sub

#Region "FB"
    'Private fcon As New FirebaseConfig() With
    '    {
    '    .AuthSecret = "6H47RPs1niSveGhmHv84SvdxLSVpcVZ5ly5WjJLp",
    '    .BasePath = "https://monitoring-86863-default-rtdb.firebaseio.com/"
    '    }
    'Private client As IFirebaseClient
    'Private Sub KonekFireBase()
    '    Try
    '        'Me.Text = "https://monitoring-86863-default-rtdb.firebaseio.com/"
    '        client = New FireSharp.FirebaseClient(fcon)
    '        LiveCall()
    '    Catch ex As Exception
    '        MessageBox.Show("Ada masalah dengan koneksi server ?")
    '    End Try
    'End Sub

    'Private Async Sub LiveCall()
    '    Try
    '        While True
    '            Await Task.Delay(600)
    '            Dim res As FirebaseResponse = Await client.GetAsync("aplikasi")
    '            Dim data As Dictionary(Of String, String) = JsonConvert.DeserializeObject(Of Dictionary(Of String, String))(res.Body.ToString)
    '            UpdateAplikasi(data)
    '        End While
    '    Catch ex As Exception
    '        MessageBox.Show("Ada masalah dengan koneksi server ??")
    '    End Try

    'End Sub
    Private Sub UpdateAplikasi(ByVal records As Dictionary(Of String, String))
        aktivasinya = records.ElementAt(0).Value
        Lblaktivasi.Text = "Aktivasi :" & records.ElementAt(0).Value
        displaynya = records.ElementAt(1).Value
        Lblpesan.Text = records.ElementAt(2).Value

        If displaynya = False Then
            BtnDisplay.Enabled = False
        Else
            BtnDisplay.Enabled = True
        End If

        If aktivasinya = False Then
            Lblpesan.Visible = True
        Else
            Lblpesan.Visible = False
        End If
    End Sub
#End Region


#Region "Trial"
    Private Sub TimerTrial_Tick(sender As Object, e As EventArgs) Handles TimerTrial.Tick
        'xhitungmundur += 1
        'If xhitungmundur >= xwaktutrial Then
        '    MsgBox("Waktu Trial Habis , silahkan upgrade ke versi penuh!")
        'Else
        '    Me.Lblpesan.Text = "You're in Trial Version [" & xwaktutrial - xhitungmundur & "]"
        'End If
    End Sub

    Private Sub BtnMonitoring_Click(sender As Object, e As EventArgs) Handles BtnMonitoring.Click
        FormMonitor.Show()
        Me.Hide()
    End Sub

    Private Sub FormMain_VisibleChanged(sender As Object, e As EventArgs) Handles Me.VisibleChanged
        If Me.Visible = True Then
            ReLoad()
        End If
    End Sub

    Private Sub BtnWeb_Click(sender As Object, e As EventArgs) Handles BtnWeb.Click
        Try
            Process.Start(alamatpage)
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error membuka file monitoring.php")
        End Try
    End Sub
#End Region

End Class