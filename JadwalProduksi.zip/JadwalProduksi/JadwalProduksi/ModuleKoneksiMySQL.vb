﻿Imports System.Data.Odbc

Module ModuleKoneksiMySQL
    Public CONNMonitoring As OdbcConnection
    Public DAMonitoring As OdbcDataAdapter
    Public DSMonitoring As DataSet
    Public CMDMonitoring As OdbcCommand
    Public DRMonitoring As OdbcDataReader
    Public Sub ConnectMySQLMonitoring()
        ''CONN = New OdbcConnection("dsn=KoneksiProduk")
        CONNMonitoring = New OdbcConnection("dsn=koneksiproduk32bitMonitoring")
        CONNMonitoring.Open()
    End Sub
End Module
