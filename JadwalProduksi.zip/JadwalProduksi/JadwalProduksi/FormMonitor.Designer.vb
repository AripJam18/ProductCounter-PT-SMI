﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMonitor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMonitor))
        Me.TLP1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblhari1 = New System.Windows.Forms.Label()
        Me.lblmodel1 = New System.Windows.Forms.Label()
        Me.lbltarget1 = New System.Windows.Forms.Label()
        Me.lblaktual1 = New System.Windows.Forms.Label()
        Me.lbltanggal1 = New System.Windows.Forms.Label()
        Me.lblefisiensi1 = New System.Windows.Forms.Label()
        Me.lblstatus1 = New System.Windows.Forms.Label()
        Me.TimerMonitoring = New System.Windows.Forms.Timer(Me.components)
        Me.BtnCloseTimbanganConfig = New System.Windows.Forms.Button()
        Me.TLP2 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblhari2 = New System.Windows.Forms.Label()
        Me.lblmodel2 = New System.Windows.Forms.Label()
        Me.lbltarget2 = New System.Windows.Forms.Label()
        Me.lblaktual2 = New System.Windows.Forms.Label()
        Me.lbltanggal2 = New System.Windows.Forms.Label()
        Me.lblefisiensi2 = New System.Windows.Forms.Label()
        Me.lblstatus2 = New System.Windows.Forms.Label()
        Me.TLP3 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin3 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblhari3 = New System.Windows.Forms.Label()
        Me.lblmodel3 = New System.Windows.Forms.Label()
        Me.lbltarget3 = New System.Windows.Forms.Label()
        Me.lblaktual3 = New System.Windows.Forms.Label()
        Me.lbltanggal3 = New System.Windows.Forms.Label()
        Me.lblefisiensi3 = New System.Windows.Forms.Label()
        Me.lblstatus3 = New System.Windows.Forms.Label()
        Me.TLP4 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin4 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblhari4 = New System.Windows.Forms.Label()
        Me.lblmodel4 = New System.Windows.Forms.Label()
        Me.lbltarget4 = New System.Windows.Forms.Label()
        Me.lblaktual4 = New System.Windows.Forms.Label()
        Me.lbltanggal4 = New System.Windows.Forms.Label()
        Me.lblefisiensi4 = New System.Windows.Forms.Label()
        Me.lblstatus4 = New System.Windows.Forms.Label()
        Me.TLP5 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin5 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblhari5 = New System.Windows.Forms.Label()
        Me.lblmodel5 = New System.Windows.Forms.Label()
        Me.lbltarget5 = New System.Windows.Forms.Label()
        Me.lblaktual5 = New System.Windows.Forms.Label()
        Me.lbltanggal5 = New System.Windows.Forms.Label()
        Me.lblefisiensi5 = New System.Windows.Forms.Label()
        Me.lblstatus5 = New System.Windows.Forms.Label()
        Me.TLP6 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin6 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.lblhari6 = New System.Windows.Forms.Label()
        Me.lblmodel6 = New System.Windows.Forms.Label()
        Me.lbltarget6 = New System.Windows.Forms.Label()
        Me.lblaktual6 = New System.Windows.Forms.Label()
        Me.lbltanggal6 = New System.Windows.Forms.Label()
        Me.lblefisiensi6 = New System.Windows.Forms.Label()
        Me.lblstatus6 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.Led6 = New System.Windows.Forms.PictureBox()
        Me.Led5 = New System.Windows.Forms.PictureBox()
        Me.Led4 = New System.Windows.Forms.PictureBox()
        Me.Led3 = New System.Windows.Forms.PictureBox()
        Me.Led2 = New System.Windows.Forms.PictureBox()
        Me.BtnMain = New System.Windows.Forms.Button()
        Me.Led1 = New System.Windows.Forms.PictureBox()
        Me.TLP1.SuspendLayout()
        Me.TLP2.SuspendLayout()
        Me.TLP3.SuspendLayout()
        Me.TLP4.SuspendLayout()
        Me.TLP5.SuspendLayout()
        Me.TLP6.SuspendLayout()
        CType(Me.Led6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TLP1
        '
        Me.TLP1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP1.ColumnCount = 3
        Me.TLP1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP1.Controls.Add(Me.Led1, 0, 0)
        Me.TLP1.Controls.Add(Me.lblnomesin1, 1, 0)
        Me.TLP1.Controls.Add(Me.Label2, 0, 1)
        Me.TLP1.Controls.Add(Me.Label3, 0, 2)
        Me.TLP1.Controls.Add(Me.Label4, 0, 3)
        Me.TLP1.Controls.Add(Me.Label5, 0, 4)
        Me.TLP1.Controls.Add(Me.lblhari1, 1, 1)
        Me.TLP1.Controls.Add(Me.lblmodel1, 1, 2)
        Me.TLP1.Controls.Add(Me.lbltarget1, 1, 3)
        Me.TLP1.Controls.Add(Me.lblaktual1, 1, 4)
        Me.TLP1.Controls.Add(Me.lbltanggal1, 2, 1)
        Me.TLP1.Controls.Add(Me.lblefisiensi1, 2, 2)
        Me.TLP1.Controls.Add(Me.lblstatus1, 2, 0)
        Me.TLP1.Location = New System.Drawing.Point(12, 12)
        Me.TLP1.Name = "TLP1"
        Me.TLP1.RowCount = 5
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP1.Size = New System.Drawing.Size(329, 226)
        Me.TLP1.TabIndex = 1
        '
        'lblnomesin1
        '
        Me.lblnomesin1.AutoSize = True
        Me.lblnomesin1.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin1.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin1.Name = "lblnomesin1"
        Me.lblnomesin1.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin1.TabIndex = 0
        Me.lblnomesin1.Text = "NomorMesin"
        Me.lblnomesin1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 38)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Hari / Tgl"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Silver
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 40)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Model"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Silver
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(4, 142)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 44)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Target"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Silver
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 187)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 38)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Aktual"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari1
        '
        Me.lblhari1.AutoSize = True
        Me.lblhari1.BackColor = System.Drawing.Color.Silver
        Me.lblhari1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari1.Location = New System.Drawing.Point(86, 62)
        Me.lblhari1.Name = "lblhari1"
        Me.lblhari1.Size = New System.Drawing.Size(85, 38)
        Me.lblhari1.TabIndex = 5
        Me.lblhari1.Text = "hari"
        Me.lblhari1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel1
        '
        Me.lblmodel1.AutoSize = True
        Me.lblmodel1.BackColor = System.Drawing.Color.Silver
        Me.lblmodel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel1.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel1.Name = "lblmodel1"
        Me.lblmodel1.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel1.TabIndex = 6
        Me.lblmodel1.Text = "model"
        Me.lblmodel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget1
        '
        Me.lbltarget1.AutoSize = True
        Me.lbltarget1.BackColor = System.Drawing.Color.Silver
        Me.lbltarget1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget1.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget1.Name = "lbltarget1"
        Me.lbltarget1.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget1.TabIndex = 7
        Me.lbltarget1.Text = "target"
        Me.lbltarget1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual1
        '
        Me.lblaktual1.AutoSize = True
        Me.lblaktual1.BackColor = System.Drawing.Color.Silver
        Me.lblaktual1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual1.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual1.Name = "lblaktual1"
        Me.lblaktual1.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual1.TabIndex = 8
        Me.lblaktual1.Text = "aktual"
        Me.lblaktual1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal1
        '
        Me.lbltanggal1.AutoSize = True
        Me.lbltanggal1.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal1.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal1.Name = "lbltanggal1"
        Me.lbltanggal1.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal1.TabIndex = 9
        Me.lbltanggal1.Text = "tanggal"
        Me.lbltanggal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi1
        '
        Me.lblefisiensi1.AutoSize = True
        Me.lblefisiensi1.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi1.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi1.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi1.Name = "lblefisiensi1"
        Me.TLP1.SetRowSpan(Me.lblefisiensi1, 3)
        Me.lblefisiensi1.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi1.TabIndex = 10
        Me.lblefisiensi1.Text = "Efisiensi"
        Me.lblefisiensi1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus1
        '
        Me.lblstatus1.AutoSize = True
        Me.lblstatus1.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus1.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus1.Name = "lblstatus1"
        Me.lblstatus1.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus1.TabIndex = 11
        Me.lblstatus1.Text = "status"
        Me.lblstatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TimerMonitoring
        '
        Me.TimerMonitoring.Interval = 1000
        '
        'BtnCloseTimbanganConfig
        '
        Me.BtnCloseTimbanganConfig.BackColor = System.Drawing.Color.Red
        Me.BtnCloseTimbanganConfig.FlatAppearance.BorderSize = 0
        Me.BtnCloseTimbanganConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseTimbanganConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseTimbanganConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseTimbanganConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseTimbanganConfig.ForeColor = System.Drawing.Color.White
        Me.BtnCloseTimbanganConfig.Location = New System.Drawing.Point(106, 526)
        Me.BtnCloseTimbanganConfig.Name = "BtnCloseTimbanganConfig"
        Me.BtnCloseTimbanganConfig.Size = New System.Drawing.Size(83, 38)
        Me.BtnCloseTimbanganConfig.TabIndex = 58
        Me.BtnCloseTimbanganConfig.Text = "CLOSE"
        Me.BtnCloseTimbanganConfig.UseVisualStyleBackColor = False
        '
        'TLP2
        '
        Me.TLP2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP2.ColumnCount = 3
        Me.TLP2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP2.Controls.Add(Me.Led2, 0, 0)
        Me.TLP2.Controls.Add(Me.lblnomesin2, 1, 0)
        Me.TLP2.Controls.Add(Me.Label6, 0, 1)
        Me.TLP2.Controls.Add(Me.Label7, 0, 2)
        Me.TLP2.Controls.Add(Me.Label8, 0, 3)
        Me.TLP2.Controls.Add(Me.Label9, 0, 4)
        Me.TLP2.Controls.Add(Me.lblhari2, 1, 1)
        Me.TLP2.Controls.Add(Me.lblmodel2, 1, 2)
        Me.TLP2.Controls.Add(Me.lbltarget2, 1, 3)
        Me.TLP2.Controls.Add(Me.lblaktual2, 1, 4)
        Me.TLP2.Controls.Add(Me.lbltanggal2, 2, 1)
        Me.TLP2.Controls.Add(Me.lblefisiensi2, 2, 2)
        Me.TLP2.Controls.Add(Me.lblstatus2, 2, 0)
        Me.TLP2.Location = New System.Drawing.Point(357, 13)
        Me.TLP2.Name = "TLP2"
        Me.TLP2.RowCount = 5
        Me.TLP2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP2.Size = New System.Drawing.Size(329, 226)
        Me.TLP2.TabIndex = 60
        '
        'lblnomesin2
        '
        Me.lblnomesin2.AutoSize = True
        Me.lblnomesin2.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin2.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin2.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin2.Name = "lblnomesin2"
        Me.lblnomesin2.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin2.TabIndex = 0
        Me.lblnomesin2.Text = "NomorMesin"
        Me.lblnomesin2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Silver
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 62)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 38)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Hari / Tgl"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Silver
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(4, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 40)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Model"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Silver
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 142)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 44)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Target"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Silver
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(4, 187)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 38)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Aktual"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari2
        '
        Me.lblhari2.AutoSize = True
        Me.lblhari2.BackColor = System.Drawing.Color.Silver
        Me.lblhari2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari2.Location = New System.Drawing.Point(86, 62)
        Me.lblhari2.Name = "lblhari2"
        Me.lblhari2.Size = New System.Drawing.Size(85, 38)
        Me.lblhari2.TabIndex = 5
        Me.lblhari2.Text = "hari"
        Me.lblhari2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel2
        '
        Me.lblmodel2.AutoSize = True
        Me.lblmodel2.BackColor = System.Drawing.Color.Silver
        Me.lblmodel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel2.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel2.Name = "lblmodel2"
        Me.lblmodel2.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel2.TabIndex = 6
        Me.lblmodel2.Text = "model"
        Me.lblmodel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget2
        '
        Me.lbltarget2.AutoSize = True
        Me.lbltarget2.BackColor = System.Drawing.Color.Silver
        Me.lbltarget2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget2.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget2.Name = "lbltarget2"
        Me.lbltarget2.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget2.TabIndex = 7
        Me.lbltarget2.Text = "target"
        Me.lbltarget2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual2
        '
        Me.lblaktual2.AutoSize = True
        Me.lblaktual2.BackColor = System.Drawing.Color.Silver
        Me.lblaktual2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual2.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual2.Name = "lblaktual2"
        Me.lblaktual2.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual2.TabIndex = 8
        Me.lblaktual2.Text = "aktual"
        Me.lblaktual2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal2
        '
        Me.lbltanggal2.AutoSize = True
        Me.lbltanggal2.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal2.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal2.Name = "lbltanggal2"
        Me.lbltanggal2.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal2.TabIndex = 9
        Me.lbltanggal2.Text = "tanggal"
        Me.lbltanggal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi2
        '
        Me.lblefisiensi2.AutoSize = True
        Me.lblefisiensi2.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi2.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi2.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi2.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi2.Name = "lblefisiensi2"
        Me.TLP2.SetRowSpan(Me.lblefisiensi2, 3)
        Me.lblefisiensi2.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi2.TabIndex = 10
        Me.lblefisiensi2.Text = "Efisiensi"
        Me.lblefisiensi2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus2
        '
        Me.lblstatus2.AutoSize = True
        Me.lblstatus2.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus2.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus2.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus2.Name = "lblstatus2"
        Me.lblstatus2.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus2.TabIndex = 11
        Me.lblstatus2.Text = "status"
        Me.lblstatus2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP3
        '
        Me.TLP3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP3.ColumnCount = 3
        Me.TLP3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP3.Controls.Add(Me.Led3, 0, 0)
        Me.TLP3.Controls.Add(Me.lblnomesin3, 1, 0)
        Me.TLP3.Controls.Add(Me.Label18, 0, 1)
        Me.TLP3.Controls.Add(Me.Label19, 0, 2)
        Me.TLP3.Controls.Add(Me.Label20, 0, 3)
        Me.TLP3.Controls.Add(Me.Label21, 0, 4)
        Me.TLP3.Controls.Add(Me.lblhari3, 1, 1)
        Me.TLP3.Controls.Add(Me.lblmodel3, 1, 2)
        Me.TLP3.Controls.Add(Me.lbltarget3, 1, 3)
        Me.TLP3.Controls.Add(Me.lblaktual3, 1, 4)
        Me.TLP3.Controls.Add(Me.lbltanggal3, 2, 1)
        Me.TLP3.Controls.Add(Me.lblefisiensi3, 2, 2)
        Me.TLP3.Controls.Add(Me.lblstatus3, 2, 0)
        Me.TLP3.Location = New System.Drawing.Point(702, 14)
        Me.TLP3.Name = "TLP3"
        Me.TLP3.RowCount = 5
        Me.TLP3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP3.Size = New System.Drawing.Size(329, 226)
        Me.TLP3.TabIndex = 61
        '
        'lblnomesin3
        '
        Me.lblnomesin3.AutoSize = True
        Me.lblnomesin3.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin3.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin3.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin3.Name = "lblnomesin3"
        Me.lblnomesin3.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin3.TabIndex = 0
        Me.lblnomesin3.Text = "NomorMesin"
        Me.lblnomesin3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Silver
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label18.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(4, 62)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(75, 38)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Hari / Tgl"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Silver
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label19.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(4, 101)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 40)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Model"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Silver
        Me.Label20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label20.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(4, 142)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(75, 44)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Target"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Silver
        Me.Label21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label21.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(4, 187)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 38)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "Aktual"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari3
        '
        Me.lblhari3.AutoSize = True
        Me.lblhari3.BackColor = System.Drawing.Color.Silver
        Me.lblhari3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari3.Location = New System.Drawing.Point(86, 62)
        Me.lblhari3.Name = "lblhari3"
        Me.lblhari3.Size = New System.Drawing.Size(85, 38)
        Me.lblhari3.TabIndex = 5
        Me.lblhari3.Text = "hari"
        Me.lblhari3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel3
        '
        Me.lblmodel3.AutoSize = True
        Me.lblmodel3.BackColor = System.Drawing.Color.Silver
        Me.lblmodel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel3.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel3.Name = "lblmodel3"
        Me.lblmodel3.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel3.TabIndex = 6
        Me.lblmodel3.Text = "model"
        Me.lblmodel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget3
        '
        Me.lbltarget3.AutoSize = True
        Me.lbltarget3.BackColor = System.Drawing.Color.Silver
        Me.lbltarget3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget3.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget3.Name = "lbltarget3"
        Me.lbltarget3.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget3.TabIndex = 7
        Me.lbltarget3.Text = "target"
        Me.lbltarget3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual3
        '
        Me.lblaktual3.AutoSize = True
        Me.lblaktual3.BackColor = System.Drawing.Color.Silver
        Me.lblaktual3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual3.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual3.Name = "lblaktual3"
        Me.lblaktual3.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual3.TabIndex = 8
        Me.lblaktual3.Text = "aktual"
        Me.lblaktual3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal3
        '
        Me.lbltanggal3.AutoSize = True
        Me.lbltanggal3.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal3.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal3.Name = "lbltanggal3"
        Me.lbltanggal3.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal3.TabIndex = 9
        Me.lbltanggal3.Text = "tanggal"
        Me.lbltanggal3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi3
        '
        Me.lblefisiensi3.AutoSize = True
        Me.lblefisiensi3.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi3.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi3.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi3.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi3.Name = "lblefisiensi3"
        Me.TLP3.SetRowSpan(Me.lblefisiensi3, 3)
        Me.lblefisiensi3.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi3.TabIndex = 10
        Me.lblefisiensi3.Text = "Efisiensi"
        Me.lblefisiensi3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus3
        '
        Me.lblstatus3.AutoSize = True
        Me.lblstatus3.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus3.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus3.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus3.Name = "lblstatus3"
        Me.lblstatus3.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus3.TabIndex = 11
        Me.lblstatus3.Text = "status"
        Me.lblstatus3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP4
        '
        Me.TLP4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP4.ColumnCount = 3
        Me.TLP4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP4.Controls.Add(Me.lblnomesin4, 1, 0)
        Me.TLP4.Controls.Add(Me.Label10, 0, 1)
        Me.TLP4.Controls.Add(Me.Label11, 0, 2)
        Me.TLP4.Controls.Add(Me.Label12, 0, 3)
        Me.TLP4.Controls.Add(Me.Label13, 0, 4)
        Me.TLP4.Controls.Add(Me.lblhari4, 1, 1)
        Me.TLP4.Controls.Add(Me.lblmodel4, 1, 2)
        Me.TLP4.Controls.Add(Me.lbltarget4, 1, 3)
        Me.TLP4.Controls.Add(Me.lblaktual4, 1, 4)
        Me.TLP4.Controls.Add(Me.lbltanggal4, 2, 1)
        Me.TLP4.Controls.Add(Me.lblefisiensi4, 2, 2)
        Me.TLP4.Controls.Add(Me.lblstatus4, 2, 0)
        Me.TLP4.Controls.Add(Me.Led4, 0, 0)
        Me.TLP4.Location = New System.Drawing.Point(12, 281)
        Me.TLP4.Name = "TLP4"
        Me.TLP4.RowCount = 5
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP4.Size = New System.Drawing.Size(329, 226)
        Me.TLP4.TabIndex = 62
        '
        'lblnomesin4
        '
        Me.lblnomesin4.AutoSize = True
        Me.lblnomesin4.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin4.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin4.Name = "lblnomesin4"
        Me.lblnomesin4.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin4.TabIndex = 0
        Me.lblnomesin4.Text = "NomorMesin"
        Me.lblnomesin4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Silver
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 62)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 38)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Hari / Tgl"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Silver
        Me.Label11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(4, 101)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 40)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Model"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Silver
        Me.Label12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(4, 142)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 44)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Target"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Silver
        Me.Label13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(4, 187)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(75, 38)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Aktual"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari4
        '
        Me.lblhari4.AutoSize = True
        Me.lblhari4.BackColor = System.Drawing.Color.Silver
        Me.lblhari4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari4.Location = New System.Drawing.Point(86, 62)
        Me.lblhari4.Name = "lblhari4"
        Me.lblhari4.Size = New System.Drawing.Size(85, 38)
        Me.lblhari4.TabIndex = 5
        Me.lblhari4.Text = "hari"
        Me.lblhari4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel4
        '
        Me.lblmodel4.AutoSize = True
        Me.lblmodel4.BackColor = System.Drawing.Color.Silver
        Me.lblmodel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel4.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel4.Name = "lblmodel4"
        Me.lblmodel4.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel4.TabIndex = 6
        Me.lblmodel4.Text = "model"
        Me.lblmodel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget4
        '
        Me.lbltarget4.AutoSize = True
        Me.lbltarget4.BackColor = System.Drawing.Color.Silver
        Me.lbltarget4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget4.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget4.Name = "lbltarget4"
        Me.lbltarget4.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget4.TabIndex = 7
        Me.lbltarget4.Text = "target"
        Me.lbltarget4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual4
        '
        Me.lblaktual4.AutoSize = True
        Me.lblaktual4.BackColor = System.Drawing.Color.Silver
        Me.lblaktual4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual4.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual4.Name = "lblaktual4"
        Me.lblaktual4.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual4.TabIndex = 8
        Me.lblaktual4.Text = "aktual"
        Me.lblaktual4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal4
        '
        Me.lbltanggal4.AutoSize = True
        Me.lbltanggal4.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal4.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal4.Name = "lbltanggal4"
        Me.lbltanggal4.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal4.TabIndex = 9
        Me.lbltanggal4.Text = "tanggal"
        Me.lbltanggal4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi4
        '
        Me.lblefisiensi4.AutoSize = True
        Me.lblefisiensi4.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi4.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi4.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi4.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi4.Name = "lblefisiensi4"
        Me.TLP4.SetRowSpan(Me.lblefisiensi4, 3)
        Me.lblefisiensi4.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi4.TabIndex = 10
        Me.lblefisiensi4.Text = "Efisiensi"
        Me.lblefisiensi4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus4
        '
        Me.lblstatus4.AutoSize = True
        Me.lblstatus4.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus4.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus4.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus4.Name = "lblstatus4"
        Me.lblstatus4.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus4.TabIndex = 11
        Me.lblstatus4.Text = "status"
        Me.lblstatus4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP5
        '
        Me.TLP5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP5.ColumnCount = 3
        Me.TLP5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP5.Controls.Add(Me.Led5, 0, 0)
        Me.TLP5.Controls.Add(Me.lblnomesin5, 1, 0)
        Me.TLP5.Controls.Add(Me.Label26, 0, 1)
        Me.TLP5.Controls.Add(Me.Label27, 0, 2)
        Me.TLP5.Controls.Add(Me.Label28, 0, 3)
        Me.TLP5.Controls.Add(Me.Label29, 0, 4)
        Me.TLP5.Controls.Add(Me.lblhari5, 1, 1)
        Me.TLP5.Controls.Add(Me.lblmodel5, 1, 2)
        Me.TLP5.Controls.Add(Me.lbltarget5, 1, 3)
        Me.TLP5.Controls.Add(Me.lblaktual5, 1, 4)
        Me.TLP5.Controls.Add(Me.lbltanggal5, 2, 1)
        Me.TLP5.Controls.Add(Me.lblefisiensi5, 2, 2)
        Me.TLP5.Controls.Add(Me.lblstatus5, 2, 0)
        Me.TLP5.Location = New System.Drawing.Point(357, 280)
        Me.TLP5.Name = "TLP5"
        Me.TLP5.RowCount = 5
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP5.Size = New System.Drawing.Size(329, 226)
        Me.TLP5.TabIndex = 63
        '
        'lblnomesin5
        '
        Me.lblnomesin5.AutoSize = True
        Me.lblnomesin5.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin5.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin5.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin5.Name = "lblnomesin5"
        Me.lblnomesin5.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin5.TabIndex = 0
        Me.lblnomesin5.Text = "NomorMesin"
        Me.lblnomesin5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Silver
        Me.Label26.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label26.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(4, 62)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(75, 38)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Hari / Tgl"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Silver
        Me.Label27.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(4, 101)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(75, 40)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = "Model"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Silver
        Me.Label28.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label28.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 142)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(75, 44)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "Target"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Silver
        Me.Label29.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label29.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 187)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(75, 38)
        Me.Label29.TabIndex = 4
        Me.Label29.Text = "Aktual"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari5
        '
        Me.lblhari5.AutoSize = True
        Me.lblhari5.BackColor = System.Drawing.Color.Silver
        Me.lblhari5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari5.Location = New System.Drawing.Point(86, 62)
        Me.lblhari5.Name = "lblhari5"
        Me.lblhari5.Size = New System.Drawing.Size(85, 38)
        Me.lblhari5.TabIndex = 5
        Me.lblhari5.Text = "hari"
        Me.lblhari5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel5
        '
        Me.lblmodel5.AutoSize = True
        Me.lblmodel5.BackColor = System.Drawing.Color.Silver
        Me.lblmodel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel5.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel5.Name = "lblmodel5"
        Me.lblmodel5.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel5.TabIndex = 6
        Me.lblmodel5.Text = "model"
        Me.lblmodel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget5
        '
        Me.lbltarget5.AutoSize = True
        Me.lbltarget5.BackColor = System.Drawing.Color.Silver
        Me.lbltarget5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget5.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget5.Name = "lbltarget5"
        Me.lbltarget5.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget5.TabIndex = 7
        Me.lbltarget5.Text = "target"
        Me.lbltarget5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual5
        '
        Me.lblaktual5.AutoSize = True
        Me.lblaktual5.BackColor = System.Drawing.Color.Silver
        Me.lblaktual5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual5.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual5.Name = "lblaktual5"
        Me.lblaktual5.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual5.TabIndex = 8
        Me.lblaktual5.Text = "aktual"
        Me.lblaktual5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal5
        '
        Me.lbltanggal5.AutoSize = True
        Me.lbltanggal5.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal5.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal5.Name = "lbltanggal5"
        Me.lbltanggal5.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal5.TabIndex = 9
        Me.lbltanggal5.Text = "tanggal"
        Me.lbltanggal5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi5
        '
        Me.lblefisiensi5.AutoSize = True
        Me.lblefisiensi5.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi5.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi5.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi5.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi5.Name = "lblefisiensi5"
        Me.TLP5.SetRowSpan(Me.lblefisiensi5, 3)
        Me.lblefisiensi5.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi5.TabIndex = 10
        Me.lblefisiensi5.Text = "Efisiensi"
        Me.lblefisiensi5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus5
        '
        Me.lblstatus5.AutoSize = True
        Me.lblstatus5.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus5.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus5.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus5.Name = "lblstatus5"
        Me.lblstatus5.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus5.TabIndex = 11
        Me.lblstatus5.Text = "status"
        Me.lblstatus5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP6
        '
        Me.TLP6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP6.ColumnCount = 3
        Me.TLP6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TLP6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TLP6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 152.0!))
        Me.TLP6.Controls.Add(Me.Led6, 0, 0)
        Me.TLP6.Controls.Add(Me.lblnomesin6, 1, 0)
        Me.TLP6.Controls.Add(Me.Label38, 0, 1)
        Me.TLP6.Controls.Add(Me.Label39, 0, 2)
        Me.TLP6.Controls.Add(Me.Label40, 0, 3)
        Me.TLP6.Controls.Add(Me.Label41, 0, 4)
        Me.TLP6.Controls.Add(Me.lblhari6, 1, 1)
        Me.TLP6.Controls.Add(Me.lblmodel6, 1, 2)
        Me.TLP6.Controls.Add(Me.lbltarget6, 1, 3)
        Me.TLP6.Controls.Add(Me.lblaktual6, 1, 4)
        Me.TLP6.Controls.Add(Me.lbltanggal6, 2, 1)
        Me.TLP6.Controls.Add(Me.lblefisiensi6, 2, 2)
        Me.TLP6.Controls.Add(Me.lblstatus6, 2, 0)
        Me.TLP6.Location = New System.Drawing.Point(702, 279)
        Me.TLP6.Name = "TLP6"
        Me.TLP6.RowCount = 5
        Me.TLP6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TLP6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TLP6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TLP6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TLP6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TLP6.Size = New System.Drawing.Size(329, 226)
        Me.TLP6.TabIndex = 64
        '
        'lblnomesin6
        '
        Me.lblnomesin6.AutoSize = True
        Me.lblnomesin6.BackColor = System.Drawing.Color.LightCoral
        Me.lblnomesin6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin6.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin6.Location = New System.Drawing.Point(86, 1)
        Me.lblnomesin6.Name = "lblnomesin6"
        Me.lblnomesin6.Size = New System.Drawing.Size(85, 60)
        Me.lblnomesin6.TabIndex = 0
        Me.lblnomesin6.Text = "NomorMesin"
        Me.lblnomesin6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Silver
        Me.Label38.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label38.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(4, 62)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(75, 38)
        Me.Label38.TabIndex = 1
        Me.Label38.Text = "Hari / Tgl"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BackColor = System.Drawing.Color.Silver
        Me.Label39.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label39.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(4, 101)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(75, 40)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "Model"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Silver
        Me.Label40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label40.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(4, 142)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(75, 44)
        Me.Label40.TabIndex = 3
        Me.Label40.Text = "Target"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Silver
        Me.Label41.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label41.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(4, 187)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(75, 38)
        Me.Label41.TabIndex = 4
        Me.Label41.Text = "Aktual"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari6
        '
        Me.lblhari6.AutoSize = True
        Me.lblhari6.BackColor = System.Drawing.Color.Silver
        Me.lblhari6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari6.Location = New System.Drawing.Point(86, 62)
        Me.lblhari6.Name = "lblhari6"
        Me.lblhari6.Size = New System.Drawing.Size(85, 38)
        Me.lblhari6.TabIndex = 5
        Me.lblhari6.Text = "hari"
        Me.lblhari6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel6
        '
        Me.lblmodel6.AutoSize = True
        Me.lblmodel6.BackColor = System.Drawing.Color.Silver
        Me.lblmodel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel6.Location = New System.Drawing.Point(86, 101)
        Me.lblmodel6.Name = "lblmodel6"
        Me.lblmodel6.Size = New System.Drawing.Size(85, 40)
        Me.lblmodel6.TabIndex = 6
        Me.lblmodel6.Text = "model"
        Me.lblmodel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget6
        '
        Me.lbltarget6.AutoSize = True
        Me.lbltarget6.BackColor = System.Drawing.Color.Silver
        Me.lbltarget6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget6.Location = New System.Drawing.Point(86, 142)
        Me.lbltarget6.Name = "lbltarget6"
        Me.lbltarget6.Size = New System.Drawing.Size(85, 44)
        Me.lbltarget6.TabIndex = 7
        Me.lbltarget6.Text = "target"
        Me.lbltarget6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual6
        '
        Me.lblaktual6.AutoSize = True
        Me.lblaktual6.BackColor = System.Drawing.Color.Silver
        Me.lblaktual6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual6.Location = New System.Drawing.Point(86, 187)
        Me.lblaktual6.Name = "lblaktual6"
        Me.lblaktual6.Size = New System.Drawing.Size(85, 38)
        Me.lblaktual6.TabIndex = 8
        Me.lblaktual6.Text = "aktual"
        Me.lblaktual6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal6
        '
        Me.lbltanggal6.AutoSize = True
        Me.lbltanggal6.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal6.Location = New System.Drawing.Point(178, 62)
        Me.lbltanggal6.Name = "lbltanggal6"
        Me.lbltanggal6.Size = New System.Drawing.Size(147, 38)
        Me.lbltanggal6.TabIndex = 9
        Me.lbltanggal6.Text = "tanggal"
        Me.lbltanggal6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi6
        '
        Me.lblefisiensi6.AutoSize = True
        Me.lblefisiensi6.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi6.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi6.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi6.Location = New System.Drawing.Point(178, 101)
        Me.lblefisiensi6.Name = "lblefisiensi6"
        Me.TLP6.SetRowSpan(Me.lblefisiensi6, 3)
        Me.lblefisiensi6.Size = New System.Drawing.Size(147, 124)
        Me.lblefisiensi6.TabIndex = 10
        Me.lblefisiensi6.Text = "Efisiensi"
        Me.lblefisiensi6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus6
        '
        Me.lblstatus6.AutoSize = True
        Me.lblstatus6.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus6.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus6.Location = New System.Drawing.Point(178, 1)
        Me.lblstatus6.Name = "lblstatus6"
        Me.lblstatus6.Size = New System.Drawing.Size(147, 60)
        Me.lblstatus6.TabIndex = 11
        Me.lblstatus6.Text = "status"
        Me.lblstatus6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'Timer3
        '
        Me.Timer3.Interval = 500
        '
        'Timer4
        '
        Me.Timer4.Interval = 500
        '
        'Timer5
        '
        Me.Timer5.Interval = 500
        '
        'Timer6
        '
        Me.Timer6.Interval = 500
        '
        'Led6
        '
        Me.Led6.BackColor = System.Drawing.Color.White
        Me.Led6.Image = CType(resources.GetObject("Led6.Image"), System.Drawing.Image)
        Me.Led6.Location = New System.Drawing.Point(4, 4)
        Me.Led6.Name = "Led6"
        Me.Led6.Size = New System.Drawing.Size(75, 54)
        Me.Led6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led6.TabIndex = 66
        Me.Led6.TabStop = False
        Me.Led6.Visible = False
        '
        'Led5
        '
        Me.Led5.BackColor = System.Drawing.Color.White
        Me.Led5.Image = CType(resources.GetObject("Led5.Image"), System.Drawing.Image)
        Me.Led5.Location = New System.Drawing.Point(4, 4)
        Me.Led5.Name = "Led5"
        Me.Led5.Size = New System.Drawing.Size(75, 54)
        Me.Led5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led5.TabIndex = 66
        Me.Led5.TabStop = False
        Me.Led5.Visible = False
        '
        'Led4
        '
        Me.Led4.BackColor = System.Drawing.Color.White
        Me.Led4.Image = CType(resources.GetObject("Led4.Image"), System.Drawing.Image)
        Me.Led4.Location = New System.Drawing.Point(4, 4)
        Me.Led4.Name = "Led4"
        Me.Led4.Size = New System.Drawing.Size(75, 54)
        Me.Led4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led4.TabIndex = 65
        Me.Led4.TabStop = False
        Me.Led4.Visible = False
        '
        'Led3
        '
        Me.Led3.BackColor = System.Drawing.Color.White
        Me.Led3.Image = CType(resources.GetObject("Led3.Image"), System.Drawing.Image)
        Me.Led3.Location = New System.Drawing.Point(4, 4)
        Me.Led3.Name = "Led3"
        Me.Led3.Size = New System.Drawing.Size(75, 54)
        Me.Led3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led3.TabIndex = 66
        Me.Led3.TabStop = False
        Me.Led3.Visible = False
        '
        'Led2
        '
        Me.Led2.BackColor = System.Drawing.Color.White
        Me.Led2.Image = CType(resources.GetObject("Led2.Image"), System.Drawing.Image)
        Me.Led2.Location = New System.Drawing.Point(4, 4)
        Me.Led2.Name = "Led2"
        Me.Led2.Size = New System.Drawing.Size(75, 54)
        Me.Led2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led2.TabIndex = 66
        Me.Led2.TabStop = False
        Me.Led2.Visible = False
        '
        'BtnMain
        '
        Me.BtnMain.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnMain.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnMain.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.BtnMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray
        Me.BtnMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMain.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMain.ForeColor = System.Drawing.Color.White
        Me.BtnMain.Image = Global.JadwalProduksi.My.Resources.Resources.b_home
        Me.BtnMain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnMain.Location = New System.Drawing.Point(13, 526)
        Me.BtnMain.Name = "BtnMain"
        Me.BtnMain.Size = New System.Drawing.Size(83, 38)
        Me.BtnMain.TabIndex = 59
        Me.BtnMain.Text = "Main"
        Me.BtnMain.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnMain.UseVisualStyleBackColor = False
        '
        'Led1
        '
        Me.Led1.BackColor = System.Drawing.Color.White
        Me.Led1.Image = CType(resources.GetObject("Led1.Image"), System.Drawing.Image)
        Me.Led1.Location = New System.Drawing.Point(4, 4)
        Me.Led1.Name = "Led1"
        Me.Led1.Size = New System.Drawing.Size(75, 54)
        Me.Led1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Led1.TabIndex = 66
        Me.Led1.TabStop = False
        Me.Led1.Visible = False
        '
        'FormMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1043, 576)
        Me.Controls.Add(Me.TLP6)
        Me.Controls.Add(Me.TLP5)
        Me.Controls.Add(Me.TLP4)
        Me.Controls.Add(Me.TLP3)
        Me.Controls.Add(Me.TLP2)
        Me.Controls.Add(Me.BtnMain)
        Me.Controls.Add(Me.BtnCloseTimbanganConfig)
        Me.Controls.Add(Me.TLP1)
        Me.Name = "FormMonitor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FormMonitor"
        Me.TLP1.ResumeLayout(False)
        Me.TLP1.PerformLayout()
        Me.TLP2.ResumeLayout(False)
        Me.TLP2.PerformLayout()
        Me.TLP3.ResumeLayout(False)
        Me.TLP3.PerformLayout()
        Me.TLP4.ResumeLayout(False)
        Me.TLP4.PerformLayout()
        Me.TLP5.ResumeLayout(False)
        Me.TLP5.PerformLayout()
        Me.TLP6.ResumeLayout(False)
        Me.TLP6.PerformLayout()
        CType(Me.Led6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TLP1 As TableLayoutPanel
    Friend WithEvents lblnomesin1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblhari1 As Label
    Friend WithEvents lblmodel1 As Label
    Friend WithEvents lbltarget1 As Label
    Friend WithEvents lblaktual1 As Label
    Friend WithEvents lbltanggal1 As Label
    Friend WithEvents lblefisiensi1 As Label
    Friend WithEvents lblstatus1 As Label
    Friend WithEvents TimerMonitoring As Timer
    Friend WithEvents BtnCloseTimbanganConfig As Button
    Friend WithEvents BtnMain As Button
    Friend WithEvents TLP2 As TableLayoutPanel
    Friend WithEvents lblnomesin2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblhari2 As Label
    Friend WithEvents lblmodel2 As Label
    Friend WithEvents lbltarget2 As Label
    Friend WithEvents lblaktual2 As Label
    Friend WithEvents lbltanggal2 As Label
    Friend WithEvents lblefisiensi2 As Label
    Friend WithEvents lblstatus2 As Label
    Friend WithEvents TLP3 As TableLayoutPanel
    Friend WithEvents lblnomesin3 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents lblhari3 As Label
    Friend WithEvents lblmodel3 As Label
    Friend WithEvents lbltarget3 As Label
    Friend WithEvents lblaktual3 As Label
    Friend WithEvents lbltanggal3 As Label
    Friend WithEvents lblefisiensi3 As Label
    Friend WithEvents lblstatus3 As Label
    Friend WithEvents TLP4 As TableLayoutPanel
    Friend WithEvents lblnomesin4 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblhari4 As Label
    Friend WithEvents lblmodel4 As Label
    Friend WithEvents lbltarget4 As Label
    Friend WithEvents lblaktual4 As Label
    Friend WithEvents lbltanggal4 As Label
    Friend WithEvents lblefisiensi4 As Label
    Friend WithEvents lblstatus4 As Label
    Friend WithEvents TLP5 As TableLayoutPanel
    Friend WithEvents lblnomesin5 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents lblhari5 As Label
    Friend WithEvents lblmodel5 As Label
    Friend WithEvents lbltarget5 As Label
    Friend WithEvents lblaktual5 As Label
    Friend WithEvents lbltanggal5 As Label
    Friend WithEvents lblefisiensi5 As Label
    Friend WithEvents lblstatus5 As Label
    Friend WithEvents TLP6 As TableLayoutPanel
    Friend WithEvents lblnomesin6 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents lblhari6 As Label
    Friend WithEvents lblmodel6 As Label
    Friend WithEvents lbltarget6 As Label
    Friend WithEvents lblaktual6 As Label
    Friend WithEvents lbltanggal6 As Label
    Friend WithEvents lblefisiensi6 As Label
    Friend WithEvents lblstatus6 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Timer4 As Timer
    Friend WithEvents Timer5 As Timer
    Friend WithEvents Timer6 As Timer
    Friend WithEvents Led4 As PictureBox
    Friend WithEvents Led1 As PictureBox
    Friend WithEvents Led2 As PictureBox
    Friend WithEvents Led3 As PictureBox
    Friend WithEvents Led5 As PictureBox
    Friend WithEvents Led6 As PictureBox
End Class
