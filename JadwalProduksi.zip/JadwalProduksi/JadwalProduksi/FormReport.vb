﻿Imports System.Data.Odbc
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel
Public Class FormReport
    Dim lokasi As String
    Dim namafile As String
    Private Sub BtnTampil_Click(sender As Object, e As EventArgs) Handles BtnTampil.Click
        TampilGrid()
    End Sub

    Sub TampilGrid()
        ConnectMySQL()
        'DA = New OdbcDataAdapter("SELECT ROW_NUMBER() OVER(ORDER BY idreport) AS No, SUBSTRING(tanggal, 1,10) as Tanggal, model as Model, qty as QTY, start as Start,stop as Stop,workhours as Workhours, efisiensi as Efisiensi FROM report WHERE tanggal >= '" & Format(DTPFrom.Value, "yyyy-MM-dd") & "' AND tanggal <= '" & Format(DTPTo.Value, "yyyy-MM-dd") & "' ", CONN)
        DA = New OdbcDataAdapter("SELECT ROW_NUMBER() OVER(ORDER BY idreport) AS No, SUBSTRING(tanggal, 1,10) as Tanggal, model as Model, qty as QTY, start as Start,stop as Stop,workhours as Workhours, efisiensi as Efisiensi , line as Line FROM report WHERE  CONVERT(tanggal, DATE) between '" & Format(DTPFrom.Value, "yyyy-MM-dd") & "' AND '" & Format(DTPTo.Value, "yyyy-MM-dd") & "' ", CONN)
        ''LIMIT 10 
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True
        LblJumlahData.Text = "Jumlah Data : " & DGV.Rows.Count
    End Sub



#Region "Export Report"
    Private Sub BtnExport_Click(sender As Object, e As EventArgs) Handles BtnExport.Click
        Dim xlApp As Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value

        'Dim i As Int16, j As Int16

        xlApp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")

        For a = 0 To DGV.RowCount - 1
            For b = 0 To DGV.ColumnCount - 1
                For c As Integer = 1 To DGV.Columns.Count
                    xlWorkSheet.Cells(1, c) = DGV.Columns(c - 1).HeaderText
                    xlWorkSheet.Cells(a + 2, b + 1) = DGV(b, a).Value.ToString()
                Next
            Next
        Next

        'If Directory.Exists(lokasi) = False Then
        '    Directory.CreateDirectory(lokasi)
        'End If

        namafile = Format(Date.Today, "yyyy-MM-dd").ToString

        SaveFileDialog1.Filter = "Microsoft Excel|*.xls"
        SaveFileDialog1.FileName = namafile
        SaveFileDialog1.AddExtension = True

        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            lokasi = SaveFileDialog1.FileName
            namafile = lokasi
        Else
            Exit Sub
        End If








        xlWorkBook.SaveAs(namafile, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
         Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue)
        xlWorkBook.Close(True, misValue, misValue)
        xlApp.Quit()

        releaseObject(xlWorkSheet)
        releaseObject(xlWorkBook)
        releaseObject(xlApp)








        MsgBox("Hasil export tersimpan di " & lokasi)

        If pesanTanya("Open File?") = True Then
            Process.Start(namafile)
        End If

    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Public Function pesanTanya(ByVal isiTanya As String, Optional ByVal yesbocancel As Boolean = False) As Object
        Dim strTanya As String

        If yesbocancel = False Then
            strTanya = MsgBox(isiTanya, vbQuestion + vbYesNo, "Question?")
            If strTanya = vbYes Then
                Return True
            Else
                Return False
            End If
        Else
            strTanya = MsgBox(isiTanya, vbQuestion + vbYesNoCancel, "Question?")
            If strTanya = vbYes Then
                Return vbYes
            ElseIf strTanya = vbNo Then
                Return vbNo
            Else
                Return vbCancel
            End If
        End If
    End Function

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub FormReport_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
    End Sub

#End Region








End Class