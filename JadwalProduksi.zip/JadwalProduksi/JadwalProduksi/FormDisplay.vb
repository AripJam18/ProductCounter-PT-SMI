﻿Imports System.ComponentModel
Imports System.Threading
Imports System.Threading.Tasks
Imports System.IO
Imports System.IO.Ports
Imports System.Data.Odbc

Public Class FormDisplay
    Private myCoolPoint As New Point
    'settingan biar panel gk flicker
    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.ExStyle = cp.ExStyle Or &H2000000
            Return cp
        End Get
    End Property
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        ReLoad()
    End Sub
    Private Sub FormDisplay_VisibleChanged(sender As Object, e As EventArgs) Handles Me.VisibleChanged
        GetSettinganAwal()
        SettingWarnaTampilan()
        setNomorMesin = My.Settings.nomesin
        setLine = My.Settings.line
        CekStatusLine("M01")
        CekStatusLine("M02")
        CekStatusLine("M03")
        CekStatusLine("M04")
        CekStatusLine("M05")
        CekStatusLine("M06")
        'If leveluser = "admin" Then
        '    PanelSetting.Visible = False
        'Else
        '    PanelSetting.Visible = True
        'End If

        If baruLoad = True Then
            aktual = 0
        Else
            aktual = aktual
            If setToDisplay = True Then
                CheckEfisiensiPerPenambahanAktual()
                LblAktual.Text = aktual
                LblTarget.Text = targetygselalubertambah
            Else
                LblAktual.Text = LblAktual.Text
                LblTarget.Text = LblTarget.Text
            End If
        End If

        Me.Text = "Product Counter " & minweight & " ~ " & maxweight & " , Waktu Kerja = (" & xDurasiMenitTanpaPotonganIstirahat & " - " & xDurasiPotongIstirahat & ") , Efisiensi = " & aktual & " / " & TargetRealtime & " * 100 " & "A [" & PotonganWaktuOpening & "," & PotonganWaktuIstirahat1 & "," & PotonganWaktuIstirahat2 & "," & PotonganWaktuIstirahat2Jumat & "," & PotonganWaktuIstirahat3 & "," & PotonganWaktuClosing & "," & PotonganWaktuIstirahatClosingJumat & "," & PotonganWaktuIstirahatLembur1 & "," & PotonganWaktuIstirahatLembur1Jumat & "," & PotonganWaktuIstirahatLembur2 & "," & PotonganWaktuIstirahatLembur3 & "]" & " Lembur :" & SetLemburShift1 & "  [" & day & "] - " & setNomorMesin
        If setArduinoAktif = 1 Then
            ConnectArduino()
        End If
    End Sub

    Private Sub ReLoad()
        Me.WindowState = FormWindowState.Maximized
        LblEfisiensi.Text = ""
        DisconnectTimbangan()
        GetSettinganAwal()
        SettingWarnaTampilan()
        setNomorMesin = My.Settings.nomesin
        setLine = My.Settings.line
        CekStatusLine("M01")
        CekStatusLine("M02")
        CekStatusLine("M03")
        CekStatusLine("M04")
        CekStatusLine("M05")
        CekStatusLine("M06")
        TimerWaktu.Start()
        TimerRealtimeRunningText.Start()
        BtnStop.Enabled = False
        BtnConnectTimbangan.Enabled = True

        LblAktual.Text = "0"
        aktual = 0
        baruLoad = True

        'If leveluser <> "Admin" Then
        '    PanelSetting.Visible = False
        'Else
        '    PanelSetting.Visible = True
        'End If

        Me.Text = "Product Counter " & minweight & " ~ " & maxweight & " , Waktu Kerja = (" & xDurasiMenitTanpaPotonganIstirahat & " - " & xDurasiPotongIstirahat & ") , Efisiensi = " & aktual & " / " & TargetRealtime & " * 100 " & "A [" & PotonganWaktuOpening & "," & PotonganWaktuIstirahat1 & "," & PotonganWaktuIstirahat2 & "," & PotonganWaktuIstirahat2Jumat & "," & PotonganWaktuIstirahat3 & "," & PotonganWaktuClosing & "," & PotonganWaktuIstirahatClosingJumat & "," & PotonganWaktuIstirahatLembur1 & "," & PotonganWaktuIstirahatLembur1Jumat & "," & PotonganWaktuIstirahatLembur2 & "," & PotonganWaktuIstirahatLembur3 & "]" & " Lembur :" & SetLemburShift1 & "  [" & day & "] - " & setNomorMesin
        If setArduinoAktif = 1 Then
            ConnectArduino()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles TimerWaktu.Tick
        tambahjammanual = False
        Ambiltargetterbaru(setNomorMesin)
        If setToDisplay = True Then
            LblAktual.Text = aktual
            LblTarget.Text = targetygselalubertambah
        Else
            LblAktual.Text = LblAktual.Text
            LblTarget.Text = LblTarget.Text
        End If
        dayofweek = Today.DayOfWeek
        ConvertDay()
        LblDate.Text = Today
        LblTime.Text = TimeOfDay.ToString("HH\:mm\:ss")
        LblTime.TextAlign = ContentAlignment.MiddleCenter
        ''MULAI
        If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatOpening Then
            'MsgBox("Waktunya Istirahat Pagi", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Pagi"
            PlayBelInstirahat()
        End If
        If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahat1 Then
            'MsgBox("Waktunya Istirahat Pagi", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Pagi"
            PlayBelInstirahat()
        End If
        If day = "JUMAT" Then
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahat2Jumat Then
                'MsgBox("Waktunya Istirahat Siang", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Istirahat Siang"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatClosingJumat Then
                'MsgBox("Waktunya Istirahat Siang", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Closing"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatLembur1Jumat Then
                'MsgBox("Waktunya Istirahat Lembur", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Istirahat Lembur"
                PlayBelInstirahat()
            End If
        Else
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahat2 Then
                'MsgBox("Waktunya Istirahat Siang", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Istirahat Siang"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatClosing Then
                'MsgBox("Waktunya Istirahat Siang", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Closing"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatLembur1 Then
                'MsgBox("Waktunya Istirahat Sore", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktunya Istirahat Sore"
                PlayBelInstirahat()
            End If
        End If

        If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatLembur2 Then
            'MsgBox("Waktunya Istirahat Sore", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Sore"
            PlayBelInstirahat()
        End If

        If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahatLembur3 Then
            'MsgBox("Waktunya Istirahat Sore", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Sore"
            PlayBelInstirahat()
        End If


        If TimeOfDay.ToString("HH\:mm\:ss") = MulaiIstirahat3 Then
            'MsgBox("Waktunya Istirahat Pagi", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat 3"
            PlayBelInstirahat()
        End If


        ''SELESAI
        If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatOpening Then
            'MsgBox("Waktu Istirahat Pagi Selesai", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktu Istirahat Pagi Selesai"
            PlayBelInstirahat()
        End If
        If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahat1 Then
            'MsgBox("Waktu Istirahat Pagi Selesai", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktu Istirahat Pagi Selesai"
            PlayBelInstirahat()
        End If

        If day = "JUMAT" Then
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahat2Jumat Then
                'MsgBox("Waktu Istirahat Siang Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Siang Selesai"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatClosingJumat Then
                'MsgBox("Waktu Istirahat Siang Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Siang Selesai"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatLembur1Jumat Then
                'MsgBox("Waktu Istirahat Lembur  Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Lembur Selesai"
                PlayBelInstirahat()
            End If
        Else
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahat2 Then
                'MsgBox("Waktu Istirahat Siang Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Siang Selesai"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatClosing Then
                'MsgBox("Waktu Istirahat Siang Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Siang Selesai"
                PlayBelInstirahat()
            End If
            If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatLembur1 Then
                'MsgBox("Waktu Istirahat Lembur  Selesai", MsgBoxStyle.Information, "Informasi")
                'LblRunningText.Text = "Waktu Istirahat Lembur Selesai"
                PlayBelInstirahat()
            End If
        End If
        If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatLembur2 Then
            'MsgBox("Waktunya Istirahat Sore", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Sore"
            PlayBelInstirahat()
        End If

        If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahatLembur3 Then
            'MsgBox("Waktunya Istirahat Sore", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktunya Istirahat Sore"
            PlayBelInstirahat()
        End If

        If TimeOfDay.ToString("HH\:mm\:ss") = SelesaiIstirahat3 Then
            'MsgBox("Waktu Istirahat Sore Selesai", MsgBoxStyle.Information, "Informasi")
            'LblRunningText.Text = "Waktu Istirahat Sore Selesai"
            PlayBelInstirahat()
        End If


        ''diawal jam kerja target selalu nol (0) baru setelah itu muncul target aktual sesuai jam dan nanti bertambah setiap jam
        ''berarti haru ada fungsi untuk memeriksa apakah sudah start atau belum.
        Ambiltargetterbaru(setNomorMesin)
        Cekkondisimesinterbaru()
    End Sub
    Private Sub ConvertDay()
        If dayofweek = 1 Then
            day = "SENIN"
        ElseIf dayofweek = 2 Then
            day = "SELASA"
        ElseIf dayofweek = 3 Then
            day = "RABU"
        ElseIf dayofweek = 4 Then
            day = "KAMIS"
        ElseIf dayofweek = 5 Then
            day = "JUMAT"
        ElseIf dayofweek = 6 Then
            day = "SABTU"
        ElseIf dayofweek = 7 Then
            day = "MINGGU"
        End If

        LblDay.Text = day
    End Sub

    Private Sub tambahaktual()
        Try
            If setToDisplay = True Then
                Dim resultmenit As String()
                resultmenit = Split(StartTimeUntukDiAdjust, ":")
                MenitStart = resultmenit(1)
                If Strings.Left(MenitStart, 1) = "0" Then
                    MenitStart = Strings.Right(MenitStart, 1)
                End If
            Else
                MenitStart = TimeOfDay.Minute.ToString
            End If

            JamStop = TimeOfDay.Hour.ToString
            If JamStop.Length = 1 Then
                JamStop = "0" & JamStop
            End If
            MenitStop = TimeOfDay.Minute.ToString
            If MenitStop.Length = 1 Then
                MenitStop = "0" & MenitStop
            End If
            DetikStop = TimeOfDay.Second.ToString
            If DetikStop.Length = 1 Then
                DetikStop = "0" & DetikStop
            End If
            WaktuStop = JamStop & ":" & MenitStop & ":" & DetikStop
            'WaktuStop = LblTime.Text
            aktual = CInt(LblAktual.Text)
            aktual += setMultiple

            ''cek ulang multiple kadang suka ada penambahan 1 pcs harusnya kelipatan 5 dan 13 dst
            If setMultiple = 5 Then
                Dim angkasisa As Integer
                angkasisa = aktual Mod setMultiple

                If angkasisa <> 0 Then
                    aktual -= angkasisa
                End If
            End If

            LblAktual.Text = aktual
            PlayTimbanganOk()
            CheckEfisiensiPerPenambahanAktual()

            UpdateAktualTerbaru(aktual, setNomorMesin)

            Me.Text = "Product Counter " & minweight & " ~ " & maxweight & " , Waktu Kerja = (" & xDurasiMenitTanpaPotonganIstirahat & " - " & xDurasiPotongIstirahat & ") , Efisiensi = " & aktual & " / " & TargetRealtime & " * 100 " & "A [" & PotonganWaktuOpening & "," & PotonganWaktuIstirahat1 & "," & PotonganWaktuIstirahat2 & "," & PotonganWaktuIstirahat2Jumat & "," & PotonganWaktuIstirahat3 & "," & PotonganWaktuClosing & "," & PotonganWaktuIstirahatClosingJumat & "," & PotonganWaktuIstirahatLembur1 & "," & PotonganWaktuIstirahatLembur1Jumat & "," & PotonganWaktuIstirahatLembur2 & "," & PotonganWaktuIstirahatLembur3 & "]" & " Lembur :" & SetLemburShift1 & "  [" & day & "] - " & setNomorMesin
            'BtnStop.Enabled = True
            updatemonitoring(setNomorMesin)
            InsertDataReportAwal()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error tambah aktual")
        End Try
    End Sub
    Private Sub updatemonitoring(ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE monitoring SET tgl='" & Format(Date.Today, "yyyy-MM-dd") & "',hari='" & LblDay.Text & "',model='" & LblModel.Text & "',target='" & LblTarget.Text & "',aktual='" & LblAktual.Text & "',efisiensi='" & LblEfisiensi.Text & "'  WHERE nomesin='" & nomesin & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'If FormSetting.Visible = True Then
            '    MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            'End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error updatemonitoring()")
        End Try
    End Sub
    Private Sub updatemonitoringSTART(ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE monitoring SET  status='ON'  WHERE nomesin='" & nomesin & "'"
            'tgl='2023-10-10',hari='0',model='0',target='0',aktual='0',efisiensi='0' ,
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'If FormSetting.Visible = True Then
            '    MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            'End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error updatemonitoring()")
        End Try
    End Sub
    Private Sub updatemonitoringSTOP(ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE monitoring SET status='OFF'  WHERE nomesin='" & nomesin & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'If FormSetting.Visible = True Then
            '    MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            'End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error updatemonitoring()")
        End Try
    End Sub


    Sub PlayBelInstirahat()
        If setBelIstirahat = "On" Then
            My.Computer.Audio.Play(My.Resources.bel_istirahat, AudioPlayMode.Background)
        End If
    End Sub
    Sub PlayTimbanganOk()
        If setBelTimbang = "On" Then
            My.Computer.Audio.Play(My.Resources.right, AudioPlayMode.Background)
        End If
    End Sub
    Private Sub TimerAktual_Tick(sender As Object, e As EventArgs) Handles TimerAktual.Tick
        Try
            detikdelay += 1
            If detikdelay = setDelay Then
                tambahaktual()
            ElseIf detikdelay > setDelay Then
                TimerAktual.Stop()
                detikdelay = 0
            Else
                TimerAktual.Start()
            End If
            LblDelayDetik.Text = detikdelay

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Timer Aktual")
        End Try

    End Sub


#Region "Timbangan / Weight Scale"

    Dim myPort As Array
    Delegate Sub SetTextCallback(ByVal [text] As String)

    Private Sub SerialPortTimbangan_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPortTimbangan.DataReceived
        Try
            'ini fungsi untuk menerima data dari SerialPort1, ReadExisting adalah perintah untuk mengambil data setiap saat/setiap serailport1 mengirimkan data
            ReceivedText(SerialPortTimbangan.ReadExisting())
        Catch ex As Exception
            MsgBox("Connection Port Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error SerialPortTimbangan")
        End Try
    End Sub
    Private Sub ReceivedText(ByVal [text] As String)
        'fungsi untuk menerima data/inputan dari timbangan kali ini yang kita mabil data berupa text/string
        Try
            'compares the ID of the creating Thread to the ID of the calling Thread
            If Me.TxtRichTemp.InvokeRequired Then
                Dim x As New SetTextCallback(AddressOf ReceivedText)
                Me.Invoke(x, New Object() {(text)})
            Else
                Me.TxtRichTemp.Text &= [text]
            End If
        Catch ex As Exception
            'MsgBox("Connection Port Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error ReceivedText")
            DisconnectTimbangan()
        End Try
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorkerTimbangan.DoWork
        'mendefinisikan backgroundworker
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
        'memberikan ijin kepada sistem untuk mengeksekusi sebuah perintah ketika sedang menunggu/melooping perintah lain di saat yang sama
        Application.DoEvents()
        Try
            'memutus koneksi ke timbangan
            SerialPortTimbangan.Close()
        Catch ex As Exception
            MsgBox("BackgroundWoker Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'ketika form ditutup , nonaktifkan backgroundworker
        Try
            'SerialPortTimbangan.Close()
            'SerialPortArduino.Dispose()
            BackgroundWorkerTimbangan.Dispose()
            BackgroundWorkerArduino.Dispose()
            ''awal koding tambahan ini kodingannya sama dengan tombol stop
            If LblAktual.Text = "0" Then
                BtnPause.Enabled = False
                BtnStop.Enabled = False
                BtnTambahManual.Enabled = False
                BtnConnectTimbangan.Enabled = True
                LblTarget.Text = setTarget
                UpdateKondisiMesin("Tidak", setNomorMesin)
                updatemonitoringSTOP(setNomorMesin)
                Me.Hide()
                FormMain.Show()
                If SerialPortTimbangan.IsOpen Then
                    DisconnectTimbangan()
                    'SerialPortTimbangan.Close()
                    'SerialPortTimbangan.Dispose()
                End If
                Exit Sub
            End If
            JamStop = TimeOfDay.Hour.ToString
            MenitStop = TimeOfDay.Minute.ToString
            DetikStop = TimeOfDay.Second.ToString
            WaktuStop = JamStop & ":" & MenitStop & ":" & DetikStop
            setTarget = setTarget
            InsertDataReport()
            UpdateKondisiMesin("Tidak", setNomorMesin)
            updatemonitoringSTOP(setNomorMesin)
            'reset target , aktual dan starttime
            UpdateAktualTerbaru(0, setNomorMesin)
            UpdateTargetTerbaru(0, setNomorMesin)
            UpdateStartTimeTerbaru("08:00:00", setNomorMesin)
            BtnPause.Enabled = False
            DisconnectTimbangan()
            If SerialPortTimbangan.IsOpen Then
                DisconnectTimbangan()
            End If
            BtnTambahManual.Enabled = False
            ''akhir koding tambahan
            Me.Hide()
            FormMain.Show()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Me.FormClosing")
        End Try

    End Sub

    Private Sub ConnectTimbangan()
        Try
            'definisikan propertis port untuk melakukan koneksi
            SerialPortTimbangan.PortName = setComPort
            SerialPortTimbangan.BaudRate = setBrate '
            SerialPortTimbangan.Parity = IO.Ports.Parity.None
            SerialPortTimbangan.StopBits = IO.Ports.StopBits.One
            SerialPortTimbangan.DataBits = 8
            If SerialPortTimbangan.IsOpen Then
                DisconnectTimbangan()
                SerialPortTimbangan.Open()
            Else
                SerialPortTimbangan.Open()
            End If
        Catch ex As Exception
            MsgBox("Connection Port Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error ConnectTimbangan")
            SerialPortTimbangan.Open()
        End Try
    End Sub
    Private Sub DisconnectTimbangan()
        'cek jika backgroundworker tidak sedang sibuk maka lakukan RunWorkerAsync 
        If BackgroundWorkerTimbangan.IsBusy <> True Then
            BackgroundWorkerTimbangan.RunWorkerAsync()
        End If
    End Sub
#End Region

    Private Sub BtnStop_Click(sender As Object, e As EventArgs) Handles BtnStop.Click
        If LblAktual.Text = "0" Then
            BtnPause.Enabled = False
            BtnStop.Enabled = False
            BtnTambahManual.Enabled = False
            BtnConnectTimbangan.Enabled = True
            LblTarget.Text = setTarget
            UpdateKondisiMesin("Tidak", setNomorMesin)
            updatemonitoringSTOP(setNomorMesin)
            If SerialPortTimbangan.IsOpen Then
                DisconnectTimbangan()
                'SerialPortTimbangan.Close()
                'SerialPortTimbangan.Dispose()
            End If
            Exit Sub
        End If
        JamStop = TimeOfDay.Hour.ToString
        MenitStop = TimeOfDay.Minute.ToString
        DetikStop = TimeOfDay.Second.ToString
        WaktuStop = JamStop & ":" & MenitStop & ":" & DetikStop
        setTarget = setTarget
        InsertDataReport()
        If berhasilinsertatauupdatedata Then
            ''jika berhasil insert
            UpdateKondisiMesin("Tidak", setNomorMesin)
            updatemonitoringSTOP(setNomorMesin)
            'reset target , aktual dan starttime
            UpdateAktualTerbaru(0, setNomorMesin)
            UpdateTargetTerbaru(0, setNomorMesin)
            UpdateStartTimeTerbaru("08:00:00", setNomorMesin)
            BtnPause.Enabled = False
            DisconnectTimbangan()
            If SerialPortTimbangan.IsOpen Then
                DisconnectTimbangan()
            End If
            BtnTambahManual.Enabled = False
        End If
    End Sub

    Private Sub TxtBerat_TextChanged(sender As Object, e As EventArgs) Handles TxtBerat.TextChanged

        If CDbl(TxtBerat.Text >= minweight) And CDbl(TxtBerat.Text <= maxweight) Then
            TimerAktual.Start()
        Else
            detikdelay = 0
            LblDelayDetik.Text = detikdelay
            TimerAktual.Stop()
        End If

    End Sub
    Private Sub BtnSetting_Click(sender As Object, e As EventArgs) Handles BtnSetting.Click
        FormSetting.Show()
        klikapa = "setting"
        baruLoad = False
        Me.Hide()
    End Sub
    Private Sub PanggilUlangDataYangTelahTersimpan()
        Dim DAx As OdbcDataAdapter
        Dim DSx As DataSet
        Dim CMDx As OdbcCommand
        Dim DRx As OdbcDataReader

        Try

            ConnectMySQL()
            CMDx = New OdbcCommand("SELECT target , aktual , efisiensi FROM monitoring WHERE tgl='" & Format(Date.Today, "yyyy-MM-dd") & "' and nomesin='" & setNomorMesin & "' and model='" & setModel & "'", CONN)
            DRx = CMDx.ExecuteReader()
            DRx.Read()

            If DRx.HasRows = 0 Then
                CONN.Close()
                ApakahIniTargetJamPertama = True
                Konekdanaturtimbanganawal()
            Else
                Dim result As DialogResult = MessageBox.Show("Apakah ingin melanjutkan dari data sebelumnya ?",
                              "Product Counter",
                              MessageBoxButtons.YesNoCancel)

                If (result = DialogResult.Yes) Then
                    'ConnectMySQL()
                    'CMD = New OdbcCommand("SELECT target , aktual , efisiensi FROM monitoring WHERE tgl='" & Format(Date.Today, "yyyy-MM-dd") & "' and nomesin='" & setNomorMesin & "' and model='" & setModel & "'", CONN)
                    'DR = CMD.ExecuteReader()
                    'DR.Read()

                    targetFound = DRx.Item("target").ToString
                    aktualFound = DRx.Item("aktual").ToString
                    efisiensiFound = DRx.Item("efisiensi").ToString
                    WaktuStart = My.Settings.starttimeFound

                    aktual = CInt(DRx.Item("aktual"))
                    targetygselalubertambah = CInt(DRx.Item("target"))
                    setEfisiensi = CDbl(Strings.Replace(DRx.Item("efisiensi").ToString, "%", ""))

                    CONN.Close()

                    ApakahIniTargetJamPertama = False
                    BtnConnectTimbangan.Enabled = False
                    BtnStop.Enabled = True
                    BtnPause.Enabled = True

                    Dim timeArray() As String = Strings.Split(WaktuStart, ":")

                    JamStart = timeArray(0)
                    If JamStart.Length = 1 Then
                        JamStart = "0" & JamStart
                    End If
                    MenitStart = timeArray(1)
                    If MenitStart.Length = 1 Then
                        MenitStart = "0" & MenitStart
                    End If
                    DetikStart = timeArray(2)
                    If DetikStart.Length = 1 Then
                        DetikStart = "0" & DetikStart
                    End If
                    WaktuStart = JamStart & ":" & MenitStart & ":" & DetikStart
                    My.Settings.starttimeFound = WaktuStart
                    My.Settings.Save()
                    xStartTimeIdeal = JamStart & ":00:00"
                    ''ambil target aktual bukan target per Model

                    UpdateKondisiMesin("Ya", setNomorMesin)
                    UpdateStartTimeTerbaru(WaktuStart, setNomorMesin)
                    updatemonitoringSTART(setNomorMesin)
                    'setTarget = setTarget / 60 * (60 - CInt(MenitStart))
                    'UpdateTargetTerbaru(setTarget)
                    'LblTarget.Text = setTarget
                    'HitungTarget()
                    ApakahIniTargetJamPertama = False
                    BtnTambahManual.Enabled = True
                    BtnPause.PerformClick()
                    BtnContinue.PerformClick()
                    LblAktual.Text = aktualFound
                    LblTarget.Text = targetFound
                    LblEfisiensi.Text = efisiensiFound
                    targetygselalubertambah = targetFound
                    lanjutHitungdarisebelumnya = True
                ElseIf (result = DialogResult.no) Then
                    ApakahIniTargetJamPertama = True
                    Konekdanaturtimbanganawal()
                    lanjutHitungdarisebelumnya = False
                Else
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub Konekdanaturtimbanganawal()
        Try
            ApakahIniTargetJamPertama = True
            BtnConnectTimbangan.Enabled = False
            BtnStop.Enabled = True
            BtnPause.Enabled = True

            JamStart = TimeOfDay.Hour.ToString
            If JamStart.Length = 1 Then
                JamStart = "0" & JamStart
            End If
            MenitStart = TimeOfDay.Minute.ToString
            If MenitStart.Length = 1 Then
                MenitStart = "0" & MenitStart
            End If
            DetikStart = TimeOfDay.Second.ToString
            If DetikStart.Length = 1 Then
                DetikStart = "0" & DetikStart
            End If
            WaktuStart = JamStart & ":" & MenitStart & ":" & DetikStart
            My.Settings.starttimeFound = WaktuStart
            My.Settings.Save()
            xStartTimeIdeal = JamStart & ":00:00"
            ''ambil target aktual bukan target per Model

            UpdateKondisiMesin("Ya", setNomorMesin)
            UpdateStartTimeTerbaru(WaktuStart, setNomorMesin)
            updatemonitoringSTART(setNomorMesin)
            'setTarget = setTarget / 60 * (60 - CInt(MenitStart))
            'UpdateTargetTerbaru(setTarget)
            'LblTarget.Text = setTarget
            HitungTarget()
            ApakahIniTargetJamPertama = False
            BtnTambahManual.Enabled = True
            BtnPause.PerformClick()
            BtnContinue.PerformClick()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "BtnConnectTimbangan")
        End Try
    End Sub
    Private Sub BtnConnectTimbangan_Click(sender As Object, e As EventArgs) Handles BtnConnectTimbangan.Click
        PanggilUlangDataYangTelahTersimpan()
        'Konekdanaturtimbanganawal()
    End Sub
    Private Sub TxtRichTemp_TextChanged(sender As Object, e As EventArgs) Handles TxtRichTemp.TextChanged
        Try
            If TxtRichTemp.TextLength <= 0 Then
                Exit Sub
            End If
            If TxtRichTemp.Text = "=999.999(kg)" Then
                Exit Sub
            End If

            Dim textlength As Integer
            Dim tmpng As String
            textlength = TxtRichTemp.Lines.Count 'menghitung jumlah baris di rtbreceived
            If textlength >= 2 Then 'jika txtjumlah nilainya lebih besar dari 2 maka
                tmpng = Microsoft.VisualBasic.Mid(TxtRichTemp.Text, 1, 10) 'mengambil 10 karakter
                For Each c In tmpng
                    If Char.IsNumber(c) Then 'mengambil nilai angka 
                        TxtTampung1.Text &= c
                    End If
                Next
                If TxtTampung1.Text.Count >= 6 Then 'jika jumlah karakter lebih dari 6
                    TxtBerat.Text = FormatNumber(Val(TxtTampung1.Text) / 1000, 2)
                End If
                TxtTampung1.Clear()
                TxtTampung2.Clear()
                TxtRichTemp.Clear()
            End If
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, "TxtRichTemp.TextChanged", MsgBoxStyle.Exclamation)
            Exit Sub
        End Try
    End Sub

    Private Sub TimerRunningText_Tick_1(sender As Object, e As EventArgs) Handles TimerRunningText.Tick
        'If LblRunningText.Left >= Me.Width Then
        '    LblRunningText.Left = -LblRunningText.Width
        'Else
        '    LblRunningText.Left = LblRunningText.Left + 50
        'End If
        'MsgBox(LblRunningText.Left)

        If LblRunningText.Left > -(LblRunningText.Width) Then
            LblRunningText.Left = LblRunningText.Left - 50
        Else
            LblRunningText.Left = Me.Width
        End If



    End Sub

    Private Sub ResetAktual()
        Dim result As DialogResult = MessageBox.Show("Confirm reset?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

        If (result = DialogResult.Yes) Then
            LblAktual.Text = "0"
            aktual = 0
        Else
            'Nothing
        End If

    End Sub

    Private Sub FormDisplay_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        DisconnectTimbangan()
        If klikapa <> "setting" Then
            FormMain.Show()
            'Dim newForm As New FormMain
            'newForm.Show()
        End If
    End Sub

    Private Sub SettingWarnaTampilan()
        Try
            ''pewarnaan label
            LblAktual.ForeColor = ColorTranslator.FromHtml(warnaAktual)
            LblTarget.ForeColor = ColorTranslator.FromHtml(warnaTarget)
            LblModel.ForeColor = ColorTranslator.FromHtml(warnaModel)
            LblTime.ForeColor = ColorTranslator.FromHtml(warnaTime)
            LblDate.ForeColor = ColorTranslator.FromHtml(warnaDate)
            LblDay.ForeColor = ColorTranslator.FromHtml(warnaDay)
            LblJudulEfiseinsi.ForeColor = ColorTranslator.FromHtml(warnaJudul)
            LblJudulAktual.ForeColor = ColorTranslator.FromHtml(warnaJudul)
            LblJudulModel.ForeColor = ColorTranslator.FromHtml(warnaJudul)
            LblJudulTarget.ForeColor = ColorTranslator.FromHtml(warnaJudul)
            TableLayoutPanel1.BackColor = ColorTranslator.FromHtml(warnaBackground)
            PanelEfisensi.BackColor = ColorTranslator.FromHtml(warnaBackground)
            PanelPenutupRichTextBox.BackColor = ColorTranslator.FromHtml(warnaBackground)
            LblEfisiensi.ForeColor = ColorTranslator.FromHtml(warnaEfisiensi)
            ''setting timbangan
            setComPort = setComPort
            setBrate = setBrate
            setDelay = setDelay
            LblModel.Text = setModel
            ''setting model
            LblTarget.Text = setTarget
            setPlan = setPlan
            minweight = minweight
            maxweight = maxweight
            setMultiple = setMultiple
            ''setting runningtext
            setTampilkan = setTampilkan

            If setTampilkan = 1 Then
                LblRunningText.Visible = True
            Else
                LblRunningText.Visible = False
            End If
            setAnimasi = setAnimasi
            If setAnimasi = 1 Then
                TimerRunningText.Start()
            Else
                TimerRunningText.Stop()
            End If

            setBelIstirahat = setBelIstirahat
            setBelTimbang = setBelTimbang

            setRunningTextSpeed = setRunningTextSpeed
            TimerRunningText.Interval = setRunningTextSpeed
            LblRunningText.Font = New Font(setFontRunningText, setSizeFontRunningText, setStyleFontRunningText)

            LblRunningText.ForeColor = ColorTranslator.FromHtml(warnaRunningText)
            LblRunningText.Text = setisiRunningText

            ''setting huruf
            LblDay.Font = New Font(setFontDay, setSizeFontDay, setStyleFontDay)
            LblDate.Font = New Font(setFontDate, setSizeFontDate, setStyleFontDate)
            LblTime.Font = New Font(setFontTime, setSizeFontTime, setStyleFontTime)
            LblModel.Font = New Font(setFontModel, setSizeFontModel, setStyleFontModel)
            LblTarget.Font = New Font(setFontTarget, setSizeFontTarget, setStyleFontTarget)
            LblAktual.Font = New Font(setFontAktual, setSizeFontAktual, setStyleFontAktual)
            LblJudulAktual.Font = New Font(setFontJudul, setSizeFontJudul, setStyleFontJudul)
            LblJudulModel.Font = New Font(setFontJudul, setSizeFontJudul, setStyleFontJudul)
            LblJudulTarget.Font = New Font(setFontJudul, setSizeFontJudul, setStyleFontJudul)
            LblEfisiensi.Font = New Font(setFontEfisiensi, setSizeFontEfisiensi, setStyleFontEfisiensi)
            ''full version tanpa expired ini dibuat full version tgl 1 November 2023
            'Dim tgl As String = "2023-12-10"

            'If TglExpired >= CDate(tgl) Then
            '    FormLogin.Show()
            '    Me.Hide()
            'End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error LoadSettinganAwal()")
        End Try
    End Sub

#Region "CRUD"
    Private Sub AutonumberReport()
        Try
            ConnectMySQL()
            TglHariIni = Format(Date.Today, "yyyyMMdd")
            Dim awalanReportNo As String = TglHariIni & "1"
            CMD = New OdbcCommand("select * from report where idreport='" & awalanReportNo & "'", CONN)
            ''order by idreport desc
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                ReportNo = TglHariIni & "1"
            Else
                ReportNo = Val(Microsoft.VisualBasic.Mid(DR.Item("idreport").ToString, 9, 3)) + 1
                ReportNo = TglHariIni & ReportNo
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub InsertDataReport()

        If aktual = 0 Then
            DisconnectTimbangan()
            BtnConnectTimbangan.Enabled = True
            BtnStop.Enabled = False
            ResetSetelahSimpan()
            Exit Sub
        End If

        'Dim tglsimpan As string = Format(Date.Today, "yyyy-MM-dd")
        Dim durasi As DateTime = Convert.ToDateTime(WaktuStop)
        Dim stoptime As DateTime = Convert.ToDateTime(WaktuStart)
        Dim span As TimeSpan = durasi - stoptime
        WorkHours = span.Hours().ToString("00") & ":" & span.Minutes().ToString("00") & ":" & span.Seconds().ToString("00")

        If lanjutHitungdarisebelumnya = True Then
            ''sebelumnya setiap kali stop, selalu insert data, tapi mulai 23 november 2023 ada fitur lanjut dari sesi sebelumnya, jadi per mesin cuma 1x insert sisanya update jika ada di mesin , model dan tgl yang sama.
            ''jadi harus cek dulu ketersediaan datanya
            Try
                ConnectMySQL()

                CMD = New OdbcCommand("select * from report where convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "'  ", CONN)
                DR = CMD.ExecuteReader
                DR.Read()
                If Not DR.HasRows Then
                    ''ini baru insert data
                    AutonumberReport()
                    Try
                        ConnectMySQL() ''buka koneksi ke MYSQL
                        Dim simpan As String = "INSERT INTO report(idreport, model, qty, start, stop, workhours, efisiensi, line, user, idealstarttime, actualtarget) VALUES ('" & ReportNo & "','" & LblModel.Text & "','" & LblAktual.Text & "','" & WaktuStart & "','" & WaktuStop & "','" & WorkHours & "','" & LblEfisiensi.Text & "','" & setLine & "','" & iduser & "' ,'" & xStartTimeIdeal & "'," & LblTarget.Text & " )"
                        CMD = New OdbcCommand(simpan, CONN)
                        CMD.ExecuteNonQuery()
                        CONN.Close() ''tutup koneksi ke MYSQL

                        LblIsiNotifikasi.Text = "Data berhasil disimpan!"
                        berhasilinsertatauupdatedata = True
                        TimerMsgBox.Start()
                        PanelNotifikasi.Visible = True
                        PanelNotifikasi.BringToFront()
                        LblJudulNotifikasi.Location = New Point(PanelNotifikasi.Height / 2, PanelNotifikasi.Width / 2)


                        LblEfisiensi.ForeColor = Color.Black

                        DisconnectTimbangan()
                        BtnConnectTimbangan.Enabled = True
                        BtnStop.Enabled = False
                        ResetSetelahSimpan()
                    Catch ex As Exception
                        MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataReport")
                    End Try
                Else
                    ''kalau ada berarti cukup update aja
                    Try
                        ConnectMySQL()
                        Dim update As String = "Update report Set qty=" & LblAktual.Text & ",start='" & WaktuStart & "',Stop='" & WaktuStop & "',workhours='" & WorkHours & "',efisiensi='" & LblEfisiensi.Text & "',user='" & iduser & "',idealstarttime='" & xStartTimeIdeal & "',actualtarget=" & LblTarget.Text & " WHERE convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "' "
                        CMD = New OdbcCommand(update, CONN)
                        CMD.ExecuteNonQuery()
                        CONN.Close()
                        LblIsiNotifikasi.Text = "Data berhasil diperbaharui!"
                        berhasilinsertatauupdatedata = True
                        TimerMsgBox.Start()
                        PanelNotifikasi.Visible = True
                        PanelNotifikasi.BringToFront()
                        LblJudulNotifikasi.Location = New Point(PanelNotifikasi.Height / 2, PanelNotifikasi.Width / 2)


                        LblEfisiensi.ForeColor = Color.Black

                        DisconnectTimbangan()
                        BtnConnectTimbangan.Enabled = True
                        BtnStop.Enabled = False
                        ResetSetelahSimpan()
                    Catch ex As Exception
                        MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateReportTerbaru()")
                    End Try
                End If
            Catch ex As Exception
                MsgBox(ex.Message.ToString)
            End Try
        Else
            '''ini baru insert data
            '''sebenarnya disini itu gk selalu insert data karena insert data pasti udah dilakukan disetiap penambahan qty, harusnya disini tuh update.
            'AutonumberReport()
            'Try
            '    ConnectMySQL() ''buka koneksi ke MYSQL
            '    Dim simpan As String = "INSERT INTO report(idreport, model, qty, start, stop, workhours, efisiensi, line, user, idealstarttime, actualtarget) VALUES ('" & ReportNo & "','" & LblModel.Text & "','" & LblAktual.Text & "','" & WaktuStart & "','" & WaktuStop & "','" & WorkHours & "','" & LblEfisiensi.Text & "','" & setLine & "','" & iduser & "' ,'" & xStartTimeIdeal & "'," & LblTarget.Text & " )"
            '    CMD = New OdbcCommand(simpan, CONN)
            '    CMD.ExecuteNonQuery()
            '    CONN.Close() ''tutup koneksi ke MYSQL

            '    LblIsiNotifikasi.Text = "Data berhasil disimpan!"
            '    TimerMsgBox.Start()
            '    PanelNotifikasi.Visible = True
            '    PanelNotifikasi.BringToFront()
            '    LblJudulNotifikasi.Location = New Point(PanelNotifikasi.Height / 2, PanelNotifikasi.Width / 2)


            '    LblEfisiensi.ForeColor = Color.Black
            '    DisconnectTimbangan()
            '    BtnConnectTimbangan.Enabled = True
            '    BtnStop.Enabled = False
            '    ResetSetelahSimpan()
            'Catch ex As Exception
            '    MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataReport")
            'End Try
            Try
                ConnectMySQL()

                CMD = New OdbcCommand("select * from report where convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "'  ", CONN)
                DR = CMD.ExecuteReader
                DR.Read()
                If Not DR.HasRows Then
                    ''ini baru insert data
                    AutonumberReport()
                    Try
                        ConnectMySQL() ''buka koneksi ke MYSQL
                        Dim simpan As String = "INSERT INTO report(idreport, model, qty, start, stop, workhours, efisiensi, line, user, idealstarttime, actualtarget) VALUES ('" & ReportNo & "','" & LblModel.Text & "','" & LblAktual.Text & "','" & WaktuStart & "','" & WaktuStop & "','" & WorkHours & "','" & LblEfisiensi.Text & "','" & setLine & "','" & iduser & "' ,'" & xStartTimeIdeal & "'," & LblTarget.Text & " )"
                        CMD = New OdbcCommand(simpan, CONN)
                        CMD.ExecuteNonQuery()
                        CONN.Close() ''tutup koneksi ke MYSQL

                        LblIsiNotifikasi.Text = "Data berhasil disimpan (1)!"
                        berhasilinsertatauupdatedata = True
                        TimerMsgBox.Start()
                        PanelNotifikasi.Visible = True
                        PanelNotifikasi.BringToFront()
                        LblJudulNotifikasi.Location = New Point(PanelNotifikasi.Height / 2, PanelNotifikasi.Width / 2)


                        LblEfisiensi.ForeColor = Color.Black

                        DisconnectTimbangan()
                        BtnConnectTimbangan.Enabled = True
                        BtnStop.Enabled = False
                        ResetSetelahSimpan()
                    Catch ex As Exception
                        MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataReport")
                    End Try
                Else
                    ''kalau ada berarti cukup update aja
                    Try
                        ConnectMySQL()
                        Dim update As String = "Update report Set qty=" & LblAktual.Text & ",start='" & WaktuStart & "',Stop='" & WaktuStop & "',workhours='" & WorkHours & "',efisiensi='" & LblEfisiensi.Text & "',user='" & iduser & "',idealstarttime='" & xStartTimeIdeal & "',actualtarget=" & LblTarget.Text & " WHERE convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "' "
                        CMD = New OdbcCommand(update, CONN)
                        CMD.ExecuteNonQuery()
                        CONN.Close()
                        LblIsiNotifikasi.Text = "Data berhasil disimpan (2)!"
                        berhasilinsertatauupdatedata = True
                        TimerMsgBox.Start()
                        PanelNotifikasi.Visible = True
                        PanelNotifikasi.BringToFront()
                        LblJudulNotifikasi.Location = New Point(PanelNotifikasi.Height / 2, PanelNotifikasi.Width / 2)


                        LblEfisiensi.ForeColor = Color.Black

                        DisconnectTimbangan()
                        BtnConnectTimbangan.Enabled = True
                        BtnStop.Enabled = False
                        ResetSetelahSimpan()
                    Catch ex As Exception
                        MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateReportTerbaru()")
                    End Try
                End If
            Catch ex As Exception
                MsgBox(ex.Message.ToString)
            End Try
        End If
    End Sub
    Private Sub InsertDataReportAwal()

        xStartTimeIdeal = JamStart & ":00:00"
        'Dim tglsimpan As string = Format(Date.Today, "yyyy-MM-dd")
        Dim durasi As DateTime = Convert.ToDateTime(WaktuStop)
        Dim stoptime As DateTime = Convert.ToDateTime(WaktuStart)
        Dim span As TimeSpan = durasi - stoptime
        WorkHours = span.Hours().ToString("00") & ":" & span.Minutes().ToString("00") & ":" & span.Seconds().ToString("00")


        If lanjutHitungdarisebelumnya = True Then
            ''kalau lanjut berarti cukup update aja
            Try
                ConnectMySQL()
                Dim update As String = "Update report Set qty=" & LblAktual.Text & ",start='" & WaktuStart & "',Stop='" & WaktuStop & "',workhours='" & WorkHours & "',efisiensi='" & LblEfisiensi.Text & "',user='" & iduser & "',idealstarttime='" & xStartTimeIdeal & "',actualtarget=" & LblTarget.Text & " WHERE convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "' "
                CMD = New OdbcCommand(update, CONN)
                CMD.ExecuteNonQuery()
                CONN.Close()
            Catch ex As Exception
                MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateReportBerkala()")
            End Try
        Else ''kalau tidak lanjut dari data sebelumnya harus cek juga udah ada atau belum datanya
            ConnectMySQL()
            CMD = New OdbcCommand("select * from report where convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "'  ", CONN)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                ''ini baru insert data
                AutonumberReport()
                Try
                    ConnectMySQL() ''buka koneksi ke MYSQL
                    Dim simpan As String = "INSERT INTO report(idreport, model, qty, start, stop, workhours, efisiensi, line, user, idealstarttime, actualtarget) VALUES ('" & ReportNo & "','" & LblModel.Text & "','" & LblAktual.Text & "','" & WaktuStart & "','" & WaktuStop & "','" & WorkHours & "','" & LblEfisiensi.Text & "','" & setLine & "','" & iduser & "' ,'" & xStartTimeIdeal & "'," & LblTarget.Text & " )"
                    CMD = New OdbcCommand(simpan, CONN)
                    CMD.ExecuteNonQuery()
                    CONN.Close() ''tutup koneksi ke MYSQL
                Catch ex As Exception
                    MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataReportAwal")
                End Try
            Else
                ''kalau ada berarti cukup update aja
                Try
                    ConnectMySQL()
                    Dim update As String = "Update report Set qty=" & LblAktual.Text & ",start='" & WaktuStart & "',Stop='" & WaktuStop & "',workhours='" & WorkHours & "',efisiensi='" & LblEfisiensi.Text & "',user='" & iduser & "',idealstarttime='" & xStartTimeIdeal & "',actualtarget=" & LblTarget.Text & " WHERE convert(tanggal,date)='" & Format(Date.Today, "yyyy-MM-dd") & "' and model ='" & setModel & "' and line ='" & setLine & "' "
                    CMD = New OdbcCommand(update, CONN)
                    CMD.ExecuteNonQuery()
                    CONN.Close()
                Catch ex As Exception
                    MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateReportBerkala()")
                End Try
            End If
        End If
    End Sub
    Private Sub UpdateDataReportBerkala()
        Try

        Catch ex As Exception

        End Try
    End Sub
    Sub CheckEfisiensiPerPenambahanAktual()
        If IsNothing(WaktuStop) = True Or IsNothing(WaktuStart) = True Then
            Exit Sub
        End If


        Dim xdurasi As DateTime = Convert.ToDateTime(WaktuStop).ToLongTimeString
        Dim xstoptime As DateTime = Convert.ToDateTime(WaktuStart).ToLongTimeString
        Dim xspan As TimeSpan = xdurasi - xstoptime
        RealtimeWorkHours = xspan.Hours().ToString("00") & ":" & xspan.Minutes().ToString("00") & ":" & xspan.Seconds().ToString("00")

        xDurasiMenit = xspan.TotalMinutes
        xDurasiMenitTanpaPotonganIstirahat = xspan.TotalMinutes

        If xDurasiMenit < 1 Then
            xDurasiMenit = 1
        Else
            xDurasiMenit = xDurasiMenit
        End If

        GetSettinganIstirhatOnly()
        'tgl 19 Agustus coba tambah kondisi shift 1 lembur , shift 2 dan shift 3.
        '4 rumus + opening + closing + lembur2 dan lembur3
        'tambahan

        '1. untuk potongan opening
        If xstoptime <= Convert.ToDateTime(MulaiIstirahatOpening).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatOpening).ToLongTimeString Then
            PotonganWaktuOpening = PotonganWaktuOpening
        Else
            PotonganWaktuOpening = 0
        End If


        '2. untuk potonganistirahat1
        If xstoptime <= Convert.ToDateTime(MulaiIstirahat1).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahat1).ToLongTimeString Then
            PotonganWaktuIstirahat1 = PotonganWaktuIstirahat1
            If rolling1 = "On" Then
                PotonganWaktuIstirahat1 = 0
            End If
        Else
            PotonganWaktuIstirahat1 = 0
        End If

        '3. untuk potonganistirahat2
        If day = "JUMAT" Then
            If xstoptime <= Convert.ToDateTime(MulaiIstirahat2Jumat).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahat2Jumat).ToLongTimeString Then
                PotonganWaktuIstirahat2Jumat = PotonganWaktuIstirahat2Jumat
                PotonganWaktuIstirahat2 = 0
            Else
                PotonganWaktuIstirahat2Jumat = 0
                PotonganWaktuIstirahat2 = 0
            End If

            '4. untuk potonganistirahatlembur1
            If xstoptime <= Convert.ToDateTime(MulaiIstirahatLembur1Jumat).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatLembur1Jumat).ToLongTimeString And SetLemburShift1 = "Ya" And SetAktifShift2 = "Off" Then
                PotonganWaktuIstirahatLembur1Jumat = PotonganWaktuIstirahatLembur1Jumat
                PotonganWaktuIstirahatLembur1 = 0
            Else
                PotonganWaktuIstirahatLembur1Jumat = 0
                PotonganWaktuIstirahatLembur1 = 0
            End If

            '6. untuk potongan closing
            If xstoptime <= Convert.ToDateTime(MulaiIstirahatClosingJumat).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatClosingJumat).ToLongTimeString Then
                PotonganWaktuIstirahatClosingJumat = PotonganWaktuIstirahatClosingJumat
                PotonganWaktuClosing = 0
            Else
                PotonganWaktuIstirahatClosingJumat = 0
                PotonganWaktuClosing = 0
            End If
        Else
            If xstoptime <= Convert.ToDateTime(MulaiIstirahat2).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahat2).ToLongTimeString Then
                PotonganWaktuIstirahat2 = PotonganWaktuIstirahat2
                PotonganWaktuIstirahat2Jumat = 0
                If rolling2 = "On" Then
                    PotonganWaktuIstirahat2 = 0
                End If
            Else
                PotonganWaktuIstirahat2 = 0
                PotonganWaktuIstirahat2Jumat = 0
            End If

            '4. untuk potonganistirahatlembur1
            If xstoptime <= Convert.ToDateTime(MulaiIstirahatLembur1).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatLembur1).ToLongTimeString And SetLemburShift1 = "Ya" And SetAktifShift2 = "Off" Then
                PotonganWaktuIstirahatLembur1 = PotonganWaktuIstirahatLembur1
                PotonganWaktuIstirahatLembur1Jumat = 0
            Else
                PotonganWaktuIstirahatLembur1 = 0
                PotonganWaktuIstirahatLembur1Jumat = 0
            End If

            '6. untuk potongan closing
            If xstoptime <= Convert.ToDateTime(MulaiIstirahatClosing).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatClosing).ToLongTimeString Then
                PotonganWaktuClosing = PotonganWaktuClosing
                PotonganWaktuIstirahatClosingJumat = 0
            Else
                PotonganWaktuClosing = 0
                PotonganWaktuIstirahatClosingJumat = 0
            End If
        End If


        '5. untuk potonganistirahat3
        If xstoptime <= Convert.ToDateTime(MulaiIstirahat3).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahat3).ToLongTimeString Then
            PotonganWaktuIstirahat3 = PotonganWaktuIstirahat3
            If rolling3 = "On" Then
                PotonganWaktuIstirahat3 = 0
            End If
        Else
            PotonganWaktuIstirahat3 = 0
        End If


        '7. untuk potonganistirahatlembur2
        If xstoptime <= Convert.ToDateTime(MulaiIstirahatLembur2).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatLembur2).ToLongTimeString And SetLemburShift1 = "Ya" And SetAktifShift2 = "Off" Then
            PotonganWaktuIstirahatLembur2 = PotonganWaktuIstirahatLembur2
        Else
            PotonganWaktuIstirahatLembur2 = 0
        End If

        '8. untuk potonganistirahatlembur3
        If xstoptime <= Convert.ToDateTime(MulaiIstirahatLembur3).ToLongTimeString And xdurasi > Convert.ToDateTime(SelesaiIstirahatLembur3).ToLongTimeString And SetLemburShift1 = "Ya" And SetAktifShift2 = "Off" Then
            PotonganWaktuIstirahatLembur3 = PotonganWaktuIstirahatLembur3
        Else
            PotonganWaktuIstirahatLembur3 = 0
        End If

        'case flexible
        xDurasiPotongIstirahat = PotonganWaktuOpening + PotonganWaktuIstirahat1 + PotonganWaktuIstirahat2 + PotonganWaktuIstirahat2Jumat + PotonganWaktuIstirahat3 + PotonganWaktuIstirahatLembur1 + PotonganWaktuIstirahatLembur1Jumat + PotonganWaktuClosing + PotonganWaktuIstirahatClosingJumat + PotonganWaktuIstirahatLembur2 + PotonganWaktuIstirahatLembur3
        xDurasiMenit = xDurasiMenit - xDurasiPotongIstirahat

        TargetRealtime = xDurasiMenit * setTargetPcs
        setEfisiensi = (aktual / TargetRealtime) * 100
        setEfisiensi = FormatNumber(setEfisiensi, 1)
        If setEfisiensi <= 80 Then
            LblEfisiensi.ForeColor = ColorTranslator.FromHtml(warnaEfisiensi0)
        ElseIf setEfisiensi >= 81 And setEfisiensi <= 90 Then
            LblEfisiensi.ForeColor = ColorTranslator.FromHtml(warnaEfisiensi80)
        ElseIf setEfisiensi > 91 Then
            ''   ElseIf setEfisiensi >= 91 And setEfisiensi >= 100 Then
            LblEfisiensi.ForeColor = ColorTranslator.FromHtml(warnaEfisiensi100)
        End If
        LblEfisiensi.Text = setEfisiensi & "%"
    End Sub
    Sub ResetSetelahSimpan()
        aktual = 0
        setEfisiensi = 0
        targetygselalubertambah = 0
        LblAktual.Text = "0"
        LblEfisiensi.Text = "0 %"
    End Sub

    Private Sub FormDisplay_Disposed(sender As Object, e As EventArgs) Handles Me.Disposed
        Me.Hide()
    End Sub
#End Region

#Region "Arduino"
    Delegate Sub SetTextCallbackArduino(ByVal [textarduino] As String)
    Private Sub SerialPortArduino_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPortArduino.DataReceived
        Try
            'ini fungsi untuk menerima data dari SerialPort1, ReadExisting adalah perintah untuk mengambil data setiap saat/setiap serailport1 mengirimkan data
            ReceivedTextArduino(SerialPortArduino.ReadExisting())
        Catch ex As Exception
            MsgBox("Connection Port Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error SerialPortArduino")
        End Try
    End Sub
    Private Sub ReceivedTextArduino(ByVal [textarduino] As String)
        'fungsi untuk menerima data/inputan dari timbangan kali ini yang kita mabil data berupa text/string
        Try

            'compares the ID of the creating Thread to the ID of the calling Thread
            If Me.RichTextBoxArduino.InvokeRequired Then
                Dim x As New SetTextCallbackArduino(AddressOf ReceivedTextArduino)
                Me.Invoke(x, New Object() {([textarduino])})
            Else
                'Me.RichTextBoxArduino.Text &= [textarduino]
                'Me.RichTextBoxArduino.Text = Me.RichTextBoxArduino.Text
                Me.RichTextBoxArduino.Text = Strings.Left([textarduino], 1)
                'Me.RichTextBoxArduino.Clear()
            End If
        Catch ex As Exception
            MsgBox("Connection Port Arduino Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error ReceivedTextArduino")
        End Try
    End Sub


    Private Sub RichTextBoxArduino_TextChanged(sender As Object, e As EventArgs) Handles RichTextBoxArduino.TextChanged
        Try
            Dim jumlah_baris As String
            jumlah_baris = RichTextBoxArduino.Lines.Count 'menghitung jumlah baris di rtbreceived
            If jumlah_baris >= 1 Then 'jika txtjumlah nilainya lebih besar dari 2 maka
                TxtPerintah.Text = Strings.Left(RichTextBoxArduino.Text, 1)  'mengambil 7 karakter dimulai dari karkter ke 3
                RichTextBoxArduino.Clear()
            End If
            'Start
            If TxtPerintah.Text = "X" Then
                If BtnConnectTimbangan.Enabled = True Then
                    BtnConnectTimbangan.PerformClick()
                End If
                'Stop
            ElseIf TxtPerintah.Text = "Y" Then
                If BtnConnectTimbangan.Enabled = False Then
                    BtnStop.PerformClick()
                End If
                'Pause
            ElseIf TxtPerintah.Text = "P" Then
                If BtnContinue.Enabled = False Then
                    BtnPause.PerformClick()
                End If
                'Continue
            ElseIf TxtPerintah.Text = "C" Then
                If BtnPause.Enabled = False Then
                    BtnContinue.PerformClick()
                End If
                'Add
            ElseIf TxtPerintah.Text = "+" Then
                TimerTambahAktualDariButton.Start()
                ''ini aktif kalau memang timbangan tidak bisa digunakan
                If SudahTambahAktuallewatButton = 0 Then
                    aktual = LblAktual.Text
                    tambahaktual()
                    RichTextBoxArduino.Clear()
                    SudahTambahAktuallewatButton = 1
                End If
            ElseIf TxtPerintah.Text = "1" Then
                ''Untuk tambah Counter 1 piece
                tambahmanual1pcs()
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub ConnectArduino()
        If sudahkonekarduino = True Then
            Exit Sub
        End If
        Try
            'definisikan propertis port untuk melakukan koneksi
            SerialPortArduino.PortName = setComPortArduino
            SerialPortArduino.BaudRate = setBaudRateArduino
            SerialPortArduino.Parity = IO.Ports.Parity.None
            SerialPortArduino.StopBits = IO.Ports.StopBits.One
            SerialPortArduino.DataBits = 8

            If SerialPortArduino.IsOpen Then
                DisconnectArduino()
                SerialPortArduino.Open()
            Else
                SerialPortArduino.Open()
                LblIsiNotifikasi.Text = "Arduino Connected!"
                sudahkonekarduino = True
                TimerMsgBox.Start()
                PanelNotifikasi.Visible = True
                PanelNotifikasi.BringToFront()
            End If 'SerialPort Aktif

        Catch ex As Exception
            sudahkonekarduino = False
            MsgBox("Connection Port Arduino Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error ConnectArduino")
        End Try
    End Sub
    Private Sub DisconnectArduino()
        'cek jika backgroundworker tidak sedang sibuk maka lakukan RunWorkerAsync 
        If BackgroundWorkerArduino.IsBusy <> True Then
            BackgroundWorkerArduino.RunWorkerAsync()
        End If
    End Sub

    Private Sub BackgroundWorkerArduino_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorkerArduino.DoWork
        'mendefinisikan backgroundworker
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
        'memberikan ijin kepada sistem untuk mengeksekusi sebuah perintah ketika sedang menunggu/melooping perintah lain di saat yang sama
        Application.DoEvents()
        Try
            'memutus koneksi ke timbangan
            SerialPortArduino.Close()
        Catch ex As Exception
            MsgBox("BackgroundWoker Arduino Error:" & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub TimerMsgBox_Tick(sender As Object, e As EventArgs) Handles TimerMsgBox.Tick
        counterMSGBOX += 1
        If counterMSGBOX = 2 Then
            PanelNotifikasi.Visible = False
            TimerMsgBox.Stop()
            counterMSGBOX = 0
        End If
    End Sub

    Private Sub LblTime_TextChanged(sender As Object, e As EventArgs) Handles LblTime.TextChanged
        CekStatusLine("M01")
        CekStatusLine("M02")
        CekStatusLine("M03")
        CekStatusLine("M04")
        CekStatusLine("M05")
        CekStatusLine("M06")
        Select Case setNomorMesin
            Case "M01"
                ApakahMesinAktif = statusM01
            Case "M02"
                ApakahMesinAktif = statusM02
            Case "M03"
                ApakahMesinAktif = statusM03
            Case "M04"
                ApakahMesinAktif = statusM04
            Case "M05"
                ApakahMesinAktif = statusM05
            Case "M06"
                ApakahMesinAktif = statusM06
        End Select
        Ambiltargetterbaru(setNomorMesin)
        Select Case LblTime.Text
            Case "00:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "01:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "02:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "03:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "04:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "05:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "06:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "07:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "08:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "09:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "10:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "11:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "12:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "13:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "14:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "15:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "16:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "17:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "18:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "19:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "20:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "21:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "22:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case "23:00:00"
                JamGenap = True
                If ApakahMesinAktif = "Ya" Then
                    HitungTarget()
                End If
            Case Else
                ''nothing
        End Select
    End Sub
    Private Sub TimerTambahAktualDariButton_Tick(sender As Object, e As EventArgs) Handles TimerTambahAktualDariButton.Tick
        delaytambahaktualdaributton += 1
        If delaytambahaktualdaributton = setDelay Then
            SudahTambahAktuallewatButton = 0
            delaytambahaktualdaributton = 0
            TimerTambahAktualDariButton.Stop()
        End If
    End Sub

    Private Sub BtnGantiJam_Click(sender As Object, e As EventArgs) Handles BtnGantiJam.Click
        tambahjammanual = True
        'My.Computer.Audio.Play(xsuarabel, AudioPlayMode.Background)
        TimerWaktu.Stop()
        TimerWaktu.Enabled = False
        Select Case LblTime.Text
            Case "07:00:00"
                LblTime.Text = "08:00:00"
            Case "08:00:00"
                LblTime.Text = "09:00:00"
            Case "09:00:00"
                LblTime.Text = "10:00:00"
            Case "10:00:00"
                LblTime.Text = "11:00:00"
            Case "11:00:00"
                LblTime.Text = "12:00:00"
            Case "12:00:00"
                LblTime.Text = "13:00:00"
            Case "13:00:00"
                LblTime.Text = "14:00:00"
            Case "14:00:00"
                LblTime.Text = "15:00:00"
            Case "15:00:00"
                LblTime.Text = "16:00:00"
            Case "16:00:00"
                LblTime.Text = "17:00:00"
            Case "17:00:00"
                LblTime.Text = "18:00:00"
            Case "18:00:00"
                LblTime.Text = "19:00:00"
            Case "19:00:00"
                LblTime.Text = "20:00:00"
            Case "20:00:00"
                LblTime.Text = "21:00:00"
            Case "21:00:00"
                LblTime.Text = "22:00:00"
            Case "22:00:00"
                LblTime.Text = "23:00:00"
            Case "23:00:00"
                LblTime.Text = "00:00:00"
            Case Else
                LblTime.Text = "07:00:00"
        End Select
    End Sub
    Private Sub BtnTambahAktual_Click(sender As Object, e As EventArgs) Handles BtnTambahAktual.Click
        tambahaktual()
        'My.Computer.Audio.Play(xsuaratimbangan, AudioPlayMode.Background)
    End Sub
    ' HitungUlangTarget()
    '    If IsNothing(WaktuStart) = True Then
    '        Exit Sub
    '    End If

    '    Dim JamStopTarget As String
    '    Dim MenitStopTarget As String
    '    Dim DetikStopTarget As String
    '    Dim WaktuStopTarget As String
    '    JamStopTarget = TimeOfDay.Hour.ToString
    '    MenitStopTarget = TimeOfDay.Minute.ToString
    '        DetikStopTarget = TimeOfDay.Second.ToString
    '    WaktuStopTarget = JamStopTarget & ":" & MenitStopTarget & ":" & DetikStopTarget
    '    'WaktuStopTarget = LblTime.Text

    '    Dim xdurasitarget As DateTime = Convert.ToDateTime(WaktuStopTarget).ToLongTimeString
    '    Dim xstoptimetarget As DateTime = Convert.ToDateTime(WaktuStart).ToLongTimeString
    '        Dim xspan As TimeSpan = xdurasitarget - xstoptimetarget

    '        xDurasiMenitTarget = xspan.TotalMinutes


    '    GetSettinganIstirhatOnly()
    '        '4 rumus 
    '        '1. untuk potonganistirahatpagi
    '        If WaktuStart <= Convert.ToDateTime(xMulaiPagi).ToLongTimeString And xdurasitarget > Convert.ToDateTime(xSelesaiPagi).ToLongTimeString Then
    '            PotonganWaktuIstirahatPagi = PotonganWaktuIstirahatPagi
    '        Else
    '            PotonganWaktuIstirahatPagi = 0
    '        End If
    '        '2. untuk potonganistirahatsiang


    '        If day = "JUMAT" Then
    '            If WaktuStart <= Convert.ToDateTime(xMulaiJumat).ToLongTimeString And xdurasitarget > Convert.ToDateTime(xSelesaiJumat).ToLongTimeString Then
    '                PotonganWaktuIstirahatJumat = PotonganWaktuIstirahatJumat
    '                PotonganWaktuIstirahatSiang = 0
    '            Else
    '                PotonganWaktuIstirahatJumat = 0
    '                PotonganWaktuIstirahatSiang = 0
    '            End If
    '        Else
    '            If WaktuStart <= Convert.ToDateTime(xMulaiSiang).ToLongTimeString And xdurasitarget > Convert.ToDateTime(xSelesaiSiang).ToLongTimeString Then
    '                PotonganWaktuIstirahatSiang = PotonganWaktuIstirahatSiang
    '                PotonganWaktuIstirahatJumat = 0
    '            Else
    '                PotonganWaktuIstirahatSiang = 0
    '                PotonganWaktuIstirahatJumat = 0
    '            End If
    '        End If


    '        '3. untuk potonganistirahatsore

    '        If WaktuStart <= Convert.ToDateTime(xMulaiSore).ToLongTimeString And xdurasitarget > Convert.ToDateTime(xSelesaiSore).ToLongTimeString Then
    '            PotonganWaktuIstirahatSore = PotonganWaktuIstirahatSore
    '        Else
    '            PotonganWaktuIstirahatSore = 0
    '            'MsgBox(" waktu start : " & WaktuStart)
    '            'MsgBox(" waktu stop: " & xMulaiSore)
    '            'MsgBox(" durasi target setelah diconvert: " & xdurasitarget)
    '        End If
    '        '4. untuk potonganistirahatlembur
    '        If WaktuStart <= Convert.ToDateTime(xMulaiLembur).ToLongTimeString And xdurasitarget > Convert.ToDateTime(xSelesaiLembur).ToLongTimeString Then
    '            PotonganWaktuIstirahatLembur = PotonganWaktuIstirahatLembur
    '        Else
    '            PotonganWaktuIstirahatLembur = 0
    '        End If

    '        xDurasiPotongIstirahat = PotonganWaktuIstirahatPagi + PotonganWaktuIstirahatJumat + PotonganWaktuIstirahatSiang + PotonganWaktuIstirahatSore + PotonganWaktuIstirahatLembur
    '        xDurasiMenitTarget = xDurasiMenitTarget - xDurasiPotongIstirahat

    '        'rumusnya :
    '        'untuk jam pertama (Tekan tombol START)  =>> 60 menit - menit start - total potongan istirahat
    '        'untuk jam genap berikutnya              ==> (selisih jam stop - jam start) - total potongan istirahat

    '        LblTarget.Text = xDurasiMenitTarget * setTargetPcs
    '        UpdateTargetTerbaru(CInt(LblTarget.Text))

    'End Sub
    Private Sub HitungTarget()
        If ApakahIniTargetJamPertama = True Then
            TambahTargetJamPertama()
        Else
            TambahTargetJamBerikutnya()
        End If
    End Sub

    Private Sub TambahTargetJamPertama()
        ''jika ini adalah baru pertama kali dijalankan maka target jam pertama adalah : (60 - menit mulai) * taget per menit
        ''misalkan target perjam 360 pcs berarti permenit 6 pcs
        ''misalkan jam mulai 08:10 maka targetnya harus : (60-10) * 6 = 300 pcs
        ''300 pcs adalah target untuk 1 jam ke depan (jam 8 - 9)
        ''baru kemudian jika waktu sudah menunjukan jam 9:00:00 dan seterusnya maka hitungan target adalah 60 - menit istirahat * target per menit

        setTarget = setTarget / 60 * (60 - CInt(MenitStart))
        UpdateTargetTerbaru(setTarget, setNomorMesin)
        LblTarget.Text = setTarget

    End Sub

    Private Sub TambahTargetJamBerikutnya()
        'jika waktu sudah menunjukan jam 9:00:00 dan seterusnya maka hitungan target adalah 60 - menit istirahat * target per menit
        'berarti variable yang dibutuhkan hanya jam aktual saat ini misalkan jam 9 atau jam 10 , potonganwaktuistirahat dan target per menit
        targetygselalubertambah = CInt(LblTarget.Text)
        If IsNothing(WaktuStart) = True Then
            Exit Sub
        End If
        xDurasiMenitTarget = 60
        Dim WaktuTarget1jamBerikutnya As DateTime
        Dim WaktuSaatIniTarget As DateTime = Convert.ToDateTime(LblTime.Text).ToLongTimeString
        'MsgBox(" waktu saat ini target : " & WaktuSaatIniTarget)
        If WaktuSaatIniTarget > "00:00:00" Then
            WaktuSaatIniTarget = WaktuSaatIniTarget
            If tambahjammanual = True Then
                WaktuSaatIniTarget = WaktuSaatIniTarget.AddHours(-1)
            End If

        End If
        WaktuTarget1jamBerikutnya = WaktuSaatIniTarget.AddHours(1)
        'MsgBox(" WaktuTarget1jamBerikutnya sebelum diconvert: " & WaktuTarget1jamBerikutnya)
        WaktuTarget1jamBerikutnya = WaktuTarget1jamBerikutnya.ToLongTimeString


        GetSettinganIstirhatOnly()
        '4 rumus + opening + closing + lembur2 dan lembur3
        'tambahan

        '1. untuk potongan opening
        If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatOpening).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahatOpening).ToLongTimeString Then
            PotonganWaktuOpening = PotonganWaktuOpening
        Else
            PotonganWaktuOpening = 0
        End If

        '2. untuk potonganistirahat1
        If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahat1).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahat1).ToLongTimeString Then
            PotonganWaktuIstirahat1 = PotonganWaktuIstirahat1
            If rolling1 = "On" Then
                PotonganWaktuIstirahat1 = 0
            End If
        Else
            PotonganWaktuIstirahat1 = 0
        End If

        '2. untuk potonganistirahat2
        If day = "JUMAT" Then
            ''waktu potong istirahat jumat itu dibagi 2 
            ''1 potongan dari jam 11.30 - jam 12:00 (ini dipotong dijam 11 ke 12)
            ''2 potongan dari jam 12:00 - jam 14:40 (ini dipotong dijam 12 ke 13)
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahat2Jumat).ToLongTimeString And WaktuTarget1jamBerikutnya.AddMinutes(40) >= Convert.ToDateTime(SelesaiIstirahat2Jumat).ToLongTimeString Then
                PotonganWaktuIstirahat2Jumat = 30
                PotonganWaktuIstirahat2 = 0
            Else
                PotonganWaktuIstirahat2Jumat = 0
                PotonganWaktuIstirahat2 = 0
            End If

            If WaktuSaatIniTarget > "00:00:00" Then
                If WaktuSaatIniTarget.AddMinutes(-30) <= Convert.ToDateTime(MulaiIstirahat2Jumat).ToLongTimeString And WaktuTarget1jamBerikutnya >= Convert.ToDateTime(SelesaiIstirahat2Jumat).ToLongTimeString Then
                    PotonganWaktuIstirahat2Jumat = 40
                    PotonganWaktuIstirahat2 = 0
                Else
                    PotonganWaktuIstirahat2Jumat = PotonganWaktuIstirahat2Jumat + 0
                    PotonganWaktuIstirahat2 = 0
                End If
            End If


            '4. untuk potonganistirahatlembur1
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatLembur1Jumat).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahatLembur1Jumat).ToLongTimeString Then
                PotonganWaktuIstirahatLembur1Jumat = PotonganWaktuIstirahatLembur1Jumat
                PotonganWaktuIstirahatLembur1 = 0
            Else
                PotonganWaktuIstirahatLembur1Jumat = 0
                PotonganWaktuIstirahatLembur1 = 0
            End If

            '5. untuk potongan closing
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatClosingJumat).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahatClosingJumat).ToLongTimeString Then
                PotonganWaktuIstirahatClosingJumat = PotonganWaktuIstirahatClosingJumat
                PotonganWaktuClosing = 0
            Else
                PotonganWaktuIstirahatClosingJumat = 0
                PotonganWaktuClosing = 0
            End If

        Else
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahat2).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahat2).ToLongTimeString Then
                PotonganWaktuIstirahat2 = PotonganWaktuIstirahat2
                PotonganWaktuIstirahat2Jumat = 0
                If rolling2 = "On" Then
                    PotonganWaktuIstirahat2 = 0
                End If
            Else
                PotonganWaktuIstirahat2 = 0
                PotonganWaktuIstirahat2Jumat = 0
            End If

            '4. untuk potonganistirahatlembur1
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatLembur1).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahatLembur1).ToLongTimeString Then
                PotonganWaktuIstirahatLembur1 = PotonganWaktuIstirahatLembur1
                PotonganWaktuIstirahatLembur1Jumat = 0
            Else
                PotonganWaktuIstirahatLembur1 = 0
                PotonganWaktuIstirahatLembur1Jumat = 0
            End If

            '5. untuk potongan closing
            If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatClosing).ToLongTimeString And WaktuTarget1jamBerikutnya >= Convert.ToDateTime(SelesaiIstirahatClosing).ToLongTimeString Then
                PotonganWaktuClosing = PotonganWaktuClosing
                PotonganWaktuIstirahatClosingJumat = 0
            Else
                PotonganWaktuClosing = 0
                PotonganWaktuIstirahatClosingJumat = 0
            End If

        End If


        '3. untuk potonganistirahat3
        If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahat3).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahat3).ToLongTimeString Then
            PotonganWaktuIstirahat3 = PotonganWaktuIstirahat3
            If rolling3 = "On" Then
                PotonganWaktuIstirahat3 = 0
            End If
        Else
            PotonganWaktuIstirahat3 = 0
        End If

        '6. untuk potonganistirahatlembur2
        If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatLembur2).ToLongTimeString And WaktuTarget1jamBerikutnya >= Convert.ToDateTime(SelesaiIstirahatLembur2).ToLongTimeString Then
            PotonganWaktuIstirahatLembur2 = PotonganWaktuIstirahatLembur2
        Else
            PotonganWaktuIstirahatLembur2 = 0
        End If

        '7. untuk potonganistirahatlembur3
        If WaktuSaatIniTarget <= Convert.ToDateTime(MulaiIstirahatLembur3).ToLongTimeString And WaktuTarget1jamBerikutnya > Convert.ToDateTime(SelesaiIstirahatLembur3).ToLongTimeString Then
            PotonganWaktuIstirahatLembur3 = PotonganWaktuIstirahatLembur3
        Else
            PotonganWaktuIstirahatLembur3 = 0
        End If

        xDurasiPotongIstirahat = PotonganWaktuOpening + PotonganWaktuIstirahat1 + PotonganWaktuIstirahat2 + PotonganWaktuIstirahat2Jumat + PotonganWaktuIstirahat3 + PotonganWaktuClosing + PotonganWaktuIstirahatClosingJumat + PotonganWaktuIstirahatLembur1 + PotonganWaktuIstirahatLembur1Jumat + PotonganWaktuIstirahatLembur2 + PotonganWaktuIstirahatLembur3
        xDurasiMenitTarget = xDurasiMenitTarget - xDurasiPotongIstirahat

        'rumusnya :
        'untuk jam pertama (Tekan tombol START)  =>> 60 menit - menit start - total potongan istirahat
        'untuk jam genap berikutnya              ==> (selisih jam stop - jam start) - total potongan istirahat

        LblTarget.Text = targetygselalubertambah + (xDurasiMenitTarget * setTargetPcs)
        UpdateTargetTerbaru(CInt(LblTarget.Text), setNomorMesin)
        tambahjammanual = False
    End Sub

    Private Sub BtnPause_Click(sender As Object, e As EventArgs) Handles BtnPause.Click
        SerialPortTimbangan.Dispose()
        BtnContinue.Enabled = True
        BtnPause.Enabled = False
    End Sub

    Private Sub BtnContinue_Click(sender As Object, e As EventArgs) Handles BtnContinue.Click
        ConnectTimbangan()
        BtnContinue.Enabled = False
        BtnPause.Enabled = True
    End Sub

    Private Sub BtnTambahManual_Click(sender As Object, e As EventArgs) Handles BtnTambahManual.Click
        tambahmanual1pcs()
    End Sub

#End Region


#Region "Tambah manual 1 pcs"
    Private Sub tambahmanual1pcs()
        Try
            If setToDisplay = True Then
                Dim resultmenit As String()
                resultmenit = Split(StartTimeUntukDiAdjust, ":")
                JamStart = resultmenit(0)
                MenitStart = resultmenit(1)
                If Strings.Left(MenitStart, 1) = "0" Then
                    MenitStart = Strings.Right(MenitStart, 1)
                End If
            Else
                MenitStart = TimeOfDay.Minute.ToString
            End If

            JamStop = TimeOfDay.Hour.ToString
            If JamStop.Length = 1 Then
                JamStop = "0" & JamStop
            End If
            MenitStop = TimeOfDay.Minute.ToString
            If MenitStop.Length = 1 Then
                MenitStop = "0" & MenitStop
            End If
            DetikStop = TimeOfDay.Second.ToString
            If DetikStop.Length = 1 Then
                DetikStop = "0" & DetikStop
            End If
            WaktuStop = JamStop & ":" & MenitStop & ":" & DetikStop
            'WaktuStop = LblTime.Text

            aktual = LblAktual.Text
            aktual += 1
            LblAktual.Text = aktual
            PlayTimbanganOk()
            CheckEfisiensiPerPenambahanAktual()

            UpdateAktualTerbaru(aktual, setNomorMesin)

            Me.Text = "Product Counter " & minweight & " ~ " & maxweight & " , Waktu Kerja = (" & xDurasiMenitTanpaPotonganIstirahat & " - " & xDurasiPotongIstirahat & ") , Efisiensi = " & aktual & " / " & TargetRealtime & " * 100 " & "A [" & PotonganWaktuOpening & "," & PotonganWaktuIstirahat1 & "," & PotonganWaktuIstirahat2 & "," & PotonganWaktuIstirahat2Jumat & "," & PotonganWaktuIstirahat3 & "," & PotonganWaktuClosing & "," & PotonganWaktuIstirahatClosingJumat & "," & PotonganWaktuIstirahatLembur1 & "," & PotonganWaktuIstirahatLembur1Jumat & "," & PotonganWaktuIstirahatLembur2 & "," & PotonganWaktuIstirahatLembur3 & "]" & " Lembur :" & SetLemburShift1 & "  [" & day & "] - " & setNomorMesin
            'BtnStop.Enabled = True
            updatemonitoring(setNomorMesin)
            InsertDataReportAwal()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error tambahmanual1pcs")
        End Try

    End Sub

    Private Sub TimerRealtimeRunningText_Tick(sender As Object, e As EventArgs) Handles TimerRealtimeRunningText.Tick
        GetSettinganRunningTextRealtime()
        setRunningTextSpeed = setRunningTextSpeed
        TimerRunningText.Interval = setRunningTextSpeed
        LblRunningText.Font = New Font(setFontRunningText, setSizeFontRunningText, setStyleFontRunningText)

        LblRunningText.ForeColor = ColorTranslator.FromHtml(warnaRunningText)
        LblRunningText.Text = setisiRunningText
    End Sub


#End Region

End Class
