﻿
Imports System.Data.Odbc
Public Class FormLine
    Dim statusdata As String
    Private Sub FormModel_Load(sender As Object, e As EventArgs) Handles Me.Load
        LoadDataAll()
        EnabledTextBox(False)
    End Sub


#Region "Function"
    Private Sub LoadDataAll()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT id, nama_line as Line , aktif as Status, no_mesin as Mesin, alias as Nama FROM setline", CONN)
            DS = New DataSet
            DA.Fill(DS, "line")
            Dim dt As DataTable = DS.Tables("line")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data setline ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVLine.Columns.Clear()
                DGVLine.DataSource = Nothing
            Else
                DGVLine.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error LoadDataAll")
        End Try
    End Sub
    Private Sub FindLine()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT id, nama_line as Line , aktif as Status, no_mesin as Mesin, alias as Nama  FROM setline WHERE no_mesin='" & TxtFind.Text & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "findline")
            Dim dt As DataTable = DS.Tables("findline")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data line ",
                       MsgBoxStyle.Exclamation, "Warning")
                DGVLine.Columns.Clear()
                DGVLine.DataSource = Nothing
            Else
                DGVLine.DataSource = dt
                LblJumlahData.Text = "Jumlah Data : " & dt.Rows.Count
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error Findline")
        End Try
    End Sub
    Public Sub CekDataSebelumSimpan()
        Try
            ConnectMySQL()

            CMD = New OdbcCommand("SELECT id, nama_line as Line , aktif as Status, no_mesin as Mesin, alias as Nama  FROM setline WHERE nama_line='" & TxtNamaLine.Text & "' and no_mesin='" & TxtNoMesin.Text & "'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                ''data baru boleh diinsert
                InsertDataLine()
            Else
                ''data sudah ada jadi diupdate saja
                UpdateDataLine()
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error CekDataSebelumSimpan()")
        End Try
    End Sub

    Private Sub InsertDataLine()
        Try
            ConnectMySQL()

            Dim simpan As String = "INSERT INTO setline (nama_line, aktif ,no_mesin,alias) VALUES ('" & TxtNamaLine.Text & "','" & CmbStatus.Text & "','" & TxtNoMesin.Text & "','" & TxtAlias.Text & "')"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil disimpan", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error InsertDataLine()")
        End Try
    End Sub

    Private Sub UpdateDataLine()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setline SET aktif='" & CmbStatus.Text & "', alias='" & TxtAlias.Text & "' WHERE id='" & TxtIDLine.Text & "'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            LoadDataAll()
            KosongkanTextbox()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateDataLine()")
        End Try
    End Sub
    Private Sub Deleteline()
        Try
            Dim result As DialogResult = MessageBox.Show("Confirm Delete?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

            If (result = DialogResult.Yes) Then
                ConnectMySQL()

                Dim hapus As String = "DELETE FROM setline WHERE id='" & TxtIDLine.Text & "'"
                CMD = New OdbcCommand(hapus, CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Data berhasil dihapus", vbInformation, "Informasi")
                LoadDataAll()
                KosongkanTextbox()
                KondisiDelete()
            Else
                'Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Deleteline()")
        End Try
    End Sub

#End Region

#Region "Kondisi TextBox"
    Private Sub KosongkanTextbox()
        CmbStatus.Text = ""
        TxtNamaLine.Clear()
        TxtNoMesin.Clear()
        TxtIDLine.Clear()
        TxtAlias.Clear()
    End Sub
    Private Sub EnabledTextBox(ByVal tf As Boolean)
        CmbStatus.Enabled = tf
        TxtNamaLine.Enabled = tf
        TxtNoMesin.Enabled = tf
        TxtAlias.Enabled = tf
    End Sub
    Private Sub KondisiAdd()
        KosongkanTextbox()
        EnabledTextBox(True)
        BtnAdd.Enabled = False
        BtnSave.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
    End Sub
    Private Sub KondisiSave()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiEdit()
        EnabledTextBox(True)
        BtnSave.Enabled = True
        BtnAdd.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = True
        BtnEdit.Enabled = False
    End Sub
    Private Sub KondisiCancel()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
    Private Sub KondisiDelete()
        KosongkanTextbox()
        EnabledTextBox(False)
        BtnSave.Enabled = False
        BtnAdd.Enabled = True
        BtnEdit.Enabled = False
        BtnDelete.Enabled = False
        BtnCancel.Enabled = False
    End Sub
#End Region
    Private Sub DGVLine_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVLine.CellContentClick
        If DGVLine.ColumnCount = 5 Then
            TxtNamaLine.Text = DGVLine.Rows(e.RowIndex).Cells.Item("Line").Value
            TxtNoMesin.Text = DGVLine.Rows(e.RowIndex).Cells.Item("Mesin").Value
            CmbStatus.Text = DGVLine.Rows(e.RowIndex).Cells.Item("Status").Value
            TxtAlias.Text = DGVLine.Rows(e.RowIndex).Cells.Item("Nama").Value
            TxtIDLine.Text = DGVLine.Rows(e.RowIndex).Cells.Item("id").Value
            BtnEdit.Enabled = True
            BtnDelete.Enabled = True
            statusdata = "edit"
        Else
            Exit Sub
        End If
    End Sub


#Region "Button Action"
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        statusdata = "add"
        KondisiAdd()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        Deleteline()
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        statusdata = "edit"
        KondisiEdit()
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        KondisiCancel()
    End Sub

    Private Sub BtnShowAll_Click(sender As Object, e As EventArgs) Handles BtnShowAll.Click
        LoadDataAll()
    End Sub

    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If TxtFind.TextLength = 0 Then
            Exit Sub
        End If
        FindLine()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        If statusdata = "edit" Then
            UpdateDataLine()
        Else
            CekDataSebelumSimpan()
        End If
        KondisiSave()
    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub FormLine_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
        Me.Hide()
    End Sub
#End Region

End Class