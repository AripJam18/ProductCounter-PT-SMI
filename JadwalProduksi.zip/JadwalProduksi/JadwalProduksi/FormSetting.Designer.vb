﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.PanelSetting = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CmbNoMesin = New System.Windows.Forms.ComboBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.CmbLine = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.CmbModel = New System.Windows.Forms.ComboBox()
        Me.TxtMaxWeight = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtPlanning = New System.Windows.Forms.TextBox()
        Me.TxtDetik = New System.Windows.Forms.TextBox()
        Me.TxtKelipatan = New System.Windows.Forms.TextBox()
        Me.TxtMinWeight = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtTarget = New System.Windows.Forms.TextBox()
        Me.BtnCloseTimbanganConfig = New System.Windows.Forms.Button()
        Me.BtnSaveTimbanganConfig = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CmbPort = New System.Windows.Forms.ComboBox()
        Me.CmbBaudRate = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BtnWarnaEfisiensi100 = New System.Windows.Forms.Button()
        Me.PnlWarnaEfisiensi100 = New System.Windows.Forms.Panel()
        Me.BtnWarnaEfisiensi80 = New System.Windows.Forms.Button()
        Me.PnlWarnaEfisiensi80 = New System.Windows.Forms.Panel()
        Me.BtnWarnaEfisiensi0 = New System.Windows.Forms.Button()
        Me.PnlWarnaEfisiensi0 = New System.Windows.Forms.Panel()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.BtnWarnaEfisiensi = New System.Windows.Forms.Button()
        Me.PnlWarnaEfisiensi = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BtnCloseTampilan = New System.Windows.Forms.Button()
        Me.BtnSaveTampilan = New System.Windows.Forms.Button()
        Me.BtnWarnaJudul = New System.Windows.Forms.Button()
        Me.PnlWarnaJudul = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.BtnWarnaAktual = New System.Windows.Forms.Button()
        Me.PnlWarnaAktual = New System.Windows.Forms.Panel()
        Me.BtnWarnaTarget = New System.Windows.Forms.Button()
        Me.BtnWarnaDate = New System.Windows.Forms.Button()
        Me.PnlWarnaTarget = New System.Windows.Forms.Panel()
        Me.BtnWarnaModel = New System.Windows.Forms.Button()
        Me.PnlWarnaDate = New System.Windows.Forms.Panel()
        Me.PnlWarnaModel = New System.Windows.Forms.Panel()
        Me.BtnWarnaDay = New System.Windows.Forms.Button()
        Me.BtnWarnaTime = New System.Windows.Forms.Button()
        Me.PnlWarnaDay = New System.Windows.Forms.Panel()
        Me.PnlWarnaTime = New System.Windows.Forms.Panel()
        Me.BtnWarnaTablayout = New System.Windows.Forms.Button()
        Me.PnlWarnaTabLayout = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnFontRunningText = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TxtFontRunningText = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BtnTesSuaraBel = New System.Windows.Forms.Button()
        Me.Lblnamafilesuarabel = New System.Windows.Forms.Label()
        Me.BtnPilihSuaraBel = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.RBoffBel = New System.Windows.Forms.RadioButton()
        Me.RBonBel = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.BtnTesSuaraTimbangan = New System.Windows.Forms.Button()
        Me.Lblnamafilesuaratimbangan = New System.Windows.Forms.Label()
        Me.BtnPilihSuaraTimbangan = New System.Windows.Forms.Button()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.RBoffSuaraTimbang = New System.Windows.Forms.RadioButton()
        Me.RBonSuaraTimbang = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.RBTidakAnimasi = New System.Windows.Forms.RadioButton()
        Me.RBYaAnimasi = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.RBTidakTampilkan = New System.Windows.Forms.RadioButton()
        Me.RBYaTampilkan = New System.Windows.Forms.RadioButton()
        Me.BtnCloseRunningTextSetting = New System.Windows.Forms.Button()
        Me.BtnSaveRunningTextConfig = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtSpeed = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtIsiRunningText = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BtnWarnaRunningText = New System.Windows.Forms.Button()
        Me.PnlWarnaRunningText = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.BtnCloseArduinoConfig = New System.Windows.Forms.Button()
        Me.BtnArduinoConfig = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.RBNonActive = New System.Windows.Forms.RadioButton()
        Me.RBActive = New System.Windows.Forms.RadioButton()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.CmbPortArduino = New System.Windows.Forms.ComboBox()
        Me.CmbBaudRateArduino = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.BtnFontEfiseinsi = New System.Windows.Forms.Button()
        Me.BtnFontJudul = New System.Windows.Forms.Button()
        Me.BtnFontAktual = New System.Windows.Forms.Button()
        Me.BtnFontTime = New System.Windows.Forms.Button()
        Me.BtnFontTarget = New System.Windows.Forms.Button()
        Me.BtnFontDate = New System.Windows.Forms.Button()
        Me.BtnFontModel = New System.Windows.Forms.Button()
        Me.BtnFontDay = New System.Windows.Forms.Button()
        Me.CmbFontEfisiensi = New System.Windows.Forms.ComboBox()
        Me.CmbFontJudul = New System.Windows.Forms.ComboBox()
        Me.CmbFontAktual = New System.Windows.Forms.ComboBox()
        Me.CmbFontTarget = New System.Windows.Forms.ComboBox()
        Me.CmbFontModel = New System.Windows.Forms.ComboBox()
        Me.CmbFontTime = New System.Windows.Forms.ComboBox()
        Me.CmbFontDate = New System.Windows.Forms.ComboBox()
        Me.CmbFontDay = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.BtnCloseFontConfig = New System.Windows.Forms.Button()
        Me.BtnSaveFontConfig = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.BtnCloseAdjustment = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.TxtAdjustStartTime = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TxtAdjustTarget = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.BtnSetToDisplay = New System.Windows.Forms.Button()
        Me.BtnSetAktualTebaru = New System.Windows.Forms.Button()
        Me.TxtAdjustAktual = New System.Windows.Forms.TextBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.BtnCloseShiftConfig = New System.Windows.Forms.Button()
        Me.BtnSaveShiftConfig = New System.Windows.Forms.Button()
        Me.gblembur = New System.Windows.Forms.GroupBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.RBTidakAktifShift3 = New System.Windows.Forms.RadioButton()
        Me.RBYaAktifShift3 = New System.Windows.Forms.RadioButton()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.RBTidakAktifShift2 = New System.Windows.Forms.RadioButton()
        Me.RBYaAktifShift2 = New System.Windows.Forms.RadioButton()
        Me.GBShift1 = New System.Windows.Forms.GroupBox()
        Me.RBTidakLembur = New System.Windows.Forms.RadioButton()
        Me.RBYaLembur = New System.Windows.Forms.RadioButton()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.PanelSetting.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.gblembur.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GBShift1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(550, 512)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.PanelSetting)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(542, 482)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Connection"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'PanelSetting
        '
        Me.PanelSetting.BackColor = System.Drawing.SystemColors.Control
        Me.PanelSetting.Controls.Add(Me.GroupBox2)
        Me.PanelSetting.Controls.Add(Me.BtnCloseTimbanganConfig)
        Me.PanelSetting.Controls.Add(Me.BtnSaveTimbanganConfig)
        Me.PanelSetting.Controls.Add(Me.GroupBox1)
        Me.PanelSetting.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelSetting.Location = New System.Drawing.Point(3, 3)
        Me.PanelSetting.Name = "PanelSetting"
        Me.PanelSetting.Size = New System.Drawing.Size(536, 476)
        Me.PanelSetting.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CmbNoMesin)
        Me.GroupBox2.Controls.Add(Me.Label49)
        Me.GroupBox2.Controls.Add(Me.CmbLine)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.CmbModel)
        Me.GroupBox2.Controls.Add(Me.TxtMaxWeight)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TxtPlanning)
        Me.GroupBox2.Controls.Add(Me.TxtDetik)
        Me.GroupBox2.Controls.Add(Me.TxtKelipatan)
        Me.GroupBox2.Controls.Add(Me.TxtMinWeight)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.TxtTarget)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(5, 104)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(239, 313)
        Me.GroupBox2.TabIndex = 61
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Product Setting"
        '
        'CmbNoMesin
        '
        Me.CmbNoMesin.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbNoMesin.FormattingEnabled = True
        Me.CmbNoMesin.Location = New System.Drawing.Point(96, 273)
        Me.CmbNoMesin.Name = "CmbNoMesin"
        Me.CmbNoMesin.Size = New System.Drawing.Size(125, 25)
        Me.CmbNoMesin.TabIndex = 66
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(1, 275)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(79, 17)
        Me.Label49.TabIndex = 65
        Me.Label49.Text = "MACHINE  :"
        '
        'CmbLine
        '
        Me.CmbLine.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbLine.FormattingEnabled = True
        Me.CmbLine.Location = New System.Drawing.Point(96, 242)
        Me.CmbLine.Name = "CmbLine"
        Me.CmbLine.Size = New System.Drawing.Size(125, 25)
        Me.CmbLine.TabIndex = 64
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(1, 244)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(46, 17)
        Me.Label23.TabIndex = 63
        Me.Label23.Text = "LINE  :"
        '
        'CmbModel
        '
        Me.CmbModel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbModel.FormattingEnabled = True
        Me.CmbModel.Location = New System.Drawing.Point(96, 15)
        Me.CmbModel.Name = "CmbModel"
        Me.CmbModel.Size = New System.Drawing.Size(125, 25)
        Me.CmbModel.TabIndex = 62
        '
        'TxtMaxWeight
        '
        Me.TxtMaxWeight.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMaxWeight.ForeColor = System.Drawing.Color.Red
        Me.TxtMaxWeight.Location = New System.Drawing.Point(96, 209)
        Me.TxtMaxWeight.MaxLength = 5
        Me.TxtMaxWeight.Name = "TxtMaxWeight"
        Me.TxtMaxWeight.Size = New System.Drawing.Size(125, 25)
        Me.TxtMaxWeight.TabIndex = 43
        Me.TxtMaxWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(1, 83)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 17)
        Me.Label4.TabIndex = 60
        Me.Label4.Text = "PLANING  :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(1, 211)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 17)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "MAX WEIGHT :"
        '
        'TxtPlanning
        '
        Me.TxtPlanning.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtPlanning.ForeColor = System.Drawing.Color.Red
        Me.TxtPlanning.Location = New System.Drawing.Point(96, 80)
        Me.TxtPlanning.MaxLength = 5
        Me.TxtPlanning.Name = "TxtPlanning"
        Me.TxtPlanning.Size = New System.Drawing.Size(125, 25)
        Me.TxtPlanning.TabIndex = 61
        Me.TxtPlanning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TxtDetik
        '
        Me.TxtDetik.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDetik.ForeColor = System.Drawing.Color.Red
        Me.TxtDetik.Location = New System.Drawing.Point(96, 142)
        Me.TxtDetik.MaxLength = 2
        Me.TxtDetik.Name = "TxtDetik"
        Me.TxtDetik.Size = New System.Drawing.Size(125, 25)
        Me.TxtDetik.TabIndex = 41
        Me.TxtDetik.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TxtKelipatan
        '
        Me.TxtKelipatan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtKelipatan.ForeColor = System.Drawing.Color.Red
        Me.TxtKelipatan.Location = New System.Drawing.Point(96, 111)
        Me.TxtKelipatan.MaxLength = 2
        Me.TxtKelipatan.Name = "TxtKelipatan"
        Me.TxtKelipatan.Size = New System.Drawing.Size(125, 25)
        Me.TxtKelipatan.TabIndex = 59
        Me.TxtKelipatan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TxtMinWeight
        '
        Me.TxtMinWeight.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtMinWeight.ForeColor = System.Drawing.Color.Red
        Me.TxtMinWeight.Location = New System.Drawing.Point(96, 177)
        Me.TxtMinWeight.MaxLength = 5
        Me.TxtMinWeight.Name = "TxtMinWeight"
        Me.TxtMinWeight.Size = New System.Drawing.Size(125, 25)
        Me.TxtMinWeight.TabIndex = 39
        Me.TxtMinWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(1, 144)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 17)
        Me.Label13.TabIndex = 40
        Me.Label13.Text = "DELAY :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(1, 51)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(61, 17)
        Me.Label17.TabIndex = 52
        Me.Label17.Text = "TARGET :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(1, 179)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(95, 17)
        Me.Label12.TabIndex = 38
        Me.Label12.Text = "MIN WEIGHT :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(1, 17)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(59, 17)
        Me.Label16.TabIndex = 54
        Me.Label16.Text = "MODEL :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1, 115)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 17)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "MULTIPLE :"
        '
        'TxtTarget
        '
        Me.TxtTarget.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtTarget.ForeColor = System.Drawing.Color.Red
        Me.TxtTarget.Location = New System.Drawing.Point(96, 48)
        Me.TxtTarget.MaxLength = 5
        Me.TxtTarget.Name = "TxtTarget"
        Me.TxtTarget.Size = New System.Drawing.Size(125, 25)
        Me.TxtTarget.TabIndex = 56
        Me.TxtTarget.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BtnCloseTimbanganConfig
        '
        Me.BtnCloseTimbanganConfig.BackColor = System.Drawing.Color.Red
        Me.BtnCloseTimbanganConfig.FlatAppearance.BorderSize = 0
        Me.BtnCloseTimbanganConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseTimbanganConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseTimbanganConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseTimbanganConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseTimbanganConfig.ForeColor = System.Drawing.Color.White
        Me.BtnCloseTimbanganConfig.Location = New System.Drawing.Point(263, 75)
        Me.BtnCloseTimbanganConfig.Name = "BtnCloseTimbanganConfig"
        Me.BtnCloseTimbanganConfig.Size = New System.Drawing.Size(153, 48)
        Me.BtnCloseTimbanganConfig.TabIndex = 57
        Me.BtnCloseTimbanganConfig.Text = "CLOSE"
        Me.BtnCloseTimbanganConfig.UseVisualStyleBackColor = False
        '
        'BtnSaveTimbanganConfig
        '
        Me.BtnSaveTimbanganConfig.BackColor = System.Drawing.Color.Green
        Me.BtnSaveTimbanganConfig.FlatAppearance.BorderSize = 0
        Me.BtnSaveTimbanganConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSaveTimbanganConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSaveTimbanganConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSaveTimbanganConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSaveTimbanganConfig.ForeColor = System.Drawing.Color.White
        Me.BtnSaveTimbanganConfig.Location = New System.Drawing.Point(263, 16)
        Me.BtnSaveTimbanganConfig.Name = "BtnSaveTimbanganConfig"
        Me.BtnSaveTimbanganConfig.Size = New System.Drawing.Size(153, 48)
        Me.BtnSaveTimbanganConfig.TabIndex = 53
        Me.BtnSaveTimbanganConfig.Text = "SAVE SCALE CONFIG"
        Me.BtnSaveTimbanganConfig.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.CmbPort)
        Me.GroupBox1.Controls.Add(Me.CmbBaudRate)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(5, 9)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(239, 89)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Scale Setting"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(1, 20)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 17)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "COM  PORT :"
        '
        'CmbPort
        '
        Me.CmbPort.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbPort.FormattingEnabled = True
        Me.CmbPort.Location = New System.Drawing.Point(96, 20)
        Me.CmbPort.Name = "CmbPort"
        Me.CmbPort.Size = New System.Drawing.Size(125, 25)
        Me.CmbPort.TabIndex = 36
        '
        'CmbBaudRate
        '
        Me.CmbBaudRate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBaudRate.FormattingEnabled = True
        Me.CmbBaudRate.Items.AddRange(New Object() {"1200", "2400", "4800", "7200", "9600"})
        Me.CmbBaudRate.Location = New System.Drawing.Point(96, 52)
        Me.CmbBaudRate.Name = "CmbBaudRate"
        Me.CmbBaudRate.Size = New System.Drawing.Size(125, 25)
        Me.CmbBaudRate.TabIndex = 32
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(1, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 17)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "BAUD RATE :"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.BtnWarnaEfisiensi100)
        Me.TabPage2.Controls.Add(Me.PnlWarnaEfisiensi100)
        Me.TabPage2.Controls.Add(Me.BtnWarnaEfisiensi80)
        Me.TabPage2.Controls.Add(Me.PnlWarnaEfisiensi80)
        Me.TabPage2.Controls.Add(Me.BtnWarnaEfisiensi0)
        Me.TabPage2.Controls.Add(Me.PnlWarnaEfisiensi0)
        Me.TabPage2.Controls.Add(Me.Label48)
        Me.TabPage2.Controls.Add(Me.Label47)
        Me.TabPage2.Controls.Add(Me.Label46)
        Me.TabPage2.Controls.Add(Me.BtnWarnaEfisiensi)
        Me.TabPage2.Controls.Add(Me.PnlWarnaEfisiensi)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.BtnCloseTampilan)
        Me.TabPage2.Controls.Add(Me.BtnSaveTampilan)
        Me.TabPage2.Controls.Add(Me.BtnWarnaJudul)
        Me.TabPage2.Controls.Add(Me.PnlWarnaJudul)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.BtnWarnaAktual)
        Me.TabPage2.Controls.Add(Me.PnlWarnaAktual)
        Me.TabPage2.Controls.Add(Me.BtnWarnaTarget)
        Me.TabPage2.Controls.Add(Me.BtnWarnaDate)
        Me.TabPage2.Controls.Add(Me.PnlWarnaTarget)
        Me.TabPage2.Controls.Add(Me.BtnWarnaModel)
        Me.TabPage2.Controls.Add(Me.PnlWarnaDate)
        Me.TabPage2.Controls.Add(Me.PnlWarnaModel)
        Me.TabPage2.Controls.Add(Me.BtnWarnaDay)
        Me.TabPage2.Controls.Add(Me.BtnWarnaTime)
        Me.TabPage2.Controls.Add(Me.PnlWarnaDay)
        Me.TabPage2.Controls.Add(Me.PnlWarnaTime)
        Me.TabPage2.Controls.Add(Me.BtnWarnaTablayout)
        Me.TabPage2.Controls.Add(Me.PnlWarnaTabLayout)
        Me.TabPage2.Controls.Add(Me.Label21)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Location = New System.Drawing.Point(4, 26)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(542, 482)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Display"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'BtnWarnaEfisiensi100
        '
        Me.BtnWarnaEfisiensi100.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaEfisiensi100.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaEfisiensi100.Location = New System.Drawing.Point(291, 439)
        Me.BtnWarnaEfisiensi100.Name = "BtnWarnaEfisiensi100"
        Me.BtnWarnaEfisiensi100.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaEfisiensi100.TabIndex = 107
        Me.BtnWarnaEfisiensi100.Text = "SET"
        Me.BtnWarnaEfisiensi100.UseVisualStyleBackColor = True
        '
        'PnlWarnaEfisiensi100
        '
        Me.PnlWarnaEfisiensi100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaEfisiensi100.Location = New System.Drawing.Point(192, 440)
        Me.PnlWarnaEfisiensi100.Name = "PnlWarnaEfisiensi100"
        Me.PnlWarnaEfisiensi100.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaEfisiensi100.TabIndex = 106
        '
        'BtnWarnaEfisiensi80
        '
        Me.BtnWarnaEfisiensi80.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaEfisiensi80.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaEfisiensi80.Location = New System.Drawing.Point(291, 401)
        Me.BtnWarnaEfisiensi80.Name = "BtnWarnaEfisiensi80"
        Me.BtnWarnaEfisiensi80.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaEfisiensi80.TabIndex = 105
        Me.BtnWarnaEfisiensi80.Text = "SET"
        Me.BtnWarnaEfisiensi80.UseVisualStyleBackColor = True
        '
        'PnlWarnaEfisiensi80
        '
        Me.PnlWarnaEfisiensi80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaEfisiensi80.Location = New System.Drawing.Point(192, 402)
        Me.PnlWarnaEfisiensi80.Name = "PnlWarnaEfisiensi80"
        Me.PnlWarnaEfisiensi80.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaEfisiensi80.TabIndex = 104
        '
        'BtnWarnaEfisiensi0
        '
        Me.BtnWarnaEfisiensi0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaEfisiensi0.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaEfisiensi0.Location = New System.Drawing.Point(291, 363)
        Me.BtnWarnaEfisiensi0.Name = "BtnWarnaEfisiensi0"
        Me.BtnWarnaEfisiensi0.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaEfisiensi0.TabIndex = 103
        Me.BtnWarnaEfisiensi0.Text = "SET"
        Me.BtnWarnaEfisiensi0.UseVisualStyleBackColor = True
        '
        'PnlWarnaEfisiensi0
        '
        Me.PnlWarnaEfisiensi0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaEfisiensi0.Location = New System.Drawing.Point(192, 364)
        Me.PnlWarnaEfisiensi0.Name = "PnlWarnaEfisiensi0"
        Me.PnlWarnaEfisiensi0.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaEfisiensi0.TabIndex = 102
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(15, 454)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(129, 17)
        Me.Label48.TabIndex = 101
        Me.Label48.Text = "EFISIENSI [ 91 - 100 ]"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(15, 409)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(126, 17)
        Me.Label47.TabIndex = 100
        Me.Label47.Text = "EFISIENSI [ 80 - 90 ]"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(15, 364)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(119, 17)
        Me.Label46.TabIndex = 99
        Me.Label46.Text = "EFISIENSI [ 0 - 80 ]"
        '
        'BtnWarnaEfisiensi
        '
        Me.BtnWarnaEfisiensi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaEfisiensi.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaEfisiensi.Location = New System.Drawing.Point(291, 321)
        Me.BtnWarnaEfisiensi.Name = "BtnWarnaEfisiensi"
        Me.BtnWarnaEfisiensi.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaEfisiensi.TabIndex = 71
        Me.BtnWarnaEfisiensi.Text = "SET"
        Me.BtnWarnaEfisiensi.UseVisualStyleBackColor = True
        '
        'PnlWarnaEfisiensi
        '
        Me.PnlWarnaEfisiensi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaEfisiensi.Location = New System.Drawing.Point(192, 322)
        Me.PnlWarnaEfisiensi.Name = "PnlWarnaEfisiensi"
        Me.PnlWarnaEfisiensi.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaEfisiensi.TabIndex = 70
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 322)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 17)
        Me.Label6.TabIndex = 69
        Me.Label6.Text = "EFISIENSI  :"
        '
        'BtnCloseTampilan
        '
        Me.BtnCloseTampilan.BackColor = System.Drawing.Color.Red
        Me.BtnCloseTampilan.FlatAppearance.BorderSize = 0
        Me.BtnCloseTampilan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseTampilan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseTampilan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseTampilan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseTampilan.ForeColor = System.Drawing.Color.White
        Me.BtnCloseTampilan.Location = New System.Drawing.Point(397, 78)
        Me.BtnCloseTampilan.Name = "BtnCloseTampilan"
        Me.BtnCloseTampilan.Size = New System.Drawing.Size(136, 48)
        Me.BtnCloseTampilan.TabIndex = 68
        Me.BtnCloseTampilan.Text = "CLOSE"
        Me.BtnCloseTampilan.UseVisualStyleBackColor = False
        '
        'BtnSaveTampilan
        '
        Me.BtnSaveTampilan.BackColor = System.Drawing.Color.Green
        Me.BtnSaveTampilan.FlatAppearance.BorderSize = 0
        Me.BtnSaveTampilan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSaveTampilan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSaveTampilan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSaveTampilan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSaveTampilan.ForeColor = System.Drawing.Color.White
        Me.BtnSaveTampilan.Location = New System.Drawing.Point(397, 18)
        Me.BtnSaveTampilan.Name = "BtnSaveTampilan"
        Me.BtnSaveTampilan.Size = New System.Drawing.Size(136, 48)
        Me.BtnSaveTampilan.TabIndex = 67
        Me.BtnSaveTampilan.Text = "SAVE DISPLAY CONFIG"
        Me.BtnSaveTampilan.UseVisualStyleBackColor = False
        '
        'BtnWarnaJudul
        '
        Me.BtnWarnaJudul.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaJudul.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaJudul.Location = New System.Drawing.Point(291, 283)
        Me.BtnWarnaJudul.Name = "BtnWarnaJudul"
        Me.BtnWarnaJudul.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaJudul.TabIndex = 66
        Me.BtnWarnaJudul.Text = "SET"
        Me.BtnWarnaJudul.UseVisualStyleBackColor = True
        '
        'PnlWarnaJudul
        '
        Me.PnlWarnaJudul.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaJudul.Location = New System.Drawing.Point(192, 284)
        Me.PnlWarnaJudul.Name = "PnlWarnaJudul"
        Me.PnlWarnaJudul.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaJudul.TabIndex = 65
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(15, 284)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(97, 17)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "LABEL JUDUL  :"
        '
        'BtnWarnaAktual
        '
        Me.BtnWarnaAktual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaAktual.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaAktual.Location = New System.Drawing.Point(291, 245)
        Me.BtnWarnaAktual.Name = "BtnWarnaAktual"
        Me.BtnWarnaAktual.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaAktual.TabIndex = 63
        Me.BtnWarnaAktual.Text = "SET"
        Me.BtnWarnaAktual.UseVisualStyleBackColor = True
        '
        'PnlWarnaAktual
        '
        Me.PnlWarnaAktual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaAktual.Location = New System.Drawing.Point(192, 246)
        Me.PnlWarnaAktual.Name = "PnlWarnaAktual"
        Me.PnlWarnaAktual.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaAktual.TabIndex = 62
        '
        'BtnWarnaTarget
        '
        Me.BtnWarnaTarget.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaTarget.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaTarget.Location = New System.Drawing.Point(291, 207)
        Me.BtnWarnaTarget.Name = "BtnWarnaTarget"
        Me.BtnWarnaTarget.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaTarget.TabIndex = 61
        Me.BtnWarnaTarget.Text = "SET"
        Me.BtnWarnaTarget.UseVisualStyleBackColor = True
        '
        'BtnWarnaDate
        '
        Me.BtnWarnaDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaDate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaDate.Location = New System.Drawing.Point(291, 94)
        Me.BtnWarnaDate.Name = "BtnWarnaDate"
        Me.BtnWarnaDate.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaDate.TabIndex = 55
        Me.BtnWarnaDate.Text = "SET"
        Me.BtnWarnaDate.UseVisualStyleBackColor = True
        '
        'PnlWarnaTarget
        '
        Me.PnlWarnaTarget.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaTarget.Location = New System.Drawing.Point(192, 208)
        Me.PnlWarnaTarget.Name = "PnlWarnaTarget"
        Me.PnlWarnaTarget.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaTarget.TabIndex = 60
        '
        'BtnWarnaModel
        '
        Me.BtnWarnaModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaModel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaModel.Location = New System.Drawing.Point(291, 169)
        Me.BtnWarnaModel.Name = "BtnWarnaModel"
        Me.BtnWarnaModel.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaModel.TabIndex = 59
        Me.BtnWarnaModel.Text = "SET"
        Me.BtnWarnaModel.UseVisualStyleBackColor = True
        '
        'PnlWarnaDate
        '
        Me.PnlWarnaDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaDate.Location = New System.Drawing.Point(192, 95)
        Me.PnlWarnaDate.Name = "PnlWarnaDate"
        Me.PnlWarnaDate.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaDate.TabIndex = 54
        '
        'PnlWarnaModel
        '
        Me.PnlWarnaModel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaModel.Location = New System.Drawing.Point(192, 170)
        Me.PnlWarnaModel.Name = "PnlWarnaModel"
        Me.PnlWarnaModel.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaModel.TabIndex = 58
        '
        'BtnWarnaDay
        '
        Me.BtnWarnaDay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaDay.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaDay.Location = New System.Drawing.Point(291, 56)
        Me.BtnWarnaDay.Name = "BtnWarnaDay"
        Me.BtnWarnaDay.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaDay.TabIndex = 53
        Me.BtnWarnaDay.Text = "SET"
        Me.BtnWarnaDay.UseVisualStyleBackColor = True
        '
        'BtnWarnaTime
        '
        Me.BtnWarnaTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaTime.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaTime.Location = New System.Drawing.Point(291, 131)
        Me.BtnWarnaTime.Name = "BtnWarnaTime"
        Me.BtnWarnaTime.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaTime.TabIndex = 57
        Me.BtnWarnaTime.Text = "SET"
        Me.BtnWarnaTime.UseVisualStyleBackColor = True
        '
        'PnlWarnaDay
        '
        Me.PnlWarnaDay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaDay.Location = New System.Drawing.Point(192, 57)
        Me.PnlWarnaDay.Name = "PnlWarnaDay"
        Me.PnlWarnaDay.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaDay.TabIndex = 52
        '
        'PnlWarnaTime
        '
        Me.PnlWarnaTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaTime.Location = New System.Drawing.Point(192, 132)
        Me.PnlWarnaTime.Name = "PnlWarnaTime"
        Me.PnlWarnaTime.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaTime.TabIndex = 56
        '
        'BtnWarnaTablayout
        '
        Me.BtnWarnaTablayout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaTablayout.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaTablayout.Location = New System.Drawing.Point(291, 18)
        Me.BtnWarnaTablayout.Name = "BtnWarnaTablayout"
        Me.BtnWarnaTablayout.Size = New System.Drawing.Size(88, 32)
        Me.BtnWarnaTablayout.TabIndex = 51
        Me.BtnWarnaTablayout.Text = "SET"
        Me.BtnWarnaTablayout.UseVisualStyleBackColor = True
        '
        'PnlWarnaTabLayout
        '
        Me.PnlWarnaTabLayout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaTabLayout.Location = New System.Drawing.Point(192, 19)
        Me.PnlWarnaTabLayout.Name = "PnlWarnaTabLayout"
        Me.PnlWarnaTabLayout.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaTabLayout.TabIndex = 50
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(15, 246)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(67, 17)
        Me.Label21.TabIndex = 49
        Me.Label21.Text = "AKTUAL  :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(15, 208)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(65, 17)
        Me.Label20.TabIndex = 48
        Me.Label20.Text = "TARGET  :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 17)
        Me.Label3.TabIndex = 47
        Me.Label3.Text = "TIME :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(15, 170)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(63, 17)
        Me.Label14.TabIndex = 46
        Me.Label14.Text = "MODEL  :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(15, 95)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 17)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "DATE :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(15, 18)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(103, 17)
        Me.Label18.TabIndex = 44
        Me.Label18.Text = "BACKGROUND :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(15, 57)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(44, 17)
        Me.Label19.TabIndex = 43
        Me.Label19.Text = "DAY  :"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label43)
        Me.TabPage3.Controls.Add(Me.Label42)
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Controls.Add(Me.BtnFontRunningText)
        Me.TabPage3.Controls.Add(Me.Button1)
        Me.TabPage3.Controls.Add(Me.TxtFontRunningText)
        Me.TabPage3.Controls.Add(Me.Label35)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Controls.Add(Me.GroupBox3)
        Me.TabPage3.Controls.Add(Me.BtnCloseRunningTextSetting)
        Me.TabPage3.Controls.Add(Me.BtnSaveRunningTextConfig)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.TxtSpeed)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.TxtIsiRunningText)
        Me.TabPage3.Controls.Add(Me.Label7)
        Me.TabPage3.Controls.Add(Me.BtnWarnaRunningText)
        Me.TabPage3.Controls.Add(Me.PnlWarnaRunningText)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Location = New System.Drawing.Point(4, 26)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(542, 482)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Running Text"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(132, 459)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(23, 17)
        Me.Label43.TabIndex = 100
        Me.Label43.Text = "---"
        Me.Label43.Visible = False
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(20, 457)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(109, 17)
        Me.Label42.TabIndex = 101
        Me.Label42.Text = "Nama file suara :"
        Me.Label42.Visible = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(18, 423)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(86, 32)
        Me.Button2.TabIndex = 101
        Me.Button2.Text = "Cari file"
        Me.Button2.UseVisualStyleBackColor = False
        Me.Button2.Visible = False
        '
        'BtnFontRunningText
        '
        Me.BtnFontRunningText.BackColor = System.Drawing.Color.Gainsboro
        Me.BtnFontRunningText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontRunningText.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontRunningText.ForeColor = System.Drawing.Color.Maroon
        Me.BtnFontRunningText.Location = New System.Drawing.Point(378, 79)
        Me.BtnFontRunningText.Name = "BtnFontRunningText"
        Me.BtnFontRunningText.Size = New System.Drawing.Size(94, 32)
        Me.BtnFontRunningText.TabIndex = 97
        Me.BtnFontRunningText.Text = "SET"
        Me.BtnFontRunningText.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(117, 423)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 32)
        Me.Button1.TabIndex = 100
        Me.Button1.Text = "Upload file"
        Me.Button1.UseVisualStyleBackColor = False
        Me.Button1.Visible = False
        '
        'TxtFontRunningText
        '
        Me.TxtFontRunningText.Location = New System.Drawing.Point(117, 82)
        Me.TxtFontRunningText.Name = "TxtFontRunningText"
        Me.TxtFontRunningText.ReadOnly = True
        Me.TxtFontRunningText.Size = New System.Drawing.Size(255, 25)
        Me.TxtFontRunningText.TabIndex = 96
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(16, 85)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(47, 17)
        Me.Label35.TabIndex = 95
        Me.Label35.Text = "Font  :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BtnTesSuaraBel)
        Me.GroupBox5.Controls.Add(Me.Lblnamafilesuarabel)
        Me.GroupBox5.Controls.Add(Me.BtnPilihSuaraBel)
        Me.GroupBox5.Controls.Add(Me.Label45)
        Me.GroupBox5.Controls.Add(Me.RBoffBel)
        Me.GroupBox5.Controls.Add(Me.RBonBel)
        Me.GroupBox5.Location = New System.Drawing.Point(18, 337)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(509, 71)
        Me.GroupBox5.TabIndex = 94
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Bel Istirahat :"
        '
        'BtnTesSuaraBel
        '
        Me.BtnTesSuaraBel.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.BtnTesSuaraBel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnTesSuaraBel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal
        Me.BtnTesSuaraBel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTesSuaraBel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTesSuaraBel.ForeColor = System.Drawing.Color.White
        Me.BtnTesSuaraBel.Location = New System.Drawing.Point(373, 21)
        Me.BtnTesSuaraBel.Name = "BtnTesSuaraBel"
        Me.BtnTesSuaraBel.Size = New System.Drawing.Size(38, 40)
        Me.BtnTesSuaraBel.TabIndex = 103
        Me.BtnTesSuaraBel.Text = "Tes"
        Me.BtnTesSuaraBel.UseVisualStyleBackColor = False
        '
        'Lblnamafilesuarabel
        '
        Me.Lblnamafilesuarabel.AutoSize = True
        Me.Lblnamafilesuarabel.Font = New System.Drawing.Font("Segoe UI Light", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblnamafilesuarabel.Location = New System.Drawing.Point(80, 48)
        Me.Lblnamafilesuarabel.Name = "Lblnamafilesuarabel"
        Me.Lblnamafilesuarabel.Size = New System.Drawing.Size(19, 13)
        Me.Lblnamafilesuarabel.TabIndex = 100
        Me.Lblnamafilesuarabel.Text = "---"
        '
        'BtnPilihSuaraBel
        '
        Me.BtnPilihSuaraBel.BackColor = System.Drawing.Color.OrangeRed
        Me.BtnPilihSuaraBel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnPilihSuaraBel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal
        Me.BtnPilihSuaraBel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPilihSuaraBel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPilihSuaraBel.ForeColor = System.Drawing.Color.White
        Me.BtnPilihSuaraBel.Location = New System.Drawing.Point(417, 21)
        Me.BtnPilihSuaraBel.Name = "BtnPilihSuaraBel"
        Me.BtnPilihSuaraBel.Size = New System.Drawing.Size(80, 40)
        Me.BtnPilihSuaraBel.TabIndex = 99
        Me.BtnPilihSuaraBel.Text = "Pilih file"
        Me.BtnPilihSuaraBel.UseVisualStyleBackColor = False
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(2, 48)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(72, 17)
        Me.Label45.TabIndex = 6
        Me.Label45.Text = "Nama file :"
        '
        'RBoffBel
        '
        Me.RBoffBel.AutoSize = True
        Me.RBoffBel.Location = New System.Drawing.Point(59, 24)
        Me.RBoffBel.Name = "RBoffBel"
        Me.RBoffBel.Size = New System.Drawing.Size(44, 21)
        Me.RBoffBel.TabIndex = 3
        Me.RBoffBel.TabStop = True
        Me.RBoffBel.Text = "Off"
        Me.RBoffBel.UseVisualStyleBackColor = True
        '
        'RBonBel
        '
        Me.RBonBel.AutoSize = True
        Me.RBonBel.Location = New System.Drawing.Point(9, 24)
        Me.RBonBel.Name = "RBonBel"
        Me.RBonBel.Size = New System.Drawing.Size(44, 21)
        Me.RBonBel.TabIndex = 2
        Me.RBonBel.TabStop = True
        Me.RBonBel.Text = "On"
        Me.RBonBel.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.BtnTesSuaraTimbangan)
        Me.GroupBox6.Controls.Add(Me.Lblnamafilesuaratimbangan)
        Me.GroupBox6.Controls.Add(Me.BtnPilihSuaraTimbangan)
        Me.GroupBox6.Controls.Add(Me.Label44)
        Me.GroupBox6.Controls.Add(Me.RBoffSuaraTimbang)
        Me.GroupBox6.Controls.Add(Me.RBonSuaraTimbang)
        Me.GroupBox6.Location = New System.Drawing.Point(19, 260)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(508, 71)
        Me.GroupBox6.TabIndex = 93
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Suara Counter  :"
        '
        'BtnTesSuaraTimbangan
        '
        Me.BtnTesSuaraTimbangan.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.BtnTesSuaraTimbangan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnTesSuaraTimbangan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal
        Me.BtnTesSuaraTimbangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTesSuaraTimbangan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTesSuaraTimbangan.ForeColor = System.Drawing.Color.White
        Me.BtnTesSuaraTimbangan.Location = New System.Drawing.Point(372, 21)
        Me.BtnTesSuaraTimbangan.Name = "BtnTesSuaraTimbangan"
        Me.BtnTesSuaraTimbangan.Size = New System.Drawing.Size(38, 40)
        Me.BtnTesSuaraTimbangan.TabIndex = 102
        Me.BtnTesSuaraTimbangan.Text = "Tes"
        Me.BtnTesSuaraTimbangan.UseVisualStyleBackColor = False
        '
        'Lblnamafilesuaratimbangan
        '
        Me.Lblnamafilesuaratimbangan.AutoSize = True
        Me.Lblnamafilesuaratimbangan.Font = New System.Drawing.Font("Segoe UI Light", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblnamafilesuaratimbangan.Location = New System.Drawing.Point(80, 48)
        Me.Lblnamafilesuaratimbangan.Name = "Lblnamafilesuaratimbangan"
        Me.Lblnamafilesuaratimbangan.Size = New System.Drawing.Size(19, 13)
        Me.Lblnamafilesuaratimbangan.TabIndex = 99
        Me.Lblnamafilesuaratimbangan.Text = "---"
        '
        'BtnPilihSuaraTimbangan
        '
        Me.BtnPilihSuaraTimbangan.BackColor = System.Drawing.Color.OrangeRed
        Me.BtnPilihSuaraTimbangan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnPilihSuaraTimbangan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal
        Me.BtnPilihSuaraTimbangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPilihSuaraTimbangan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPilihSuaraTimbangan.ForeColor = System.Drawing.Color.White
        Me.BtnPilihSuaraTimbangan.Location = New System.Drawing.Point(416, 21)
        Me.BtnPilihSuaraTimbangan.Name = "BtnPilihSuaraTimbangan"
        Me.BtnPilihSuaraTimbangan.Size = New System.Drawing.Size(80, 40)
        Me.BtnPilihSuaraTimbangan.TabIndex = 98
        Me.BtnPilihSuaraTimbangan.Text = "Pilih file"
        Me.BtnPilihSuaraTimbangan.UseVisualStyleBackColor = False
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(2, 48)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(72, 17)
        Me.Label44.TabIndex = 5
        Me.Label44.Text = "Nama file :"
        '
        'RBoffSuaraTimbang
        '
        Me.RBoffSuaraTimbang.AutoSize = True
        Me.RBoffSuaraTimbang.Location = New System.Drawing.Point(59, 24)
        Me.RBoffSuaraTimbang.Name = "RBoffSuaraTimbang"
        Me.RBoffSuaraTimbang.Size = New System.Drawing.Size(44, 21)
        Me.RBoffSuaraTimbang.TabIndex = 1
        Me.RBoffSuaraTimbang.TabStop = True
        Me.RBoffSuaraTimbang.Text = "Off"
        Me.RBoffSuaraTimbang.UseVisualStyleBackColor = True
        '
        'RBonSuaraTimbang
        '
        Me.RBonSuaraTimbang.AutoSize = True
        Me.RBonSuaraTimbang.Location = New System.Drawing.Point(9, 24)
        Me.RBonSuaraTimbang.Name = "RBonSuaraTimbang"
        Me.RBonSuaraTimbang.Size = New System.Drawing.Size(44, 21)
        Me.RBonSuaraTimbang.TabIndex = 0
        Me.RBonSuaraTimbang.TabStop = True
        Me.RBonSuaraTimbang.Text = "On"
        Me.RBonSuaraTimbang.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.RBTidakAnimasi)
        Me.GroupBox4.Controls.Add(Me.RBYaAnimasi)
        Me.GroupBox4.Location = New System.Drawing.Point(272, 188)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 58)
        Me.GroupBox4.TabIndex = 92
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Animasi :"
        '
        'RBTidakAnimasi
        '
        Me.RBTidakAnimasi.AutoSize = True
        Me.RBTidakAnimasi.Location = New System.Drawing.Point(103, 24)
        Me.RBTidakAnimasi.Name = "RBTidakAnimasi"
        Me.RBTidakAnimasi.Size = New System.Drawing.Size(58, 21)
        Me.RBTidakAnimasi.TabIndex = 3
        Me.RBTidakAnimasi.TabStop = True
        Me.RBTidakAnimasi.Text = "Tidak"
        Me.RBTidakAnimasi.UseVisualStyleBackColor = True
        '
        'RBYaAnimasi
        '
        Me.RBYaAnimasi.AutoSize = True
        Me.RBYaAnimasi.Location = New System.Drawing.Point(14, 24)
        Me.RBYaAnimasi.Name = "RBYaAnimasi"
        Me.RBYaAnimasi.Size = New System.Drawing.Size(40, 21)
        Me.RBYaAnimasi.TabIndex = 2
        Me.RBYaAnimasi.TabStop = True
        Me.RBYaAnimasi.Text = "Ya"
        Me.RBYaAnimasi.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.RBTidakTampilkan)
        Me.GroupBox3.Controls.Add(Me.RBYaTampilkan)
        Me.GroupBox3.Location = New System.Drawing.Point(19, 188)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 58)
        Me.GroupBox3.TabIndex = 91
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Tampilkan :"
        '
        'RBTidakTampilkan
        '
        Me.RBTidakTampilkan.AutoSize = True
        Me.RBTidakTampilkan.Location = New System.Drawing.Point(98, 24)
        Me.RBTidakTampilkan.Name = "RBTidakTampilkan"
        Me.RBTidakTampilkan.Size = New System.Drawing.Size(58, 21)
        Me.RBTidakTampilkan.TabIndex = 1
        Me.RBTidakTampilkan.TabStop = True
        Me.RBTidakTampilkan.Text = "Tidak"
        Me.RBTidakTampilkan.UseVisualStyleBackColor = True
        '
        'RBYaTampilkan
        '
        Me.RBYaTampilkan.AutoSize = True
        Me.RBYaTampilkan.Location = New System.Drawing.Point(9, 24)
        Me.RBYaTampilkan.Name = "RBYaTampilkan"
        Me.RBYaTampilkan.Size = New System.Drawing.Size(40, 21)
        Me.RBYaTampilkan.TabIndex = 0
        Me.RBYaTampilkan.TabStop = True
        Me.RBYaTampilkan.Text = "Ya"
        Me.RBYaTampilkan.UseVisualStyleBackColor = True
        '
        'BtnCloseRunningTextSetting
        '
        Me.BtnCloseRunningTextSetting.BackColor = System.Drawing.Color.Red
        Me.BtnCloseRunningTextSetting.FlatAppearance.BorderSize = 0
        Me.BtnCloseRunningTextSetting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseRunningTextSetting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseRunningTextSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseRunningTextSetting.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseRunningTextSetting.ForeColor = System.Drawing.Color.White
        Me.BtnCloseRunningTextSetting.Location = New System.Drawing.Point(391, 422)
        Me.BtnCloseRunningTextSetting.Name = "BtnCloseRunningTextSetting"
        Me.BtnCloseRunningTextSetting.Size = New System.Drawing.Size(136, 46)
        Me.BtnCloseRunningTextSetting.TabIndex = 88
        Me.BtnCloseRunningTextSetting.Text = "CLOSE"
        Me.BtnCloseRunningTextSetting.UseVisualStyleBackColor = False
        '
        'BtnSaveRunningTextConfig
        '
        Me.BtnSaveRunningTextConfig.BackColor = System.Drawing.Color.Green
        Me.BtnSaveRunningTextConfig.FlatAppearance.BorderSize = 0
        Me.BtnSaveRunningTextConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSaveRunningTextConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSaveRunningTextConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSaveRunningTextConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSaveRunningTextConfig.ForeColor = System.Drawing.Color.White
        Me.BtnSaveRunningTextConfig.Location = New System.Drawing.Point(249, 422)
        Me.BtnSaveRunningTextConfig.Name = "BtnSaveRunningTextConfig"
        Me.BtnSaveRunningTextConfig.Size = New System.Drawing.Size(136, 46)
        Me.BtnSaveRunningTextConfig.TabIndex = 87
        Me.BtnSaveRunningTextConfig.Text = "SAVE RUNNING TEXT CONFIG"
        Me.BtnSaveRunningTextConfig.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(216, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 17)
        Me.Label11.TabIndex = 86
        Me.Label11.Text = "Milidetik"
        '
        'TxtSpeed
        '
        Me.TxtSpeed.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtSpeed.ForeColor = System.Drawing.Color.Red
        Me.TxtSpeed.Location = New System.Drawing.Point(117, 6)
        Me.TxtSpeed.MaxLength = 4
        Me.TxtSpeed.Name = "TxtSpeed"
        Me.TxtSpeed.Size = New System.Drawing.Size(93, 25)
        Me.TxtSpeed.TabIndex = 85
        Me.TxtSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(16, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 17)
        Me.Label10.TabIndex = 84
        Me.Label10.Text = "Speed :"
        '
        'TxtIsiRunningText
        '
        Me.TxtIsiRunningText.Location = New System.Drawing.Point(117, 121)
        Me.TxtIsiRunningText.MaxLength = 1000
        Me.TxtIsiRunningText.Multiline = True
        Me.TxtIsiRunningText.Name = "TxtIsiRunningText"
        Me.TxtIsiRunningText.Size = New System.Drawing.Size(355, 66)
        Me.TxtIsiRunningText.TabIndex = 83
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 121)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 17)
        Me.Label7.TabIndex = 82
        Me.Label7.Text = "Kalimat :"
        '
        'BtnWarnaRunningText
        '
        Me.BtnWarnaRunningText.BackColor = System.Drawing.Color.Blue
        Me.BtnWarnaRunningText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWarnaRunningText.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWarnaRunningText.ForeColor = System.Drawing.Color.White
        Me.BtnWarnaRunningText.Location = New System.Drawing.Point(216, 36)
        Me.BtnWarnaRunningText.Name = "BtnWarnaRunningText"
        Me.BtnWarnaRunningText.Size = New System.Drawing.Size(59, 32)
        Me.BtnWarnaRunningText.TabIndex = 81
        Me.BtnWarnaRunningText.Text = "SET"
        Me.BtnWarnaRunningText.UseVisualStyleBackColor = False
        '
        'PnlWarnaRunningText
        '
        Me.PnlWarnaRunningText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlWarnaRunningText.Location = New System.Drawing.Point(117, 37)
        Me.PnlWarnaRunningText.Name = "PnlWarnaRunningText"
        Me.PnlWarnaRunningText.Size = New System.Drawing.Size(93, 31)
        Me.PnlWarnaRunningText.TabIndex = 80
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(16, 43)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 17)
        Me.Label8.TabIndex = 79
        Me.Label8.Text = "Text Color  :"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.BtnCloseArduinoConfig)
        Me.TabPage4.Controls.Add(Me.BtnArduinoConfig)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 26)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(542, 482)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Arduino"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'BtnCloseArduinoConfig
        '
        Me.BtnCloseArduinoConfig.BackColor = System.Drawing.Color.Red
        Me.BtnCloseArduinoConfig.FlatAppearance.BorderSize = 0
        Me.BtnCloseArduinoConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseArduinoConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseArduinoConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseArduinoConfig.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseArduinoConfig.ForeColor = System.Drawing.Color.White
        Me.BtnCloseArduinoConfig.Location = New System.Drawing.Point(266, 67)
        Me.BtnCloseArduinoConfig.Name = "BtnCloseArduinoConfig"
        Me.BtnCloseArduinoConfig.Size = New System.Drawing.Size(136, 48)
        Me.BtnCloseArduinoConfig.TabIndex = 60
        Me.BtnCloseArduinoConfig.Text = "CLOSE"
        Me.BtnCloseArduinoConfig.UseVisualStyleBackColor = False
        '
        'BtnArduinoConfig
        '
        Me.BtnArduinoConfig.BackColor = System.Drawing.Color.Green
        Me.BtnArduinoConfig.FlatAppearance.BorderSize = 0
        Me.BtnArduinoConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnArduinoConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnArduinoConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnArduinoConfig.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnArduinoConfig.ForeColor = System.Drawing.Color.White
        Me.BtnArduinoConfig.Location = New System.Drawing.Point(266, 13)
        Me.BtnArduinoConfig.Name = "BtnArduinoConfig"
        Me.BtnArduinoConfig.Size = New System.Drawing.Size(136, 48)
        Me.BtnArduinoConfig.TabIndex = 59
        Me.BtnArduinoConfig.Text = "SAVE ARDUINO CONFIG"
        Me.BtnArduinoConfig.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.RBNonActive)
        Me.GroupBox7.Controls.Add(Me.RBActive)
        Me.GroupBox7.Controls.Add(Me.Label26)
        Me.GroupBox7.Controls.Add(Me.Label24)
        Me.GroupBox7.Controls.Add(Me.CmbPortArduino)
        Me.GroupBox7.Controls.Add(Me.CmbBaudRateArduino)
        Me.GroupBox7.Controls.Add(Me.Label25)
        Me.GroupBox7.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(239, 109)
        Me.GroupBox7.TabIndex = 58
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Arduino Setting"
        '
        'RBNonActive
        '
        Me.RBNonActive.AutoSize = True
        Me.RBNonActive.Location = New System.Drawing.Point(168, 86)
        Me.RBNonActive.Name = "RBNonActive"
        Me.RBNonActive.Size = New System.Drawing.Size(53, 17)
        Me.RBNonActive.TabIndex = 40
        Me.RBNonActive.TabStop = True
        Me.RBNonActive.Text = "Tidak"
        Me.RBNonActive.UseVisualStyleBackColor = True
        '
        'RBActive
        '
        Me.RBActive.AutoSize = True
        Me.RBActive.Location = New System.Drawing.Point(96, 86)
        Me.RBActive.Name = "RBActive"
        Me.RBActive.Size = New System.Drawing.Size(36, 17)
        Me.RBActive.TabIndex = 39
        Me.RBActive.TabStop = True
        Me.RBActive.Text = "Ya"
        Me.RBActive.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(1, 78)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(62, 17)
        Me.Label26.TabIndex = 38
        Me.Label26.Text = "ACTIVE  :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(1, 20)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(86, 17)
        Me.Label24.TabIndex = 37
        Me.Label24.Text = "COM  PORT :"
        '
        'CmbPortArduino
        '
        Me.CmbPortArduino.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbPortArduino.FormattingEnabled = True
        Me.CmbPortArduino.Location = New System.Drawing.Point(96, 20)
        Me.CmbPortArduino.Name = "CmbPortArduino"
        Me.CmbPortArduino.Size = New System.Drawing.Size(125, 25)
        Me.CmbPortArduino.TabIndex = 36
        '
        'CmbBaudRateArduino
        '
        Me.CmbBaudRateArduino.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBaudRateArduino.FormattingEnabled = True
        Me.CmbBaudRateArduino.Items.AddRange(New Object() {"1200", "2400", "4800", "7200", "9600"})
        Me.CmbBaudRateArduino.Location = New System.Drawing.Point(96, 52)
        Me.CmbBaudRateArduino.Name = "CmbBaudRateArduino"
        Me.CmbBaudRateArduino.Size = New System.Drawing.Size(125, 25)
        Me.CmbBaudRateArduino.TabIndex = 32
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(1, 51)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(84, 17)
        Me.Label25.TabIndex = 33
        Me.Label25.Text = "BAUD RATE :"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.BtnFontEfiseinsi)
        Me.TabPage5.Controls.Add(Me.BtnFontJudul)
        Me.TabPage5.Controls.Add(Me.BtnFontAktual)
        Me.TabPage5.Controls.Add(Me.BtnFontTime)
        Me.TabPage5.Controls.Add(Me.BtnFontTarget)
        Me.TabPage5.Controls.Add(Me.BtnFontDate)
        Me.TabPage5.Controls.Add(Me.BtnFontModel)
        Me.TabPage5.Controls.Add(Me.BtnFontDay)
        Me.TabPage5.Controls.Add(Me.CmbFontEfisiensi)
        Me.TabPage5.Controls.Add(Me.CmbFontJudul)
        Me.TabPage5.Controls.Add(Me.CmbFontAktual)
        Me.TabPage5.Controls.Add(Me.CmbFontTarget)
        Me.TabPage5.Controls.Add(Me.CmbFontModel)
        Me.TabPage5.Controls.Add(Me.CmbFontTime)
        Me.TabPage5.Controls.Add(Me.CmbFontDate)
        Me.TabPage5.Controls.Add(Me.CmbFontDay)
        Me.TabPage5.Controls.Add(Me.Label27)
        Me.TabPage5.Controls.Add(Me.BtnCloseFontConfig)
        Me.TabPage5.Controls.Add(Me.BtnSaveFontConfig)
        Me.TabPage5.Controls.Add(Me.Label28)
        Me.TabPage5.Controls.Add(Me.Label29)
        Me.TabPage5.Controls.Add(Me.Label30)
        Me.TabPage5.Controls.Add(Me.Label31)
        Me.TabPage5.Controls.Add(Me.Label32)
        Me.TabPage5.Controls.Add(Me.Label33)
        Me.TabPage5.Controls.Add(Me.Label34)
        Me.TabPage5.Location = New System.Drawing.Point(4, 26)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(542, 482)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Font Size"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'BtnFontEfiseinsi
        '
        Me.BtnFontEfiseinsi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontEfiseinsi.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontEfiseinsi.Location = New System.Drawing.Point(248, 293)
        Me.BtnFontEfiseinsi.Name = "BtnFontEfiseinsi"
        Me.BtnFontEfiseinsi.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontEfiseinsi.TabIndex = 95
        Me.BtnFontEfiseinsi.Text = "SET"
        Me.BtnFontEfiseinsi.UseVisualStyleBackColor = True
        '
        'BtnFontJudul
        '
        Me.BtnFontJudul.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontJudul.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontJudul.Location = New System.Drawing.Point(248, 255)
        Me.BtnFontJudul.Name = "BtnFontJudul"
        Me.BtnFontJudul.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontJudul.TabIndex = 94
        Me.BtnFontJudul.Text = "SET"
        Me.BtnFontJudul.UseVisualStyleBackColor = True
        '
        'BtnFontAktual
        '
        Me.BtnFontAktual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontAktual.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontAktual.Location = New System.Drawing.Point(248, 217)
        Me.BtnFontAktual.Name = "BtnFontAktual"
        Me.BtnFontAktual.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontAktual.TabIndex = 93
        Me.BtnFontAktual.Text = "SET"
        Me.BtnFontAktual.UseVisualStyleBackColor = True
        '
        'BtnFontTime
        '
        Me.BtnFontTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontTime.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontTime.Location = New System.Drawing.Point(248, 104)
        Me.BtnFontTime.Name = "BtnFontTime"
        Me.BtnFontTime.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontTime.TabIndex = 90
        Me.BtnFontTime.Text = "SET"
        Me.BtnFontTime.UseVisualStyleBackColor = True
        '
        'BtnFontTarget
        '
        Me.BtnFontTarget.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontTarget.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontTarget.Location = New System.Drawing.Point(248, 179)
        Me.BtnFontTarget.Name = "BtnFontTarget"
        Me.BtnFontTarget.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontTarget.TabIndex = 92
        Me.BtnFontTarget.Text = "SET"
        Me.BtnFontTarget.UseVisualStyleBackColor = True
        '
        'BtnFontDate
        '
        Me.BtnFontDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontDate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontDate.Location = New System.Drawing.Point(248, 66)
        Me.BtnFontDate.Name = "BtnFontDate"
        Me.BtnFontDate.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontDate.TabIndex = 89
        Me.BtnFontDate.Text = "SET"
        Me.BtnFontDate.UseVisualStyleBackColor = True
        '
        'BtnFontModel
        '
        Me.BtnFontModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontModel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontModel.Location = New System.Drawing.Point(248, 141)
        Me.BtnFontModel.Name = "BtnFontModel"
        Me.BtnFontModel.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontModel.TabIndex = 91
        Me.BtnFontModel.Text = "SET"
        Me.BtnFontModel.UseVisualStyleBackColor = True
        '
        'BtnFontDay
        '
        Me.BtnFontDay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFontDay.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFontDay.Location = New System.Drawing.Point(248, 28)
        Me.BtnFontDay.Name = "BtnFontDay"
        Me.BtnFontDay.Size = New System.Drawing.Size(88, 32)
        Me.BtnFontDay.TabIndex = 88
        Me.BtnFontDay.Text = "SET"
        Me.BtnFontDay.UseVisualStyleBackColor = True
        '
        'CmbFontEfisiensi
        '
        Me.CmbFontEfisiensi.FormattingEnabled = True
        Me.CmbFontEfisiensi.Location = New System.Drawing.Point(104, 294)
        Me.CmbFontEfisiensi.Name = "CmbFontEfisiensi"
        Me.CmbFontEfisiensi.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontEfisiensi.TabIndex = 87
        '
        'CmbFontJudul
        '
        Me.CmbFontJudul.FormattingEnabled = True
        Me.CmbFontJudul.Location = New System.Drawing.Point(104, 258)
        Me.CmbFontJudul.Name = "CmbFontJudul"
        Me.CmbFontJudul.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontJudul.TabIndex = 86
        '
        'CmbFontAktual
        '
        Me.CmbFontAktual.FormattingEnabled = True
        Me.CmbFontAktual.Location = New System.Drawing.Point(104, 218)
        Me.CmbFontAktual.Name = "CmbFontAktual"
        Me.CmbFontAktual.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontAktual.TabIndex = 85
        '
        'CmbFontTarget
        '
        Me.CmbFontTarget.FormattingEnabled = True
        Me.CmbFontTarget.Location = New System.Drawing.Point(104, 182)
        Me.CmbFontTarget.Name = "CmbFontTarget"
        Me.CmbFontTarget.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontTarget.TabIndex = 84
        '
        'CmbFontModel
        '
        Me.CmbFontModel.FormattingEnabled = True
        Me.CmbFontModel.Location = New System.Drawing.Point(104, 142)
        Me.CmbFontModel.Name = "CmbFontModel"
        Me.CmbFontModel.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontModel.TabIndex = 83
        '
        'CmbFontTime
        '
        Me.CmbFontTime.FormattingEnabled = True
        Me.CmbFontTime.Location = New System.Drawing.Point(104, 106)
        Me.CmbFontTime.Name = "CmbFontTime"
        Me.CmbFontTime.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontTime.TabIndex = 82
        '
        'CmbFontDate
        '
        Me.CmbFontDate.FormattingEnabled = True
        Me.CmbFontDate.Location = New System.Drawing.Point(104, 66)
        Me.CmbFontDate.Name = "CmbFontDate"
        Me.CmbFontDate.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontDate.TabIndex = 81
        '
        'CmbFontDay
        '
        Me.CmbFontDay.FormattingEnabled = True
        Me.CmbFontDay.Location = New System.Drawing.Point(104, 30)
        Me.CmbFontDay.Name = "CmbFontDay"
        Me.CmbFontDay.Size = New System.Drawing.Size(142, 25)
        Me.CmbFontDay.TabIndex = 80
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(3, 296)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(76, 17)
        Me.Label27.TabIndex = 79
        Me.Label27.Text = "EFISIENSI  :"
        '
        'BtnCloseFontConfig
        '
        Me.BtnCloseFontConfig.BackColor = System.Drawing.Color.Red
        Me.BtnCloseFontConfig.FlatAppearance.BorderSize = 0
        Me.BtnCloseFontConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseFontConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseFontConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseFontConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseFontConfig.ForeColor = System.Drawing.Color.White
        Me.BtnCloseFontConfig.Location = New System.Drawing.Point(342, 90)
        Me.BtnCloseFontConfig.Name = "BtnCloseFontConfig"
        Me.BtnCloseFontConfig.Size = New System.Drawing.Size(136, 48)
        Me.BtnCloseFontConfig.TabIndex = 78
        Me.BtnCloseFontConfig.Text = "CLOSE"
        Me.BtnCloseFontConfig.UseVisualStyleBackColor = False
        '
        'BtnSaveFontConfig
        '
        Me.BtnSaveFontConfig.BackColor = System.Drawing.Color.Green
        Me.BtnSaveFontConfig.FlatAppearance.BorderSize = 0
        Me.BtnSaveFontConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSaveFontConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSaveFontConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSaveFontConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSaveFontConfig.ForeColor = System.Drawing.Color.White
        Me.BtnSaveFontConfig.Location = New System.Drawing.Point(342, 30)
        Me.BtnSaveFontConfig.Name = "BtnSaveFontConfig"
        Me.BtnSaveFontConfig.Size = New System.Drawing.Size(136, 48)
        Me.BtnSaveFontConfig.TabIndex = 77
        Me.BtnSaveFontConfig.Text = "SAVE FONT CONFIG"
        Me.BtnSaveFontConfig.UseVisualStyleBackColor = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(3, 258)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(97, 17)
        Me.Label28.TabIndex = 76
        Me.Label28.Text = "LABEL JUDUL  :"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(3, 220)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(67, 17)
        Me.Label29.TabIndex = 75
        Me.Label29.Text = "AKTUAL  :"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(3, 182)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(65, 17)
        Me.Label30.TabIndex = 74
        Me.Label30.Text = "TARGET  :"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(3, 106)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(45, 17)
        Me.Label31.TabIndex = 73
        Me.Label31.Text = "TIME :"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(3, 144)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(63, 17)
        Me.Label32.TabIndex = 72
        Me.Label32.Text = "MODEL  :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(3, 69)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(46, 17)
        Me.Label33.TabIndex = 71
        Me.Label33.Text = "DATE :"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(3, 31)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(44, 17)
        Me.Label34.TabIndex = 70
        Me.Label34.Text = "DAY  :"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox8)
        Me.TabPage6.Location = New System.Drawing.Point(4, 26)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(542, 482)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Adjustment"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.BtnCloseAdjustment)
        Me.GroupBox8.Controls.Add(Me.Label38)
        Me.GroupBox8.Controls.Add(Me.TxtAdjustStartTime)
        Me.GroupBox8.Controls.Add(Me.Label37)
        Me.GroupBox8.Controls.Add(Me.TxtAdjustTarget)
        Me.GroupBox8.Controls.Add(Me.Label36)
        Me.GroupBox8.Controls.Add(Me.BtnSetToDisplay)
        Me.GroupBox8.Controls.Add(Me.BtnSetAktualTebaru)
        Me.GroupBox8.Controls.Add(Me.TxtAdjustAktual)
        Me.GroupBox8.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(233, 330)
        Me.GroupBox8.TabIndex = 64
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Adjustment"
        '
        'BtnCloseAdjustment
        '
        Me.BtnCloseAdjustment.BackColor = System.Drawing.Color.Red
        Me.BtnCloseAdjustment.FlatAppearance.BorderSize = 0
        Me.BtnCloseAdjustment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseAdjustment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseAdjustment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseAdjustment.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseAdjustment.ForeColor = System.Drawing.Color.White
        Me.BtnCloseAdjustment.Location = New System.Drawing.Point(16, 275)
        Me.BtnCloseAdjustment.Name = "BtnCloseAdjustment"
        Me.BtnCloseAdjustment.Size = New System.Drawing.Size(186, 36)
        Me.BtnCloseAdjustment.TabIndex = 79
        Me.BtnCloseAdjustment.Text = "CLOSE"
        Me.BtnCloseAdjustment.UseVisualStyleBackColor = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(13, 131)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(70, 17)
        Me.Label38.TabIndex = 69
        Me.Label38.Text = "Start Time"
        '
        'TxtAdjustStartTime
        '
        Me.TxtAdjustStartTime.Location = New System.Drawing.Point(16, 151)
        Me.TxtAdjustStartTime.MaxLength = 8
        Me.TxtAdjustStartTime.Name = "TxtAdjustStartTime"
        Me.TxtAdjustStartTime.Size = New System.Drawing.Size(186, 25)
        Me.TxtAdjustStartTime.TabIndex = 68
        Me.TxtAdjustStartTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(13, 81)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(88, 17)
        Me.Label37.TabIndex = 67
        Me.Label37.Text = "Actual Target"
        '
        'TxtAdjustTarget
        '
        Me.TxtAdjustTarget.Location = New System.Drawing.Point(16, 101)
        Me.TxtAdjustTarget.MaxLength = 8
        Me.TxtAdjustTarget.Name = "TxtAdjustTarget"
        Me.TxtAdjustTarget.Size = New System.Drawing.Size(186, 25)
        Me.TxtAdjustTarget.TabIndex = 66
        Me.TxtAdjustTarget.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(13, 32)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(74, 17)
        Me.Label36.TabIndex = 64
        Me.Label36.Text = "Actual QTY"
        '
        'BtnSetToDisplay
        '
        Me.BtnSetToDisplay.BackColor = System.Drawing.Color.DarkOrange
        Me.BtnSetToDisplay.FlatAppearance.BorderSize = 0
        Me.BtnSetToDisplay.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSetToDisplay.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSetToDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetToDisplay.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSetToDisplay.ForeColor = System.Drawing.Color.White
        Me.BtnSetToDisplay.Location = New System.Drawing.Point(16, 234)
        Me.BtnSetToDisplay.Name = "BtnSetToDisplay"
        Me.BtnSetToDisplay.Size = New System.Drawing.Size(186, 34)
        Me.BtnSetToDisplay.TabIndex = 65
        Me.BtnSetToDisplay.Text = "Set To Display"
        Me.BtnSetToDisplay.UseVisualStyleBackColor = False
        '
        'BtnSetAktualTebaru
        '
        Me.BtnSetAktualTebaru.BackColor = System.Drawing.Color.SeaGreen
        Me.BtnSetAktualTebaru.FlatAppearance.BorderSize = 0
        Me.BtnSetAktualTebaru.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSetAktualTebaru.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSetAktualTebaru.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetAktualTebaru.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSetAktualTebaru.ForeColor = System.Drawing.Color.White
        Me.BtnSetAktualTebaru.Location = New System.Drawing.Point(16, 193)
        Me.BtnSetAktualTebaru.Name = "BtnSetAktualTebaru"
        Me.BtnSetAktualTebaru.Size = New System.Drawing.Size(186, 34)
        Me.BtnSetAktualTebaru.TabIndex = 64
        Me.BtnSetAktualTebaru.Text = "SAVE"
        Me.BtnSetAktualTebaru.UseVisualStyleBackColor = False
        '
        'TxtAdjustAktual
        '
        Me.TxtAdjustAktual.Location = New System.Drawing.Point(16, 52)
        Me.TxtAdjustAktual.MaxLength = 8
        Me.TxtAdjustAktual.Name = "TxtAdjustAktual"
        Me.TxtAdjustAktual.Size = New System.Drawing.Size(186, 25)
        Me.TxtAdjustAktual.TabIndex = 0
        Me.TxtAdjustAktual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.BtnCloseShiftConfig)
        Me.TabPage7.Controls.Add(Me.BtnSaveShiftConfig)
        Me.TabPage7.Controls.Add(Me.gblembur)
        Me.TabPage7.Location = New System.Drawing.Point(4, 26)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(542, 482)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Shift"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'BtnCloseShiftConfig
        '
        Me.BtnCloseShiftConfig.BackColor = System.Drawing.Color.Red
        Me.BtnCloseShiftConfig.FlatAppearance.BorderSize = 0
        Me.BtnCloseShiftConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnCloseShiftConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnCloseShiftConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCloseShiftConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCloseShiftConfig.ForeColor = System.Drawing.Color.White
        Me.BtnCloseShiftConfig.Location = New System.Drawing.Point(194, 75)
        Me.BtnCloseShiftConfig.Name = "BtnCloseShiftConfig"
        Me.BtnCloseShiftConfig.Size = New System.Drawing.Size(146, 48)
        Me.BtnCloseShiftConfig.TabIndex = 80
        Me.BtnCloseShiftConfig.Text = "CLOSE"
        Me.BtnCloseShiftConfig.UseVisualStyleBackColor = False
        '
        'BtnSaveShiftConfig
        '
        Me.BtnSaveShiftConfig.BackColor = System.Drawing.Color.Green
        Me.BtnSaveShiftConfig.FlatAppearance.BorderSize = 0
        Me.BtnSaveShiftConfig.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal
        Me.BtnSaveShiftConfig.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnSaveShiftConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSaveShiftConfig.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSaveShiftConfig.ForeColor = System.Drawing.Color.White
        Me.BtnSaveShiftConfig.Location = New System.Drawing.Point(194, 15)
        Me.BtnSaveShiftConfig.Name = "BtnSaveShiftConfig"
        Me.BtnSaveShiftConfig.Size = New System.Drawing.Size(146, 48)
        Me.BtnSaveShiftConfig.TabIndex = 79
        Me.BtnSaveShiftConfig.Text = "SAVE SHIFT CONFIG"
        Me.BtnSaveShiftConfig.UseVisualStyleBackColor = False
        '
        'gblembur
        '
        Me.gblembur.Controls.Add(Me.GroupBox10)
        Me.gblembur.Controls.Add(Me.GroupBox9)
        Me.gblembur.Controls.Add(Me.GBShift1)
        Me.gblembur.Controls.Add(Me.Label41)
        Me.gblembur.Controls.Add(Me.Label40)
        Me.gblembur.Controls.Add(Me.Label39)
        Me.gblembur.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gblembur.Location = New System.Drawing.Point(8, 6)
        Me.gblembur.Name = "gblembur"
        Me.gblembur.Size = New System.Drawing.Size(174, 262)
        Me.gblembur.TabIndex = 39
        Me.gblembur.TabStop = False
        Me.gblembur.Text = "Shift Setting"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.RBTidakAktifShift3)
        Me.GroupBox10.Controls.Add(Me.RBYaAktifShift3)
        Me.GroupBox10.Location = New System.Drawing.Point(9, 183)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(144, 49)
        Me.GroupBox10.TabIndex = 42
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Aktif"
        '
        'RBTidakAktifShift3
        '
        Me.RBTidakAktifShift3.AutoSize = True
        Me.RBTidakAktifShift3.Location = New System.Drawing.Point(77, 21)
        Me.RBTidakAktifShift3.Name = "RBTidakAktifShift3"
        Me.RBTidakAktifShift3.Size = New System.Drawing.Size(53, 17)
        Me.RBTidakAktifShift3.TabIndex = 5
        Me.RBTidakAktifShift3.TabStop = True
        Me.RBTidakAktifShift3.Text = "Tidak"
        Me.RBTidakAktifShift3.UseVisualStyleBackColor = True
        '
        'RBYaAktifShift3
        '
        Me.RBYaAktifShift3.AutoSize = True
        Me.RBYaAktifShift3.Location = New System.Drawing.Point(16, 21)
        Me.RBYaAktifShift3.Name = "RBYaAktifShift3"
        Me.RBYaAktifShift3.Size = New System.Drawing.Size(36, 17)
        Me.RBYaAktifShift3.TabIndex = 4
        Me.RBYaAktifShift3.TabStop = True
        Me.RBYaAktifShift3.Text = "Ya"
        Me.RBYaAktifShift3.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.RBTidakAktifShift2)
        Me.GroupBox9.Controls.Add(Me.RBYaAktifShift2)
        Me.GroupBox9.Location = New System.Drawing.Point(9, 111)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(144, 49)
        Me.GroupBox9.TabIndex = 41
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Aktif"
        '
        'RBTidakAktifShift2
        '
        Me.RBTidakAktifShift2.AutoSize = True
        Me.RBTidakAktifShift2.Location = New System.Drawing.Point(77, 21)
        Me.RBTidakAktifShift2.Name = "RBTidakAktifShift2"
        Me.RBTidakAktifShift2.Size = New System.Drawing.Size(53, 17)
        Me.RBTidakAktifShift2.TabIndex = 3
        Me.RBTidakAktifShift2.TabStop = True
        Me.RBTidakAktifShift2.Text = "Tidak"
        Me.RBTidakAktifShift2.UseVisualStyleBackColor = True
        '
        'RBYaAktifShift2
        '
        Me.RBYaAktifShift2.AutoSize = True
        Me.RBYaAktifShift2.Location = New System.Drawing.Point(16, 21)
        Me.RBYaAktifShift2.Name = "RBYaAktifShift2"
        Me.RBYaAktifShift2.Size = New System.Drawing.Size(36, 17)
        Me.RBYaAktifShift2.TabIndex = 2
        Me.RBYaAktifShift2.TabStop = True
        Me.RBYaAktifShift2.Text = "Ya"
        Me.RBYaAktifShift2.UseVisualStyleBackColor = True
        '
        'GBShift1
        '
        Me.GBShift1.Controls.Add(Me.RBTidakLembur)
        Me.GBShift1.Controls.Add(Me.RBYaLembur)
        Me.GBShift1.Location = New System.Drawing.Point(9, 40)
        Me.GBShift1.Name = "GBShift1"
        Me.GBShift1.Size = New System.Drawing.Size(144, 49)
        Me.GBShift1.TabIndex = 40
        Me.GBShift1.TabStop = False
        Me.GBShift1.Text = "Lembur"
        '
        'RBTidakLembur
        '
        Me.RBTidakLembur.AutoSize = True
        Me.RBTidakLembur.Location = New System.Drawing.Point(77, 22)
        Me.RBTidakLembur.Name = "RBTidakLembur"
        Me.RBTidakLembur.Size = New System.Drawing.Size(53, 17)
        Me.RBTidakLembur.TabIndex = 1
        Me.RBTidakLembur.TabStop = True
        Me.RBTidakLembur.Text = "Tidak"
        Me.RBTidakLembur.UseVisualStyleBackColor = True
        '
        'RBYaLembur
        '
        Me.RBYaLembur.AutoSize = True
        Me.RBYaLembur.Location = New System.Drawing.Point(16, 22)
        Me.RBYaLembur.Name = "RBYaLembur"
        Me.RBYaLembur.Size = New System.Drawing.Size(36, 17)
        Me.RBYaLembur.TabIndex = 0
        Me.RBYaLembur.TabStop = True
        Me.RBYaLembur.Text = "Ya"
        Me.RBYaLembur.UseVisualStyleBackColor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(6, 163)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(61, 17)
        Me.Label41.TabIndex = 39
        Me.Label41.Text = "SHIFT 3 :"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(6, 91)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(65, 17)
        Me.Label40.TabIndex = 38
        Me.Label40.Text = "SHIFT 2  :"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(12, 18)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(59, 17)
        Me.Label39.TabIndex = 37
        Me.Label39.Text = "SHIFT 1 :"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FormSetting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(550, 512)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "FormSetting"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Setting"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.PanelSetting.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.gblembur.ResumeLayout(False)
        Me.gblembur.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GBShift1.ResumeLayout(False)
        Me.GBShift1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents PanelSetting As Panel
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TxtKelipatan As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtTarget As TextBox
    Friend WithEvents BtnCloseTimbanganConfig As Button
    Friend WithEvents BtnSaveTimbanganConfig As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TxtMaxWeight As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtDetik As TextBox
    Friend WithEvents TxtMinWeight As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents CmbPort As ComboBox
    Friend WithEvents CmbBaudRate As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents BtnWarnaJudul As Button
    Friend WithEvents PnlWarnaJudul As Panel
    Friend WithEvents Label22 As Label
    Friend WithEvents BtnWarnaAktual As Button
    Friend WithEvents PnlWarnaAktual As Panel
    Friend WithEvents BtnWarnaTarget As Button
    Friend WithEvents BtnWarnaDate As Button
    Friend WithEvents PnlWarnaTarget As Panel
    Friend WithEvents BtnWarnaModel As Button
    Friend WithEvents PnlWarnaDate As Panel
    Friend WithEvents PnlWarnaModel As Panel
    Friend WithEvents BtnWarnaDay As Button
    Friend WithEvents BtnWarnaTime As Button
    Friend WithEvents PnlWarnaDay As Panel
    Friend WithEvents PnlWarnaTime As Panel
    Friend WithEvents BtnWarnaTablayout As Button
    Friend WithEvents PnlWarnaTabLayout As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TxtPlanning As TextBox
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents BtnCloseTampilan As Button
    Friend WithEvents BtnSaveTampilan As Button
    Friend WithEvents BtnWarnaEfisiensi As Button
    Friend WithEvents PnlWarnaEfisiensi As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TxtIsiRunningText As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents BtnWarnaRunningText As Button
    Friend WithEvents PnlWarnaRunningText As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TxtSpeed As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents BtnCloseRunningTextSetting As Button
    Friend WithEvents BtnSaveRunningTextConfig As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents RBTidakAnimasi As RadioButton
    Friend WithEvents RBYaAnimasi As RadioButton
    Friend WithEvents RBTidakTampilkan As RadioButton
    Friend WithEvents RBYaTampilkan As RadioButton
    Friend WithEvents CmbModel As ComboBox
    Friend WithEvents CmbLine As ComboBox
    Friend WithEvents Label23 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents RBoffBel As RadioButton
    Friend WithEvents RBonBel As RadioButton
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents RBoffSuaraTimbang As RadioButton
    Friend WithEvents RBonSuaraTimbang As RadioButton
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents BtnCloseArduinoConfig As Button
    Friend WithEvents BtnArduinoConfig As Button
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents RBNonActive As RadioButton
    Friend WithEvents RBActive As RadioButton
    Friend WithEvents Label26 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents CmbPortArduino As ComboBox
    Friend WithEvents CmbBaudRateArduino As ComboBox
    Friend WithEvents Label25 As Label
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents BtnFontEfiseinsi As Button
    Friend WithEvents BtnFontJudul As Button
    Friend WithEvents BtnFontAktual As Button
    Friend WithEvents BtnFontTime As Button
    Friend WithEvents BtnFontTarget As Button
    Friend WithEvents BtnFontDate As Button
    Friend WithEvents BtnFontModel As Button
    Friend WithEvents BtnFontDay As Button
    Friend WithEvents CmbFontEfisiensi As ComboBox
    Friend WithEvents CmbFontJudul As ComboBox
    Friend WithEvents CmbFontAktual As ComboBox
    Friend WithEvents CmbFontTarget As ComboBox
    Friend WithEvents CmbFontModel As ComboBox
    Friend WithEvents CmbFontTime As ComboBox
    Friend WithEvents CmbFontDate As ComboBox
    Friend WithEvents CmbFontDay As ComboBox
    Friend WithEvents Label27 As Label
    Friend WithEvents BtnCloseFontConfig As Button
    Friend WithEvents BtnSaveFontConfig As Button
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents FontDialog1 As FontDialog
    Friend WithEvents TxtFontRunningText As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents BtnFontRunningText As Button
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents BtnCloseAdjustment As Button
    Friend WithEvents Label38 As Label
    Friend WithEvents TxtAdjustStartTime As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents TxtAdjustTarget As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents BtnSetToDisplay As Button
    Friend WithEvents BtnSetAktualTebaru As Button
    Friend WithEvents TxtAdjustAktual As TextBox
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents BtnCloseShiftConfig As Button
    Friend WithEvents BtnSaveShiftConfig As Button
    Friend WithEvents gblembur As GroupBox
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents RBTidakAktifShift3 As RadioButton
    Friend WithEvents RBYaAktifShift3 As RadioButton
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents RBTidakAktifShift2 As RadioButton
    Friend WithEvents RBYaAktifShift2 As RadioButton
    Friend WithEvents GBShift1 As GroupBox
    Friend WithEvents RBTidakLembur As RadioButton
    Friend WithEvents RBYaLembur As RadioButton
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents BtnPilihSuaraBel As Button
    Friend WithEvents Label45 As Label
    Friend WithEvents BtnPilihSuaraTimbangan As Button
    Friend WithEvents Label44 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Lblnamafilesuaratimbangan As Label
    Friend WithEvents Lblnamafilesuarabel As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents BtnWarnaEfisiensi100 As Button
    Friend WithEvents PnlWarnaEfisiensi100 As Panel
    Friend WithEvents BtnWarnaEfisiensi80 As Button
    Friend WithEvents PnlWarnaEfisiensi80 As Panel
    Friend WithEvents BtnWarnaEfisiensi0 As Button
    Friend WithEvents PnlWarnaEfisiensi0 As Panel
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents BtnTesSuaraBel As Button
    Friend WithEvents BtnTesSuaraTimbangan As Button
    Friend WithEvents CmbNoMesin As ComboBox
    Friend WithEvents Label49 As Label
End Class
