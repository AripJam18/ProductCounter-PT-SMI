﻿Imports System.Data.Odbc
Imports System.Resources


Public Class FormMonitor
#Region "Get Data"
    Private Sub GeRealtimeData1()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin='M01' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M01!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin1.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal1.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari1.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel1.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget1.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual1.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi1.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus1.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData1")
        End Try
    End Sub
    Private Sub GeRealtimeData2()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin='M02' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M02!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin2.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal2.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari2.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel2.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget2.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual2.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi2.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus2.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData2")
        End Try
    End Sub
    Private Sub GeRealtimeData3()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin='M03' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M03!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin3.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal3.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari3.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel3.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget3.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual3.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi3.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus3.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData3")
        End Try
    End Sub
    Private Sub GeRealtimeData4()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin='M04' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M04!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin4.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal4.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari4.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel4.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget4.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual4.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi4.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus4.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData4")
        End Try
    End Sub
    Private Sub GeRealtimeData5()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin='M05' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M05!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin5.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal5.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari5.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel5.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget5.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual5.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi5.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus5.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData5")
        End Try
    End Sub
    Private Sub GeRealtimeData6()
        Try
            ConnectMySQLMonitoring()

            DAMonitoring = New OdbcDataAdapter("SELECT a.nomesin, a.tgl, a.hari, a.model, a.target, a.aktual, a.efisiensi, a.status , b.alias FROM monitoring a LEFT JOIN setline b ON a.nomesin = b.no_mesin WHERE a.nomesin=M06' ", CONNMonitoring)
            DSMonitoring = New DataSet
            DAMonitoring.Fill(DSMonitoring, "getrealtimedata")
            Dim dtMonitoring As DataTable = DSMonitoring.Tables("getrealtimedata")
            If dtMonitoring.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail realtime untuk mesin M06!",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                lblnomesin6.Text = dtMonitoring.Rows(0).Item("alias")
                lbltanggal6.Text = dtMonitoring.Rows(0).Item("tgl")
                lblhari6.Text = dtMonitoring.Rows(0).Item("hari")
                lblmodel6.Text = dtMonitoring.Rows(0).Item("model")
                lbltarget6.Text = dtMonitoring.Rows(0).Item("target")
                lblaktual6.Text = dtMonitoring.Rows(0).Item("aktual")
                lblefisiensi6.Text = dtMonitoring.Rows(0).Item("efisiensi")
                lblstatus6.Text = dtMonitoring.Rows(0).Item("status")
            End If
            CONNMonitoring.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GeRealtimeData6")
        End Try
    End Sub

#End Region

    Private Sub FormMonitor_Load(sender As Object, e As EventArgs) Handles Me.Load
        TimerMonitoring.Start()
    End Sub

    Private Sub ReLoad()
        CekStatusLine("M01")
        CekStatusLine("M02")
        CekStatusLine("M03")
        CekStatusLine("M04")
        CekStatusLine("M05")
        CekStatusLine("M06")
    End Sub
    Private Sub TimerMonitoring_Tick(sender As Object, e As EventArgs) Handles TimerMonitoring.Tick
        ReLoad()
        ''CEK dulu mesin mana saja yang aktif
        If statusM01 = "Ya" Then
            GeRealtimeData1()
            Led1.Visible = True
            lblstatus1.Text = "ON"
            TLP1.Enabled = True
        Else
            Led1.Visible = False
            lblstatus1.Text = "OFF"
            TLP1.Enabled = False
        End If

        If statusM02 = "Ya" Then
            GeRealtimeData2()
            Led2.Visible = True
            lblstatus2.Text = "ON"
            TLP2.Enabled = True
        Else
            Led2.Visible = False
            lblstatus2.Text = "OFF"
            TLP2.Enabled = False
        End If

        If statusM03 = "Ya" Then
            GeRealtimeData3()
            Led3.Visible = True
            lblstatus3.Text = "ON"
            TLP3.Enabled = True
        Else
            Led3.Visible = False
            lblstatus3.Text = "OFF"
            TLP3.Enabled = False
        End If

        If statusM04 = "Ya" Then
            GeRealtimeData4()
            Led4.Visible = True
            lblstatus4.Text = "ON"
            TLP4.Enabled = True
        Else
            Led4.Visible = False
            lblstatus4.Text = "OFF"
            TLP4.Enabled = False
        End If

        If statusM05 = "Ya" Then
            GeRealtimeData5()
            Led5.Visible = True
            lblstatus5.Text = "ON"
            TLP5.Enabled = True
        Else
            Led5.Visible = False
            lblstatus5.Text = "OFF"
            TLP5.Enabled = False
        End If

        If statusM06 = "Ya" Then
            GeRealtimeData6()
            Led6.Visible = True
            lblstatus6.Text = "ON"
            TLP6.Enabled = True
        Else
            Led6.Visible = False
            lblstatus6.Text = "OFF"
            TLP6.Enabled = False
        End If
    End Sub

    Private Sub BtnCloseTimbanganConfig_Click(sender As Object, e As EventArgs) Handles BtnCloseTimbanganConfig.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        FormMain.Show()
        'Me.Close()
    End Sub

    Private Sub FormMonitor_VisibleChanged(sender As Object, e As EventArgs) Handles Me.VisibleChanged
        If Me.Visible = True Then
            CekStatusLine("M01")
            CekStatusLine("M02")
            CekStatusLine("M03")
            CekStatusLine("M04")
            CekStatusLine("M05")
            CekStatusLine("M06")
            TimerMonitoring.Start()
        End If
    End Sub

    Private Sub FormMonitor_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
        Me.Hide()
    End Sub
End Class