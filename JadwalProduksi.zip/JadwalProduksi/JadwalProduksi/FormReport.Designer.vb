﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormReport))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BtnMain = New System.Windows.Forms.Button()
        Me.BtnPDF = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnExport = New System.Windows.Forms.Button()
        Me.DTPFrom = New System.Windows.Forms.DateTimePicker()
        Me.BtnTampil = New System.Windows.Forms.Button()
        Me.DTPTo = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelData = New System.Windows.Forms.Panel()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.PanelBawah = New System.Windows.Forms.Panel()
        Me.LblJumlahData = New System.Windows.Forms.Label()
        Me.PanelButton = New System.Windows.Forms.Panel()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.GroupBox1.SuspendLayout()
        Me.PanelData.SuspendLayout()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBawah.SuspendLayout()
        Me.PanelButton.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BtnMain)
        Me.GroupBox1.Controls.Add(Me.BtnPDF)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.BtnExport)
        Me.GroupBox1.Controls.Add(Me.DTPFrom)
        Me.GroupBox1.Controls.Add(Me.BtnTampil)
        Me.GroupBox1.Controls.Add(Me.DTPTo)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(534, 118)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tampil Data"
        '
        'BtnMain
        '
        Me.BtnMain.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnMain.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.BtnMain.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PowderBlue
        Me.BtnMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMain.ForeColor = System.Drawing.Color.White
        Me.BtnMain.Image = Global.JadwalProduksi.My.Resources.Resources.b_home
        Me.BtnMain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnMain.Location = New System.Drawing.Point(422, 59)
        Me.BtnMain.Name = "BtnMain"
        Me.BtnMain.Size = New System.Drawing.Size(93, 35)
        Me.BtnMain.TabIndex = 8
        Me.BtnMain.Text = "Main"
        Me.BtnMain.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnMain.UseVisualStyleBackColor = False
        '
        'BtnPDF
        '
        Me.BtnPDF.Enabled = False
        Me.BtnPDF.Image = Global.JadwalProduksi.My.Resources.Resources.b_pdf
        Me.BtnPDF.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPDF.Location = New System.Drawing.Point(422, 18)
        Me.BtnPDF.Name = "BtnPDF"
        Me.BtnPDF.Size = New System.Drawing.Size(93, 35)
        Me.BtnPDF.TabIndex = 7
        Me.BtnPDF.Text = "Export"
        Me.BtnPDF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPDF.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Dari"
        '
        'BtnExport
        '
        Me.BtnExport.Image = CType(resources.GetObject("BtnExport.Image"), System.Drawing.Image)
        Me.BtnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnExport.Location = New System.Drawing.Point(314, 59)
        Me.BtnExport.Name = "BtnExport"
        Me.BtnExport.Size = New System.Drawing.Size(93, 35)
        Me.BtnExport.TabIndex = 6
        Me.BtnExport.Text = "Export"
        Me.BtnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnExport.UseVisualStyleBackColor = True
        '
        'DTPFrom
        '
        Me.DTPFrom.Location = New System.Drawing.Point(97, 24)
        Me.DTPFrom.Name = "DTPFrom"
        Me.DTPFrom.Size = New System.Drawing.Size(189, 25)
        Me.DTPFrom.TabIndex = 4
        '
        'BtnTampil
        '
        Me.BtnTampil.Image = CType(resources.GetObject("BtnTampil.Image"), System.Drawing.Image)
        Me.BtnTampil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTampil.Location = New System.Drawing.Point(314, 18)
        Me.BtnTampil.Name = "BtnTampil"
        Me.BtnTampil.Size = New System.Drawing.Size(93, 35)
        Me.BtnTampil.TabIndex = 1
        Me.BtnTampil.Text = "Show"
        Me.BtnTampil.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnTampil.UseVisualStyleBackColor = True
        '
        'DTPTo
        '
        Me.DTPTo.Location = New System.Drawing.Point(97, 65)
        Me.DTPTo.Name = "DTPTo"
        Me.DTPTo.Size = New System.Drawing.Size(186, 25)
        Me.DTPTo.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "hingga"
        '
        'PanelData
        '
        Me.PanelData.Controls.Add(Me.DGV)
        Me.PanelData.Controls.Add(Me.PanelBawah)
        Me.PanelData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelData.Location = New System.Drawing.Point(0, 105)
        Me.PanelData.Name = "PanelData"
        Me.PanelData.Size = New System.Drawing.Size(1221, 659)
        Me.PanelData.TabIndex = 5
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGV.Location = New System.Drawing.Point(0, 0)
        Me.DGV.Name = "DGV"
        Me.DGV.Size = New System.Drawing.Size(1221, 621)
        Me.DGV.TabIndex = 0
        '
        'PanelBawah
        '
        Me.PanelBawah.BackColor = System.Drawing.Color.LightGray
        Me.PanelBawah.Controls.Add(Me.LblJumlahData)
        Me.PanelBawah.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBawah.Location = New System.Drawing.Point(0, 621)
        Me.PanelBawah.Name = "PanelBawah"
        Me.PanelBawah.Size = New System.Drawing.Size(1221, 38)
        Me.PanelBawah.TabIndex = 8
        '
        'LblJumlahData
        '
        Me.LblJumlahData.AutoSize = True
        Me.LblJumlahData.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblJumlahData.Location = New System.Drawing.Point(3, 12)
        Me.LblJumlahData.Name = "LblJumlahData"
        Me.LblJumlahData.Size = New System.Drawing.Size(94, 17)
        Me.LblJumlahData.TabIndex = 8
        Me.LblJumlahData.Text = "Jumlah Data : "
        '
        'PanelButton
        '
        Me.PanelButton.Controls.Add(Me.GroupBox1)
        Me.PanelButton.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelButton.Location = New System.Drawing.Point(0, 0)
        Me.PanelButton.Name = "PanelButton"
        Me.PanelButton.Size = New System.Drawing.Size(1221, 105)
        Me.PanelButton.TabIndex = 4
        '
        'FormReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1221, 764)
        Me.Controls.Add(Me.PanelData)
        Me.Controls.Add(Me.PanelButton)
        Me.Name = "FormReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Report"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.PanelData.ResumeLayout(False)
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBawah.ResumeLayout(False)
        Me.PanelBawah.PerformLayout()
        Me.PanelButton.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnExport As Button
    Friend WithEvents DTPFrom As DateTimePicker
    Friend WithEvents BtnTampil As Button
    Friend WithEvents DTPTo As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents PanelData As Panel
    Friend WithEvents DGV As DataGridView
    Friend WithEvents PanelButton As Panel
    Friend WithEvents BtnPDF As Button
    Friend WithEvents BtnMain As Button
    Friend WithEvents LblJumlahData As Label
    Friend WithEvents PanelBawah As Panel
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
End Class
