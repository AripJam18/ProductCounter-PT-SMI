﻿Imports System.Data.Odbc
Module koneksi
    Public CONN As OdbcConnection
    Public DA As OdbcDataAdapter
    Public DS As DataSet
    Public CMD As OdbcCommand
    Public DR As OdbcDataReader
    Public aktivasinya, displaynya As Boolean
    Public iduser As String
    Public namauser As String
    Public leveluser As String
    Public LineList As New ArrayList()
    Public counterMSGBOX = 0
    Public setLine As String
    Public aktual As Integer
    Public dayofweek As Integer = 1
    Public day, setComPort As String
    Public setBrate As Integer = 9600
    Public minweight As Double
    Public maxweight As Double
    Public setDelay As Integer
    Public detikdelay As Integer = 0
    Public setMultiple As Integer = 1
    Public setTarget As Integer
    Public setPlan As Integer = 1000
    Public stopTimerAfterAdd As Integer = 0
    Public lastweight As Double
    Public setRunningTextSpeed As Integer = 400
    Public setTampilkan As Integer = 1
    Public setAnimasi As Integer = 1
    Public setTargetPcs As Integer
    Public setEfisiensi As Double
    Public setStart As Integer = 0
    Public setStop As Integer = 1
    Public SudahTambahAktuallewatButton As Integer = 0
    Public setArduinoAktif As Integer
    Public setBelIstirahat, setBelTimbang, setBaudRateArduino, setComPortArduino As String
    '' Public PotonganWaktuIstirahatPagi, PotonganWaktuIstirahatSiang, PotonganWaktuIstirahatSore, PotonganWaktuIstirahatLembur, PotonganWaktuIstirahatJumat As Integer
    Public targetygselalubertambah, delaytambahaktualdaributton As Integer
    ''Public WaktuIstirahatPagi, WaktuIstirahatSiang, WaktuIstirahatSore, WaktuIstirahatLembur, WaktuIstirahatJumat As Integer
    Public warnaBackground, warnaDay, warnaDate, warnaTime, warnaModel, warnaAktual, warnaTarget, warnaJudul, warnaRunningText, warnaEfisiensi, warnaEfisiensi0, warnaEfisiensi80, warnaEfisiensi100, setisiRunningText, setModel, createdatetarget, updatedatetarget As String
    ''Public xIstirahat, xMulaiPagi, xMulaiSiang, xMulaiSore, xMulaiLembur, xMulaiJumat, xMulaiBriefPagi, xMulaiBriefSore, xMulaiCloseMet, xSelesaiPagi, xSelesaiSiang, xSelesaiSore, xSelesaiLembur, xSelesaiJumat, xSelesaiBriefPagi, xSelesaiBriefSore, xSelesaiCloseMet As String
    Public xRemainingMinutesPagi, xRemainingMinutesSiang, xRemainingMinutesSore, xRemainingMinutesLembur, xRemainingMinutesJumat As Integer
    Public xDurasiMenit, xDurasiMenitTarget, xDurasiPotongIstirahat, ActualTarget, targetperjam, xTotalWaktuIstirahat As Integer
    Public ReportNo, TglHariIni, JamSekarang, MenitSekarang, JamStart, MenitStart, DetikStart, JamStop, MenitStop, DetikStop, WaktuStart, WaktuStop, xStartTimeIdeal, MenitTambahAktual, StartTimeUntukDiAdjust, klikapa As String
    Public setFontDay, setFontDate, setFontTime, setFontModel, setFontTarget, setFontAktual, setFontJudul, setFontEfisiensi, setFontRunningText As String
    Public setSizeFontDay, setSizeFontDate, setSizeFontTime, setSizeFontModel, setSizeFontTarget, setSizeFontAktual, setSizeFontJudul, setSizeFontEfisiensi, setSizeFontRunningText As Single
    Public setStyleFontDay, setStyleFontDate, setStyleFontTime, setStyleFontModel, setStyleFontTarget, setStyleFontAktual, setStyleFontJudul, setStyleFontEfisiensi, setStyleFontRunningText As FontStyle
    Public Result1(), Result2(), Result3(), Result4(), Result5(), Result6(), Result7(), Result8(), Result9() As String
    Public WorkHours, RealtimeWorkHours, RollingIstirahat As String
    Public TglExpired As Date
    Public setToDisplay As Boolean = False
    Public baruLoad As Boolean = True
    Public TargetRealtime, xDurasiMenitTanpaPotonganIstirahat, shift As Integer
    Public JamGenap As Boolean = False
    Public ApakahIniTargetJamPertama As Boolean = True
    Public MulaiIstirahatOpening, SelesaiIstirahatOpening, MulaiIstirahatClosing, SelesaiIstirahatClosing, MulaiIstirahatClosingJumat, SelesaiIstirahatClosingJumat, MulaiIstirahat1, SelesaiIstirahat1, MulaiIstirahat2, SelesaiIstirahat2, MulaiIstirahat2Jumat, SelesaiIstirahat2Jumat, MulaiIstirahat3, SelesaiIstirahat3, MulaiIstirahatLembur1, SelesaiIstirahatLembur1, MulaiIstirahatLembur1Jumat, SelesaiIstirahatLembur1Jumat, MulaiIstirahatLembur2, SelesaiIstirahatLembur2, MulaiIstirahatLembur3, SelesaiIstirahatLembur3 As String
    Public PotonganWaktuIstirahat1, PotonganWaktuIstirahat2, PotonganWaktuIstirahat2Jumat, PotonganWaktuIstirahat3, PotonganWaktuIstirahatLembur1, PotonganWaktuIstirahatLembur1Jumat, PotonganWaktuIstirahatLembur2, PotonganWaktuIstirahatLembur3, PotonganWaktuOpening, PotonganWaktuClosing, PotonganWaktuIstirahatClosingJumat As Integer
    ''8 jam kerja x 60 menit
    Public TotalWaktuIstirahatPerhari = 90
    Public SetLemburShift1, SetAktifShift2, SetAktifShift3 As String
    Public xsuarabel, xsuaratimbangan As String
    Public xwaktutrial, xhitungmundur As Integer
    Public tambahjammanual As Boolean
    Public lagikirimdatakeserver As Boolean
    Public setNomorMesin As String
    Public statusM01, statusM02, statusM03, statusM04, statusM05, statusM06 As String
    Public ApakahMesinAktif As String
    Public rolling1, rolling2, rolling3 As String
    Public targetFound, aktualFound As Integer
    Public efisiensiFound As String
    Public lanjutHitungdarisebelumnya, sudahkonekarduino, berhasilinsertatauupdatedata As Boolean
    ''pagi 10 + siang 40 + sore 10 + Lembur 30

    Public Sub ConnectMySQL()
        ''CONN = New OdbcConnection("dsn=KoneksiProduk")
        CONN = New OdbcConnection("dsn=koneksiproduk32bit")
        CONN.Open()
    End Sub
    Public Sub GetSettinganAwal()

        Try
            ConnectMySQL()



            ''ambil tgl server
            CMD = New OdbcCommand("SELECT CURDATE() as date", CONN)
            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                TglExpired = Date.Today()
            Else
                TglExpired = DR.Item("date")
                TglExpired = Format(TglExpired, "yyyy-MM-dd")
            End If


            ''ambil settingan tampilan
            CMD = New OdbcCommand("SELECT * FROM settampilan ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan tampilan ",
                       MsgBoxStyle.Exclamation, "Error settampilan")
            Else
                warnaBackground = DR.Item("backgorund").ToString
                warnaDay = DR.Item("lblday").ToString
                warnaDate = DR.Item("lbldate").ToString
                warnaTime = DR.Item("lbltime").ToString
                warnaModel = DR.Item("lblmodel").ToString
                warnaTarget = DR.Item("lbltarget").ToString
                warnaAktual = DR.Item("lblaktual").ToString
                warnaJudul = DR.Item("lbljudul").ToString
                warnaEfisiensi = DR.Item("lblefiseinsi").ToString
                warnaEfisiensi0 = DR.Item("lblefiseinsi0").ToString
                warnaEfisiensi80 = DR.Item("lblefiseinsi80").ToString
                warnaEfisiensi100 = DR.Item("lblefiseinsi100").ToString
            End If

            ''ambil settingan model
            CMD = New OdbcCommand("SELECT * FROM setmodel WHERE aktif=1", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()


            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan model ",
                       MsgBoxStyle.Exclamation, "Error setmodel")
            Else
                setModel = DR.Item("model")
                setTarget = DR.Item("target")
                setPlan = DR.Item("plan")
                setMultiple = DR.Item("kelipatan")
                setDelay = DR.Item("delay")
                minweight = FormatNumber(DR.Item("minberat"), 2)
                maxweight = FormatNumber(DR.Item("maxberat"), 2)
                setTargetPcs = setTarget / 60
            End If

            ''ambil settingan timbangan
            CMD = New OdbcCommand("SELECT * FROM settimbangan ", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()


            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan timbangan ",
                       MsgBoxStyle.Exclamation, "Error settimbangan")
            Else
                setComPort = DR.Item("comport").ToString
                setBrate = DR.Item("baudrate")
            End If

            ''ambil settingan runningtext
            CMD = New OdbcCommand("SELECT * FROM setrunningtext", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan runningtext ",
                       MsgBoxStyle.Exclamation, "Error setrunningtext")
            Else
                setRunningTextSpeed = DR.Item("speed")
                setisiRunningText = DR.Item("kalimat").ToString
                warnaRunningText = DR.Item("warna").ToString
                setTampilkan = DR.Item("tampilkan")
                setAnimasi = DR.Item("animasi")
                setFontRunningText = DR.Item("font")

                Result9 = Split(setFontRunningText, ",")
                setFontRunningText = Result9(0)
                setSizeFontRunningText = Result9(1)
                setStyleFontRunningText = Result9(2)
            End If


            ''ambil settingan Line
            'CMD = New OdbcCommand("SELECT nama_line , no_mesin FROM setline WHERE aktif='Ya'", CONN)
            CMD = New OdbcCommand("SELECT nama_line , no_mesin FROM setline", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan line ",
                       MsgBoxStyle.Exclamation, "Error setline")
            Else
                setLine = DR.Item("nama_line")
                'setNomorMesin = DR.Item("no_mesin")
                'setNomorMesin mesin belum sesuai sama mesin apa yg sedang running saat ini
            End If

            ''mulai tgl 10 Agustus 2023 istirahat pakai kode 1-2-3 bukan pagi siang sore
            ''durasi1 , mulai1 dan selesai1 artinya settingan khusus shift 1. tambah juga opening dan closing 

            ''ambil settingan istirahat Opening
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Opening'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Opening")
            Else
                MulaiIstirahatOpening = DR.Item("mulai1")
                SelesaiIstirahatOpening = DR.Item("selesai1").ToString
                PotonganWaktuOpening = DR.Item("durasi1").ToString
            End If
            ''ambil settingan istirahat Closing
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Closing'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Closing")
            Else
                MulaiIstirahatClosing = DR.Item("mulai1")
                SelesaiIstirahatClosing = DR.Item("selesai1").ToString
                PotonganWaktuClosing = DR.Item("durasi1").ToString
            End If
            ''ambil settingan istirahat Closing Jumat
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Closing Jumat'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Closing Jumat")
            Else
                MulaiIstirahatClosingJumat = DR.Item("mulai1")
                SelesaiIstirahatClosingJumat = DR.Item("selesai1").ToString
                PotonganWaktuIstirahatClosingJumat = DR.Item("durasi1").ToString
            End If
            ''ambil settingan istirahat 1
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 1'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 1")
            Else
                MulaiIstirahat1 = DR.Item("mulai1")
                SelesaiIstirahat1 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahat1 = DR.Item("durasi1").ToString
                rolling1 = DR.Item("Rolling").ToString
            End If

            ''ambil settingan istirahat 2
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 2'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 2")
            Else
                MulaiIstirahat2 = DR.Item("mulai1")
                SelesaiIstirahat2 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahat2 = CInt(DR.Item("durasi1").ToString)
                rolling2 = DR.Item("Rolling").ToString
            End If

            ''ambil settingan istirahat 3
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 3'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 3")
            Else
                MulaiIstirahat3 = DR.Item("mulai1")
                SelesaiIstirahat3 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahat3 = CInt(DR.Item("durasi1").ToString)
                rolling3 = DR.Item("Rolling").ToString
            End If

            ''ambil settingan istirahat 2 Jumat
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 2 Jumat'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 2 Jumat")
            Else
                MulaiIstirahat2Jumat = DR.Item("mulai1")
                SelesaiIstirahat2Jumat = DR.Item("selesai1").ToString
                PotonganWaktuIstirahat2Jumat = DR.Item("durasi1").ToString
            End If

            ''ambil settingan istirahat lembur 1
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 1'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 1")
            Else
                MulaiIstirahatLembur1 = DR.Item("mulai1")
                SelesaiIstirahatLembur1 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahatLembur1 = DR.Item("durasi1").ToString
            End If


            ''ambil settingan istirahat lembur 1 jumat
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 1 Jumat'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 1 Jumat")
            Else
                MulaiIstirahatLembur1Jumat = DR.Item("mulai1")
                SelesaiIstirahatLembur1Jumat = DR.Item("selesai1").ToString
                PotonganWaktuIstirahatLembur1Jumat = DR.Item("durasi1").ToString
            End If

            ''ambil settingan istirahat lembur 2
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 2'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 2")
            Else
                MulaiIstirahatLembur2 = DR.Item("mulai1")
                SelesaiIstirahatLembur2 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahatLembur2 = DR.Item("durasi1").ToString
            End If
            ''ambil settingan istirahat lembur 3
            CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 3'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 3")
            Else
                MulaiIstirahatLembur3 = DR.Item("mulai1")
                SelesaiIstirahatLembur3 = DR.Item("selesai1").ToString
                PotonganWaktuIstirahatLembur3 = DR.Item("durasi1").ToString
            End If

            ''ambil settingan bel
            CMD = New OdbcCommand("SELECT * FROM setbel WHERE id=1", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setbel ",
                       MsgBoxStyle.Exclamation, "Error setbel")
            Else
                setBelIstirahat = DR.Item("istirahat")
                setBelTimbang = DR.Item("timbang").ToString
            End If


            CONN.Close()
            ''ambil data lainnya secara terpisah
            AmbilSettinganArduino()
            Ambiltargetterbaru(My.Settings.nomesin)
            AmbilSettinganHuruf()
            Cekkondisimesinterbaru()
            AmbilLembur()
            AmbilShift2()
            AmbilShift3()

            ''load suara bel dan timbangan
            xsuarabel = My.Settings.suarabell
            xsuaratimbangan = My.Settings.suaratimbangan
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error LoadSettinganAwal()")
        End Try

    End Sub
    Public Sub AmbilLembur()
        ConnectMySQL()
        Try
            CMD = New OdbcCommand("SELECT  `lembur` FROM `setshift` WHERE `namashift`='Shift 1'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan lembur shift1 ",
                       MsgBoxStyle.Exclamation, "Error setbel")
            Else
                SetLemburShift1 = DR.Item("lembur")
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub
    Public Sub AmbilShift2()
        ConnectMySQL()
        Try
            CMD = New OdbcCommand("SELECT  `status` FROM `setshift` WHERE `namashift`='Shift 2'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan shift2 ",
                       MsgBoxStyle.Exclamation, "Error setbel")
            Else
                SetAktifShift2 = DR.Item("status")
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub
    Public Sub AmbilShift3()
        ConnectMySQL()
        Try
            CMD = New OdbcCommand("SELECT  `status` FROM `setshift` WHERE `namashift`='Shift 3'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan shift3 ",
                       MsgBoxStyle.Exclamation, "Error setbel")
            Else
                SetAktifShift3 = DR.Item("status")
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub
    Public Sub AmbilSettinganArduino()
        ConnectMySQL()
        Try
            CMD = New OdbcCommand("SELECT * FROM arduino WHERE id=1", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setbel ",
                       MsgBoxStyle.Exclamation, "Error setbel")
            Else
                setArduinoAktif = DR.Item("aktif")
                setBaudRateArduino = DR.Item("baudrate").ToString
                setComPortArduino = DR.Item("port").ToString
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub
    Public Sub Ambiltargetterbaru(ByVal nomesin As String)
        If IsNothing(nomesin) Then
            nomesin = My.Settings.nomesin
        End If
        ConnectMySQL()
        Try
            CMD = New OdbcCommand("SELECT * FROM target WHERE nomesin='" & nomesin & "'", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan target ",
                       MsgBoxStyle.Exclamation, "Error target")
            Else
                targetygselalubertambah = DR.Item("target")
                createdatetarget = DR.Item("createdat").ToString
                updatedatetarget = DR.Item("updatedat").ToString
                aktual = DR.Item("aktual")
                StartTimeUntukDiAdjust = DR.Item("starttime")
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub
    Public Sub UpdateTargetTerbaru(ByVal newtarget As Integer, ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE target SET target='" & newtarget & "'  WHERE  nomesin='" & nomesin & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'MsgBox("Target berhasil diperbaharui", vbInformation, "Informasi")
            Cekkondisimesinterbaru()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateTargetTerbaru()")
        End Try
    End Sub

    Public Sub UpdateAktualTerbaru(ByVal newaktual As Integer, ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE target SET aktual='" & newaktual & "'  WHERE nomesin='" & nomesin & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'If FormSetting.Visible = True Then
            '    MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            'End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateAktualTerbaru()")
        End Try
    End Sub
    Public Sub UpdateStartTimeTerbaru(ByVal adjustedtime As String, ByVal nomesin As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE target SET starttime='" & adjustedtime & "'  WHERE nomesin='" & nomesin & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'If FormSetting.Visible = True Then
            '    MsgBox("Data berhasil diperbaharui", vbInformation, "Informasi")
            'End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateStartTimeTerbaru()")
        End Try
    End Sub

    Public Sub Cekkondisimesinterbaru()
        ConnectMySQL()
        ''1 data untuk dipakai 6 mesin ???
        Try
            CMD = New OdbcCommand("SELECT * FROM mesin WHERE id=1", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan mesin ",
                       MsgBoxStyle.Exclamation, "Error mesin")
            Else
                setStart = DR.Item("start")
                setStop = DR.Item("stop")
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error Ambiltargetterbaru()")
        End Try
    End Sub

    Public Sub UpdateKondisiMesin(ByVal aktifatautidak As String, ByVal nomormesinnya As String)
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE setline SET aktif='" & aktifatautidak & "' WHERE no_mesin='" & nomormesinnya & "'"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            'MsgBox("Data berhasil diperbaharui , mesin " & kondisinya, vbInformation, "Informasi")
            Cekkondisimesinterbaru()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateKondisiMesin()")
        End Try
    End Sub
    Public Sub CekStatusLine(ByVal nomesin As String)
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT aktif FROM setline WHERE no_mesin = '" & nomesin & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "statusline")
            Dim dt As DataTable = DS.Tables("statusline")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data statusline untuk mesin " & nomesin,
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                Select Case nomesin
                    Case "M01"
                        statusM01 = dt.Rows(0).Item("aktif").ToString
                    Case "M02"
                        statusM02 = dt.Rows(0).Item("aktif").ToString
                    Case "M03"
                        statusM03 = dt.Rows(0).Item("aktif").ToString
                    Case "M04"
                        statusM04 = dt.Rows(0).Item("aktif").ToString
                    Case "M05"
                        statusM05 = dt.Rows(0).Item("aktif").ToString
                    Case "M06"
                        statusM06 = dt.Rows(0).Item("aktif").ToString
                End Select
            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error CekStatusLine")
        End Try
    End Sub
    Public Sub AmbilSettinganHuruf()
        Try
            ConnectMySQL()
            CMD = New OdbcCommand("SELECT * FROM setfont WHERE id=1", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan setfont ",
                       MsgBoxStyle.Exclamation, "Error setfont")
            Else
                setFontDay = DR.Item("dayfont")
                setFontDate = DR.Item("datefont")
                setFontTime = DR.Item("timefont")
                setFontModel = DR.Item("modelfont")
                setFontTarget = DR.Item("targetfont")
                setFontAktual = DR.Item("aktualfont")
                setFontJudul = DR.Item("judulfont")
                setFontEfisiensi = DR.Item("efisiensifont")

                Result1 = Split(setFontDay, ",")
                setFontDay = Result1(0)
                setSizeFontDay = Result1(1)
                setStyleFontDay = Result1(2)


                Result2 = Split(setFontDate, ",")
                setFontDate = Result2(0)
                setSizeFontDate = Result2(1)
                setStyleFontDate = Result2(2)

                Result3 = Split(setFontTime, ",")
                setFontTime = Result3(0)
                setSizeFontTime = Result3(1)
                setStyleFontTime = Result3(2)


                Result4 = Split(setFontModel, ",")
                setFontModel = Result4(0)
                setSizeFontModel = Result4(1)
                setStyleFontModel = Result4(2)


                Result5 = Split(setFontTarget, ",")
                setFontTarget = Result5(0)
                setSizeFontTarget = Result5(1)
                setStyleFontTarget = Result5(2)

                Result6 = Split(setFontAktual, ",")
                setFontAktual = Result6(0)
                setSizeFontAktual = Result6(1)
                setStyleFontAktual = Result6(2)


                Result7 = Split(setFontJudul, ",")
                setFontJudul = Result7(0)
                setSizeFontJudul = Result7(1)
                setStyleFontJudul = Result7(2)


                Result8 = Split(setFontEfisiensi, ",")
                setFontEfisiensi = Result8(0)
                setSizeFontEfisiensi = Result8(1)
                setStyleFontEfisiensi = Result8(2)

            End If
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error AmbilSettinganHuruf()")
        End Try
    End Sub
    Public Sub GetSettinganIstirhatOnly()
        If CONN.State = False Then
            CONN.Open()
        End If

        ''mulai tgl 10 Agustus 2023 istirahat pakai kode 1-2-3 bukan pagi siang sore
        ''durasi1 , mulai1 dan selesai1 artinya settingan khusus shift 1. tambah juga opening dan closing 

        ''ambil settingan istirahat Opening
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Opening'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Opening")
        Else
            MulaiIstirahatOpening = DR.Item("mulai1")
            SelesaiIstirahatOpening = DR.Item("selesai1").ToString
            PotonganWaktuOpening = DR.Item("durasi1").ToString
        End If
        ''ambil settingan istirahat Closing
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Closing'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Closing")
        Else
            MulaiIstirahatClosing = DR.Item("mulai1")
            SelesaiIstirahatClosing = DR.Item("selesai1").ToString
            PotonganWaktuClosing = DR.Item("durasi1").ToString
        End If
        ''ambil settingan istirahat Closing Jumat
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Closing Jumat'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Closing Jumat")
        Else
            MulaiIstirahatClosingJumat = DR.Item("mulai1")
            SelesaiIstirahatClosingJumat = DR.Item("selesai1").ToString
            PotonganWaktuIstirahatClosingJumat = DR.Item("durasi1").ToString
        End If
        ''ambil settingan istirahat 1
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 1'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 1")
        Else
            MulaiIstirahat1 = DR.Item("mulai1")
            SelesaiIstirahat1 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahat1 = DR.Item("durasi1").ToString
        End If

        ''ambil settingan istirahat 2
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 2'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 2")
        Else
            MulaiIstirahat2 = DR.Item("mulai1")
            SelesaiIstirahat2 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahat2 = CInt(DR.Item("durasi1").ToString)
        End If

        ''ambil settingan istirahat 3
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 3'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 3")
        Else
            MulaiIstirahat3 = DR.Item("mulai1")
            SelesaiIstirahat3 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahat3 = CInt(DR.Item("durasi1").ToString)
        End If

        ''ambil settingan istirahat 2 Jumat
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Istirahat 2 Jumat'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat 2 Jumat")
        Else
            MulaiIstirahat2Jumat = DR.Item("mulai1")
            SelesaiIstirahat2Jumat = DR.Item("selesai1").ToString
            PotonganWaktuIstirahat2Jumat = DR.Item("durasi1").ToString
        End If

        ''ambil settingan istirahat lembur 1
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 1'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 1")
        Else
            MulaiIstirahatLembur1 = DR.Item("mulai1")
            SelesaiIstirahatLembur1 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahatLembur1 = DR.Item("durasi1").ToString
        End If


        ''ambil settingan istirahat lembur 1 jumat
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 1 Jumat'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 1 Jumat")
        Else
            MulaiIstirahatLembur1Jumat = DR.Item("mulai1")
            SelesaiIstirahatLembur1Jumat = DR.Item("selesai1").ToString
            PotonganWaktuIstirahatLembur1Jumat = DR.Item("durasi1").ToString
        End If

        ''ambil settingan istirahat lembur 2
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 2'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 2")
        Else
            MulaiIstirahatLembur2 = DR.Item("mulai1")
            SelesaiIstirahatLembur2 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahatLembur2 = DR.Item("durasi1").ToString
        End If
        ''ambil settingan istirahat lembur 3
        CMD = New OdbcCommand("SELECT * FROM setistirahat WHERE istirahat='Lembur 3'", CONN)

        DR = CMD.ExecuteReader()
        DR.Read()

        If DR.HasRows = 0 Then
            MsgBox("Tidak ada data settingan setistirahat ",
                       MsgBoxStyle.Exclamation, "Error setistirahat Lembur 3")
        Else
            MulaiIstirahatLembur3 = DR.Item("mulai1")
            SelesaiIstirahatLembur3 = DR.Item("selesai1").ToString
            PotonganWaktuIstirahatLembur3 = DR.Item("durasi1").ToString
        End If
        CONN.Close()
    End Sub
    Public Sub GetSettinganRunningTextRealtime()
        Try
            If CONN.State = False Then
                CONN.Open()
            End If
            ''ambil settingan runningtext
            CMD = New OdbcCommand("SELECT * FROM setrunningtext", CONN)

            DR = CMD.ExecuteReader()
            DR.Read()

            If DR.HasRows = 0 Then
                MsgBox("Tidak ada data settingan runningtext ",
                       MsgBoxStyle.Exclamation, "Error setrunningtext")
            Else
                setRunningTextSpeed = DR.Item("speed")
                setisiRunningText = DR.Item("kalimat").ToString
                warnaRunningText = DR.Item("warna").ToString
                setTampilkan = DR.Item("tampilkan")
                setAnimasi = DR.Item("animasi")
                setFontRunningText = DR.Item("font")

                Result9 = Split(setFontRunningText, ",")
                setFontRunningText = Result9(0)
                setSizeFontRunningText = Result9(1)
                setStyleFontRunningText = Result9(2)
            End If
            CONN.Open()
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
End Module