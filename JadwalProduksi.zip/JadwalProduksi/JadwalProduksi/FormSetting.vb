﻿Imports System.Data.Odbc
Imports System.Resources
Public Class FormSetting
    Dim hex_color, Type_Theme, Update_Type, Add_Type, Tampung_Type, Theme_Ready As String
    Dim suarabellistirahat As String
    Dim suaratimbangan As String
    Dim appDataPath As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
    Dim mainPath As String = My.Application.Info.DirectoryPath
    Dim startupPath As String = Application.StartupPath()
    Private Sub FormSetting_Load(sender As Object, e As EventArgs) Handles Me.Load
        Reload()
    End Sub
    Private Sub FormSetting_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        FormMain.Show()
    End Sub

    Private Sub Reload()
        Try
            GetSerialPortNames()
            GetModels()
            GetSettinganAwal()
            LoadSettinganAwal()
            GetLines()
            If baruLoad = False Then
                CmbLine.Text = My.Settings.line
                CmbNoMesin.DataSource = Nothing
                CmbNoMesin.Items.Clear()
                CmbNoMesin.Text = My.Settings.nomesin
            End If
            Lblnamafilesuarabel.Text = My.Settings.suarabell
            Lblnamafilesuaratimbangan.Text = My.Settings.suaratimbangan
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error Reload()")
        End Try
    End Sub

#Region "TextChanged"
    Private Sub TxtMinWeight_TextChanged(sender As Object, e As EventArgs) Handles TxtMinWeight.TextChanged
        If IsNumeric(TxtMinWeight.Text) Or TxtMinWeight.Text = "." Then
            'do nothing 
        Else
            'clear textbox 
            TxtMinWeight.Text = ""
        End If
    End Sub
    Private Sub TxtMaxWeight_TextChanged(sender As Object, e As EventArgs) Handles TxtMaxWeight.TextChanged
        If IsNumeric(TxtMaxWeight.Text) Or TxtMaxWeight.Text = "." Then
            'do nothing 
        Else
            'clear textbox 
            TxtMaxWeight.Text = ""
        End If
    End Sub
    Private Sub TxtTarget_TextChanged(sender As Object, e As EventArgs) Handles TxtTarget.TextChanged
        If IsNumeric(TxtTarget.Text) Then
            'do nothing 
        Else
            'clear textbox 
            TxtTarget.Text = ""
        End If
    End Sub

    Private Sub TxtKelipatan_TextChanged(sender As Object, e As EventArgs) Handles TxtKelipatan.TextChanged
        If IsNumeric(TxtKelipatan.Text) Then
            'do nothing 
        Else
            'clear textbox 
            TxtKelipatan.Text = ""
        End If
    End Sub

    Private Sub TxtDetik_TextChanged(sender As Object, e As EventArgs) Handles TxtDetik.TextChanged
        If IsNumeric(TxtDetik.Text) Then
            'do nothing 
        Else
            'clear textbox 
            TxtDetik.Text = ""
        End If
    End Sub
#End Region



#Region "ButtonAction"
    Private Sub BtnWarnaTablayout_Click(sender As Object, e As EventArgs) Handles BtnWarnaTablayout.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaBackground = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaTablayout.Text = warnaBackground = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)

            BtnWarnaTablayout.BackColor = ColorTranslator.FromHtml(warnaBackground)
            PnlWarnaTabLayout.BackColor = ColorTranslator.FromHtml(warnaBackground)
        End If
    End Sub

    Private Sub BtnWarnaDay_Click(sender As Object, e As EventArgs) Handles BtnWarnaDay.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaDay = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaDay.Text = warnaDay
            BtnWarnaDay.BackColor = ColorTranslator.FromHtml(warnaDay)
            PnlWarnaDay.BackColor = ColorTranslator.FromHtml(warnaDay)
        End If
    End Sub

    Private Sub BtnWarnaDate_Click(sender As Object, e As EventArgs) Handles BtnWarnaDate.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaDate = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaDate.Text = warnaDate
            BtnWarnaDate.BackColor = ColorTranslator.FromHtml(warnaDate)
            PnlWarnaDate.BackColor = ColorTranslator.FromHtml(warnaDate)
        End If
    End Sub

    Private Sub BtnWarnaTime_Click(sender As Object, e As EventArgs) Handles BtnWarnaTime.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaTime = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaTime.Text = warnaTime
            BtnWarnaTime.BackColor = ColorTranslator.FromHtml(warnaTime)
            PnlWarnaTime.BackColor = ColorTranslator.FromHtml(warnaTime)
        End If
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnCloseTimbanganConfig.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub BtnConfig_Click(sender As Object, e As EventArgs) Handles BtnSaveTimbanganConfig.Click
        UpdateSettinganTimbangan()
        My.Settings.line = CmbLine.Text
        My.Settings.nomesin = CmbNoMesin.Text
        My.Settings.Save()
    End Sub

    Private Sub BtnSaveTampilan_Click(sender As Object, e As EventArgs) Handles BtnSaveTampilan.Click
        ''update data ke server
        UpdateSettinganTampilan()
    End Sub

    Private Sub BtnWarnaModel_Click(sender As Object, e As EventArgs) Handles BtnWarnaModel.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaModel = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaModel.Text = warnaModel
            BtnWarnaModel.BackColor = ColorTranslator.FromHtml(warnaModel)
            PnlWarnaModel.BackColor = ColorTranslator.FromHtml(warnaModel)
        End If
    End Sub

    Private Sub BtnWarnaTarget_Click(sender As Object, e As EventArgs) Handles BtnWarnaTarget.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaTarget = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaTarget.Text = warnaTarget
            BtnWarnaTarget.BackColor = ColorTranslator.FromHtml(warnaTarget)
            PnlWarnaTarget.BackColor = ColorTranslator.FromHtml(warnaTarget)
        End If
    End Sub

    Private Sub BtnWarnaAktual_Click(sender As Object, e As EventArgs) Handles BtnWarnaAktual.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaAktual = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaAktual.Text = warnaAktual
            BtnWarnaAktual.BackColor = ColorTranslator.FromHtml(warnaAktual)
            PnlWarnaAktual.BackColor = ColorTranslator.FromHtml(warnaAktual)
        End If
    End Sub

    Private Sub BtnWarnaLabel_Click(sender As Object, e As EventArgs) Handles BtnWarnaJudul.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaJudul = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaJudul.Text = warnaJudul
            BtnWarnaJudul.BackColor = ColorTranslator.FromHtml(warnaJudul)
            PnlWarnaJudul.BackColor = ColorTranslator.FromHtml(warnaJudul)
        End If
    End Sub

    Private Sub BtnWarnaEfisiensi_Click(sender As Object, e As EventArgs) Handles BtnWarnaEfisiensi.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaEfisiensi = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaEfisiensi.Text = warnaEfisiensi
            BtnWarnaEfisiensi.BackColor = ColorTranslator.FromHtml(warnaEfisiensi)
            PnlWarnaEfisiensi.BackColor = ColorTranslator.FromHtml(warnaEfisiensi)
        End If
    End Sub
    Private Sub BtnWarnaEfisiensi0_Click(sender As Object, e As EventArgs) Handles BtnWarnaEfisiensi0.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaEfisiensi0 = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaEfisiensi0.Text = warnaEfisiensi0
            BtnWarnaEfisiensi0.BackColor = ColorTranslator.FromHtml(warnaEfisiensi0)
            PnlWarnaEfisiensi0.BackColor = ColorTranslator.FromHtml(warnaEfisiensi0)
        End If
    End Sub
    Private Sub BtnWarnaEfisiensi80_Click(sender As Object, e As EventArgs) Handles BtnWarnaEfisiensi80.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaEfisiensi80 = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaEfisiensi80.Text = warnaEfisiensi80
            BtnWarnaEfisiensi80.BackColor = ColorTranslator.FromHtml(warnaEfisiensi80)
            PnlWarnaEfisiensi80.BackColor = ColorTranslator.FromHtml(warnaEfisiensi80)
        End If
    End Sub
    Private Sub BtnWarnaEfisiensi100_Click(sender As Object, e As EventArgs) Handles BtnWarnaEfisiensi100.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaEfisiensi100 = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaEfisiensi100.Text = warnaEfisiensi
            BtnWarnaEfisiensi100.BackColor = ColorTranslator.FromHtml(warnaEfisiensi100)
            PnlWarnaEfisiensi100.BackColor = ColorTranslator.FromHtml(warnaEfisiensi100)
        End If
    End Sub
    Private Sub BtnClearAktual_Click(sender As Object, e As EventArgs)
        Dim result As DialogResult = MessageBox.Show("Confirm reset?",
                              "Product Counter",
                              MessageBoxButtons.YesNo)

        If (result = DialogResult.Yes) Then
            'LblAktual.Text = "0"
            'aktual = 0
        Else
            'Nothing
        End If

    End Sub
    Private Sub BtnFontRunningText_Click(sender As Object, e As EventArgs) Handles BtnFontRunningText.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            TxtFontRunningText.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnCloseTampilan_Click(sender As Object, e As EventArgs) Handles BtnCloseTampilan.Click, BtnCloseTimbanganConfig.Click, BtnCloseRunningTextSetting.Click
        FormMain.Show()
        Me.Hide()
    End Sub
#End Region
    Private Sub UpdateSettinganRunningText()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setrunningtext Set warna='" & warnaRunningText & "',speed=" & TxtSpeed.Text & ",kalimat='" & TxtIsiRunningText.Text & "',tampilkan=" & setTampilkan & ",animasi=" & setAnimasi & " , font='" & TxtFontRunningText.Text & "' WHERE id=1"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()


            Dim simpan2 As String = "UPDATE setbel Set istirahat='" & setBelIstirahat & "',timbang='" & setBelTimbang & "' WHERE id=1"
            CMD = New OdbcCommand(simpan2, CONN)
            CMD.ExecuteNonQuery()

            MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateSettinganRunningText()")
        End Try

    End Sub
    Private Sub UpdateSettinganTampilan()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE settampilan Set backgorund='" & warnaBackground & "',lblday='" & warnaDay & "',lbldate='" & warnaDate & "',lbltime='" & warnaTime & "',lblmodel='" & warnaModel & "', lbltarget='" & warnaTarget & "',lblaktual='" & warnaAktual & "',lbljudul='" & warnaJudul & "',lblefiseinsi='" & warnaEfisiensi & "' , lblefiseinsi0='" & warnaEfisiensi0 & "' , lblefiseinsi80='" & warnaEfisiensi80 & "' ,lblefiseinsi100='" & warnaEfisiensi100 & "'  WHERE id=1"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateSettinganTampilan()")
        End Try
    End Sub
    Private Sub UpdateSettinganTimbangan()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE settimbangan SET comport='" & setComPort & "',baudrate='" & setBrate & "' WHERE id=1"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()

            Dim update1 As String = "UPDATE setmodel SET target=" & TxtTarget.Text & ",plan=" & TxtPlanning.Text & ",kelipatan=" & TxtKelipatan.Text & ",delay=" & TxtDetik.Text & ",minberat='" & TxtMinWeight.Text & "',maxberat='" & TxtMaxWeight.Text & "' ,aktif=1 WHERE model='" & CmbModel.Text & "'"
            CMD = New OdbcCommand(update1, CONN)
            CMD.ExecuteNonQuery()


            Dim update2 As String = "UPDATE setmodel SET aktif=0 WHERE model<>'" & CmbModel.Text & "'"
            CMD = New OdbcCommand(update2, CONN)
            CMD.ExecuteNonQuery()

            Dim update3 As String = "UPDATE setline SET aktif='Ya' WHERE no_mesin='" & CmbNoMesin.Text & "'"
            CMD = New OdbcCommand(update3, CONN)
            CMD.ExecuteNonQuery()

            MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateSettinganTimbangan()")
        End Try
    End Sub
    Private Sub UpdateSettinganArduino()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE arduino SET port='" & setComPortArduino & "',baudrate='" & setBaudRateArduino & "' , aktif ='" & setArduinoAktif & "' WHERE id=1"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()

            MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateSettinganTimbangan()")
        End Try
    End Sub
    Private Sub BtnWarnaRunningText_Click(sender As Object, e As EventArgs) Handles BtnWarnaRunningText.Click
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            warnaRunningText = String.Format("#{0:X2}{1:X2}{2:X2}", ColorDialog1.Color.R, ColorDialog1.Color.G, ColorDialog1.Color.B)
            BtnWarnaRunningText.Text = warnaRunningText
            BtnWarnaRunningText.BackColor = ColorTranslator.FromHtml(warnaRunningText)
            PnlWarnaRunningText.BackColor = ColorTranslator.FromHtml(warnaRunningText)
        End If
    End Sub

    Private Sub BtnSaveRunningTextConfig_Click(sender As Object, e As EventArgs) Handles BtnSaveRunningTextConfig.Click
        UpdateSettinganRunningText()
        My.Settings.suarabell = Lblnamafilesuarabel.Text
        My.Settings.Save()
        My.Settings.suaratimbangan = Lblnamafilesuaratimbangan.Text
        My.Settings.Save()
    End Sub

    Private Sub RBYaTampilkan_CheckedChanged(sender As Object, e As EventArgs) Handles RBYaTampilkan.CheckedChanged
        If RBYaTampilkan.Checked = True Then
            setTampilkan = 1
        Else
            setTampilkan = 0
        End If
    End Sub
    Private Sub RBTidakTampilkan_CheckedChanged(sender As Object, e As EventArgs) Handles RBTidakTampilkan.CheckedChanged
        If RBTidakTampilkan.Checked = True Then
            setTampilkan = 0
        Else
            setTampilkan = 1
        End If
    End Sub

    Private Sub RBYaAnimasi_CheckedChanged(sender As Object, e As EventArgs) Handles RBYaAnimasi.CheckedChanged
        If RBYaAnimasi.Checked = True Then
            setAnimasi = 1
        Else
            setAnimasi = 0
        End If
    End Sub
    Private Sub RBTidakAnimasi_CheckedChanged(sender As Object, e As EventArgs) Handles RBTidakAnimasi.CheckedChanged
        If RBTidakAnimasi.Checked = True Then
            setAnimasi = 0
        Else
            setAnimasi = 1
        End If
    End Sub


#Region "Function"


    Private Sub LoadSettinganAwal()
        Try

            PnlWarnaAktual.BackColor = ColorTranslator.FromHtml(warnaAktual)
            PnlWarnaTarget.BackColor = ColorTranslator.FromHtml(warnaTarget)
            PnlWarnaModel.BackColor = ColorTranslator.FromHtml(warnaModel)
            PnlWarnaTime.BackColor = ColorTranslator.FromHtml(warnaTime)
            PnlWarnaDate.BackColor = ColorTranslator.FromHtml(warnaDate)
            PnlWarnaDay.BackColor = ColorTranslator.FromHtml(warnaDay)
            PnlWarnaJudul.BackColor = ColorTranslator.FromHtml(warnaJudul)
            PnlWarnaTabLayout.BackColor = ColorTranslator.FromHtml(warnaBackground)
            PnlWarnaEfisiensi.BackColor = ColorTranslator.FromHtml(warnaEfisiensi)
            PnlWarnaEfisiensi0.BackColor = ColorTranslator.FromHtml(warnaEfisiensi0)
            PnlWarnaEfisiensi80.BackColor = ColorTranslator.FromHtml(warnaEfisiensi80)
            PnlWarnaEfisiensi100.BackColor = ColorTranslator.FromHtml(warnaEfisiensi100)

            CmbModel.Text = setModel
            TxtMinWeight.Text = minweight
            TxtMaxWeight.Text = maxweight
            TxtDetik.Text = setDelay
            TxtTarget.Text = setTarget
            TxtKelipatan.Text = setMultiple
            TxtPlanning.Text = setPlan

            CmbPort.Text = setComPort
            CmbBaudRate.Text = setBrate
            TxtDetik.Text = setDelay

            setTampilkan = setTampilkan
            setAnimasi = setAnimasi


            setBelIstirahat = setBelIstirahat
            setBelTimbang = setBelTimbang

            TxtSpeed.Text = setRunningTextSpeed
            TxtIsiRunningText.Text = setisiRunningText
            PnlWarnaRunningText.BackColor = ColorTranslator.FromHtml(warnaRunningText)

            CmbLine.Text = setLine
            CmbNoMesin.Text = setNomorMesin

            If setTampilkan = 1 Then
                RBYaTampilkan.Checked = 1
            Else
                RBTidakTampilkan.Checked = 1
            End If

            If setAnimasi = 1 Then
                RBYaAnimasi.Checked = 1
            Else
                RBTidakAnimasi.Checked = 1
            End If



            If setBelIstirahat = "On" Then
                RBonBel.Checked = 1
            Else
                RBoffBel.Checked = 1
            End If

            If setBelTimbang = "On" Then
                RBonSuaraTimbang.Checked = 1
            Else
                RBoffSuaraTimbang.Checked = 1
            End If


            CmbBaudRateArduino.Text = setBaudRateArduino
            CmbPortArduino.Text = setComPortArduino

            If setArduinoAktif = 1 Then
                RBActive.Checked = True
            Else
                RBNonActive.Checked = True
            End If

            If lanjutHitungdarisebelumnya = True And targetygselalubertambah = 0 Then
                targetygselalubertambah = targetFound
            Else
                targetygselalubertambah = targetygselalubertambah
            End If

            'If targetFound = CInt(FormDisplay.LblTarget.Text) Then
            '    targetygselalubertambah = targetFound
            'Else
            '    targetygselalubertambah = FormDisplay.LblTarget.Text
            'End If

            TxtAdjustAktual.Text = aktual
            TxtAdjustTarget.Text = targetygselalubertambah
            TxtAdjustStartTime.Text = StartTimeUntukDiAdjust

            ''settingan huruf
            CmbFontDay.Text = setFontDay & "," & setSizeFontDay & "," & setStyleFontDay
            CmbFontDate.Text = setFontDate & "," & setSizeFontDate & "," & setStyleFontDate
            CmbFontTime.Text = setFontTime & "," & setSizeFontTime & "," & setStyleFontTime
            CmbFontModel.Text = setFontModel & "," & setSizeFontModel & "," & setStyleFontModel
            CmbFontTarget.Text = setFontTarget & "," & setSizeFontTarget & "," & setStyleFontTarget
            CmbFontTarget.Text = setFontTarget & "," & setSizeFontTarget & "," & setStyleFontTarget
            CmbFontAktual.Text = setFontAktual & "," & setSizeFontAktual & "," & setStyleFontAktual
            CmbFontJudul.Text = setFontJudul & "," & setSizeFontJudul & "," & setStyleFontJudul
            CmbFontEfisiensi.Text = setFontEfisiensi & "," & setSizeFontEfisiensi & "," & setStyleFontEfisiensi
            TxtFontRunningText.Text = setFontRunningText & "," & setSizeFontRunningText & "," & setStyleFontRunningText


            ''settingan shift
            If SetLemburShift1 = "Ya" Then
                RBYaLembur.Checked = True
            Else
                RBTidakLembur.Checked = True
            End If

            If SetAktifShift2 = "On" Then
                RBYaAktifShift2.Checked = True
            Else
                RBTidakAktifShift2.Checked = True
            End If

            If SetAktifShift3 = "On" Then
                RBYaAktifShift3.Checked = True
            Else
                RBTidakAktifShift3.Checked = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error LoadSettinganAwal()")
        End Try

    End Sub
    Private Sub GetMachines()
        Try
            CmbNoMesin.DataSource = Nothing
            CmbNoMesin.Items.Clear()
            ConnectMySQL()
            If CmbLine.Text = "" Then
                Exit Sub
            End If

            If CmbLine.Text = "System.Data.DataRowView" Then
                Exit Sub
            End If
            DA = New OdbcDataAdapter("SELECT DISTINCT no_mesin FROM setline WHERE nama_line='" & CmbLine.Text & "'", CONN)
            DS = New DataSet
            DA.Fill(DS, "getnomesin")
            Dim dt As DataTable = DS.Tables("getnomesin")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data no mesin ",
                       MsgBoxStyle.Exclamation, "Warning")
                CmbNoMesin.DataSource = Nothing
            Else
                CmbNoMesin.DataSource = dt
                CmbNoMesin.ValueMember = "no_mesin"
                CmbNoMesin.DisplayMember = "no_mesin"
            End If
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, "Error GetModels")
        End Try
    End Sub
    Private Sub GetModels()
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT DISTINCT model FROM setmodel", CONN)
            DS = New DataSet
            DA.Fill(DS, "getmodel")
            Dim dt As DataTable = DS.Tables("getmodel")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data model ",
                       MsgBoxStyle.Exclamation, "Warning")
                CmbModel.DataSource = Nothing
            Else
                CmbModel.DataSource = dt
                CmbModel.ValueMember = "model"
                CmbModel.DisplayMember = "model"
            End If
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, "Error GetModels")
        End Try
    End Sub

    Private Sub GetModelDetails()
        If CmbModel.Text = "System.Data.DataRowView" Then
            Exit Sub
        End If
        Try
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT target,plan,kelipatan,delay,minberat,maxberat FROM setmodel WHERE model='" & CmbModel.Text & "' ", CONN)
            DS = New DataSet
            DA.Fill(DS, "getmodel")
            Dim dt As DataTable = DS.Tables("getmodel")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data detail model ",
                       MsgBoxStyle.Exclamation, "Warning")
            Else
                TxtTarget.Text = CInt(dt.Rows(0).Item("target"))
                TxtPlanning.Text = CInt(dt.Rows(0).Item("plan"))
                TxtKelipatan.Text = CInt(dt.Rows(0).Item("kelipatan"))
                TxtDetik.Text = CInt(dt.Rows(0).Item("delay"))
                TxtMinWeight.Text = FormatNumber(dt.Rows(0).Item("minberat"), 2)
                TxtMaxWeight.Text = FormatNumber(dt.Rows(0).Item("maxberat"), 2)
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GetModels")
        End Try
    End Sub

    Private Sub RBonSuaraTimbang_CheckedChanged(sender As Object, e As EventArgs) Handles RBonSuaraTimbang.CheckedChanged
        If RBonSuaraTimbang.Checked = True Then
            setBelTimbang = "On"
        Else
            setBelTimbang = "Off"
        End If
    End Sub

    Private Sub RBoffSuaraTimbang_CheckedChanged(sender As Object, e As EventArgs) Handles RBoffSuaraTimbang.CheckedChanged
        If RBoffSuaraTimbang.Checked = True Then
            setBelTimbang = "Off"
        Else
            setBelTimbang = "On"
        End If
    End Sub

    Private Sub RBonBel_CheckedChanged(sender As Object, e As EventArgs) Handles RBonBel.CheckedChanged
        If RBonBel.Checked = True Then
            setBelIstirahat = "On"
        Else
            setBelIstirahat = "Off"
        End If
    End Sub

    Private Sub RBoffBel_CheckedChanged(sender As Object, e As EventArgs) Handles RBoffBel.CheckedChanged
        If RBoffBel.Checked = True Then
            setBelIstirahat = "Off"
        Else
            setBelIstirahat = "On"
        End If
    End Sub

    Private Sub GetLines()
        Try
            CmbLine.DataSource = Nothing
            CmbLine.Items.Clear()
            ConnectMySQL()

            DA = New OdbcDataAdapter("SELECT DISTINCT nama_line FROM setline WHERE aktif='Tidak'", CONN)
            DS = New DataSet
            DA.Fill(DS, "getline")
            Dim dt As DataTable = DS.Tables("getline")
            If dt.Rows.Count = 0 Then
                MsgBox("Tidak ada data line ",
                       MsgBoxStyle.Exclamation, "Warning")
                CmbLine.DataSource = Nothing
            Else
                CmbLine.DataSource = dt
                CmbLine.ValueMember = "nama_line"
                CmbLine.DisplayMember = "nama_line"
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Error GetLines")
        End Try
    End Sub
    Sub GetSerialPortNames()
        Try
            ' Show all available COM ports.
            For Each sp As String In My.Computer.Ports.SerialPortNames

                If CmbPort.Items.Count < My.Computer.Ports.SerialPortNames.Count Then
                    CmbPort.Items.Add(sp)
                    CmbPort.Text = CmbPort.Items(0)
                End If

                If CmbPortArduino.Items.Count < My.Computer.Ports.SerialPortNames.Count Then
                    CmbPortArduino.Items.Add(sp)
                    CmbPortArduino.Text = CmbPort.Items(0)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, "GetSerialPortNames()")
        End Try
    End Sub
#End Region
    Private Sub CmbModel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbModel.SelectedIndexChanged
        GetModelDetails()
    End Sub
    Private Sub CmbPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbPort.SelectedIndexChanged
        setComPort = CmbPort.Text
    End Sub
    Private Sub CmbBaudRate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbBaudRate.SelectedIndexChanged
        setBrate = CmbBaudRate.Text
    End Sub

    Private Sub FormSetting_VisibleChanged(sender As Object, e As EventArgs) Handles Me.VisibleChanged
        Reload()
    End Sub

#Region "Arduino"
    Private Sub RBActive_CheckedChanged(sender As Object, e As EventArgs) Handles RBActive.CheckedChanged
        If RBActive.Checked = True Then
            setArduinoAktif = 1
        End If
    End Sub

    Private Sub RBNonActive_CheckedChanged(sender As Object, e As EventArgs) Handles RBNonActive.CheckedChanged
        If RBNonActive.Checked = True Then
            setArduinoAktif = 0
        End If
    End Sub

    Private Sub BtnArduinoConfig_Click(sender As Object, e As EventArgs) Handles BtnArduinoConfig.Click
        UpdateSettinganArduino()
    End Sub

    Private Sub BtnCloseArduinoConfig_Click(sender As Object, e As EventArgs) Handles BtnCloseArduinoConfig.Click
        FormMain.Show()
        Me.Hide()
    End Sub
#End Region


#Region "Font Size"
    Private Sub BtnFontDay_Click(sender As Object, e As EventArgs) Handles BtnFontDay.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontDay.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnFontDate_Click(sender As Object, e As EventArgs) Handles BtnFontDate.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontDate.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnFontTime_Click(sender As Object, e As EventArgs) Handles BtnFontTime.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontTime.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnFontModel_Click(sender As Object, e As EventArgs) Handles BtnFontModel.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontModel.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub
    Private Sub BtnFontTarget_Click(sender As Object, e As EventArgs) Handles BtnFontTarget.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontTarget.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnFontAktual_Click(sender As Object, e As EventArgs) Handles BtnFontAktual.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontAktual.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub
    Private Sub BtnCloseAdjustment_Click(sender As Object, e As EventArgs) Handles BtnCloseAdjustment.Click
        FormMain.Show()
        Me.Hide()
    End Sub

    Private Sub BtnSetAktualTebaru_Click_1(sender As Object, e As EventArgs) Handles BtnSetAktualTebaru.Click
        My.Settings.starttimeFound = TxtAdjustStartTime.Text
        My.Settings.Save()
        UpdateAktualTerbaru(TxtAdjustAktual.Text, setNomorMesin)
        UpdateTargetTerbaru(TxtAdjustTarget.Text, setNomorMesin)
        UpdateStartTimeTerbaru(TxtAdjustStartTime.Text, setNomorMesin)
        MsgBox("Save addjustment , Success!", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnSetToDisplay_Click_1(sender As Object, e As EventArgs) Handles BtnSetToDisplay.Click
        aktual = TxtAdjustAktual.Text
        targetygselalubertambah = TxtAdjustTarget.Text
        WaktuStart = TxtAdjustStartTime.Text
        setToDisplay = True
        MsgBox("Set to Display , Success!", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnFontJudul_Click(sender As Object, e As EventArgs) Handles BtnFontJudul.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontJudul.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub

    Private Sub BtnFontEfiseinsi_Click(sender As Object, e As EventArgs) Handles BtnFontEfiseinsi.Click
        If FontDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            CmbFontEfisiensi.Text = FontDialog1.Font.Name & "," & FontDialog1.Font.Size & "," & FontDialog1.Font.Style
        End If
    End Sub
    Private Sub BtnCloseFontConfig_Click(sender As Object, e As EventArgs) Handles BtnCloseFontConfig.Click
        FormMain.Show()
        Me.Hide()
    End Sub
    Private Sub BtnSaveFontConfig_Click(sender As Object, e As EventArgs) Handles BtnSaveFontConfig.Click
        UpdateFontSize()
    End Sub
    Private Sub UpdateFontSize()
        Try
            ConnectMySQL()

            Dim update As String = "UPDATE `setfont` SET `dayfont`='" & CmbFontDay.Text & "',`datefont`='" & CmbFontDate.Text & "',`timefont`='" & CmbFontTime.Text & "',`modelfont`='" & CmbFontModel.Text & "',`targetfont`='" & CmbFontTarget.Text & "',`aktualfont`='" & CmbFontAktual.Text & "',`judulfont`='" & CmbFontJudul.Text & "',`efisiensifont`='" & CmbFontEfisiensi.Text & "' WHERE id=1"
            CMD = New OdbcCommand(update, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil di simpan", vbInformation, "update")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateFontSize()")
        End Try
    End Sub
#End Region

#Region "Shift"
    Private Sub UpdateShift1Lembur()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setshift SET lembur='" & SetLemburShift1 & "' WHERE namashift='Shift 1'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()

            'MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateShift()")
        End Try
    End Sub
    Private Sub UpdateShift2()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setshift SET status='" & SetAktifShift2 & "' WHERE namashift='Shift 2'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()

            'MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateShift2()")
        End Try
    End Sub
    Private Sub UpdateShift3()
        Try
            ConnectMySQL()

            Dim simpan As String = "UPDATE setshift SET status='" & SetAktifShift3 & "' WHERE namashift='Shift 3'"
            CMD = New OdbcCommand(simpan, CONN)
            CMD.ExecuteNonQuery()

            'MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
            CONN.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error UpdateShift3()")
        End Try
    End Sub
    Private Sub BtnSaveShiftConfig_Click(sender As Object, e As EventArgs) Handles BtnSaveShiftConfig.Click
        ''nothing
    End Sub

    Private Sub BtnCloseShiftConfig_Click(sender As Object, e As EventArgs) Handles BtnCloseShiftConfig.Click
        FormMain.Show()
        Me.Hide()
    End Sub


    Private Sub RBYaLembur_CheckedChanged(sender As Object, e As EventArgs) Handles RBYaLembur.CheckedChanged
        If RBYaLembur.Checked = True Then
            SetLemburShift1 = "Ya"
        Else
            SetLemburShift1 = "Tidak"
        End If
        UpdateShift1Lembur()
    End Sub
    Private Sub RBTidakLembur_CheckedChanged(sender As Object, e As EventArgs) Handles RBTidakLembur.CheckedChanged
        If RBTidakLembur.Checked = True Then
            SetLemburShift1 = "Tidak"
        Else
            If RBYaAktifShift2.Checked = True Then
                MsgBox("Tidak bisa mengaktifkan Shift 2 saat Shift 1 bekerja lembur!")
                RBTidakLembur.Checked = True
                Exit Sub
            End If
            SetLemburShift1 = "Ya"
        End If
        UpdateShift1Lembur()
    End Sub
    Private Sub RBYaAktifShift2_CheckedChanged(sender As Object, e As EventArgs) Handles RBYaAktifShift2.CheckedChanged
        If RBYaAktifShift2.Checked = True Then
            If RBYaLembur.Checked = True Then
                MsgBox("Tidak bisa mengaktifkan Shift 2 saat Shift 1 bekerja lembur!")
                RBTidakAktifShift2.Checked = True
                Exit Sub
            End If
            SetAktifShift2 = "On"
        Else
            SetAktifShift2 = "Off"
        End If
        UpdateShift2()
    End Sub
    Private Sub RBTidakAktifShift2_CheckedChanged(sender As Object, e As EventArgs) Handles RBTidakAktifShift2.CheckedChanged
        If RBTidakAktifShift2.Checked = True Then
            SetAktifShift2 = "Off"
        Else
            SetAktifShift2 = "On"
        End If
        UpdateShift2()
    End Sub

    Private Sub BtnTesSuaraBel_Click(sender As Object, e As EventArgs) Handles BtnTesSuaraBel.Click
        If Lblnamafilesuarabel.Text <> "---" Then
            My.Computer.Audio.Play(Lblnamafilesuarabel.Text, AudioPlayMode.Background)
        End If
    End Sub

    Private Sub BtnTesSuaraTimbangan_Click(sender As Object, e As EventArgs) Handles BtnTesSuaraTimbangan.Click
        If Lblnamafilesuaratimbangan.Text <> "---" Then
            My.Computer.Audio.Play(Lblnamafilesuaratimbangan.Text, AudioPlayMode.Background)
        End If
    End Sub

    Private Sub CmbLine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbLine.SelectedIndexChanged
        GetMachines()
    End Sub

    Private Sub CmbPortArduino_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbPortArduino.SelectedIndexChanged
        setComPortArduino = CmbPortArduino.Text
    End Sub

    Private Sub CmbBaudRateArduino_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbBaudRateArduino.SelectedIndexChanged
        setBaudRateArduino = CmbBaudRateArduino.Text
    End Sub

    Private Sub RBYaAktifShift3_CheckedChanged(sender As Object, e As EventArgs) Handles RBYaAktifShift3.CheckedChanged
        If RBYaAktifShift3.Checked = True Then
            SetAktifShift3 = "On"
        Else
            SetAktifShift3 = "Off"
        End If
        UpdateShift3()
    End Sub
    Private Sub RBTidakAktifShift3_CheckedChanged(sender As Object, e As EventArgs) Handles RBTidakAktifShift3.CheckedChanged
        If RBTidakAktifShift3.Checked = True Then
            SetAktifShift3 = "Off"
        Else
            SetAktifShift3 = "On"
        End If
        UpdateShift3()
    End Sub
#End Region


#Region "Resources"
    Private Sub AddResources()
        Dim sndResource As Byte()
        Try
            sndResource = System.IO.File.ReadAllBytes("C:\MyMedia.wav")
        Catch ex As Exception

        End Try
        Using rw As New ResourceWriter("CarResources.resources")
            rw.AddResource("Media1", sndResource)
        End Using
    End Sub
    'Private Sub PlayFileFromResources()
    '    Dim resoReader As ResourceReader = New ResourceReader("MyMedia.resources")
    '    Dim REResource As Byte()
    '    Dim dEnum As IDictionaryEnumerator = resoReader.GetEnumerator()
    '    While dEnum.MoveNext()
    '        Select Case dEnum.Key
    '            Case "Media1"
    '                REResource = dEnum.Value
    '        End Select
    '    End While
    '    resoReader.Close()
    '    Dim st As IO.Stream = New IO.MemoryStream(REResource)
    '    Dim player As SoundPlayer = New SoundPlayer(st)
    '    player.Play()
    'End Sub



    Private Sub BtnPilihSuaraBel_Click(sender As Object, e As EventArgs) Handles BtnPilihSuaraBel.Click
        OpenFileDialog1.InitialDirectory = startupPath & "wav"
        OpenFileDialog1.Title = "Open an Audio File"
        OpenFileDialog1.Filter = "Audio File|*.wav"
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            suarabellistirahat = OpenFileDialog1.FileName
            Lblnamafilesuarabel.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub BtnPilihSuaraTimbangan_Click(sender As Object, e As EventArgs) Handles BtnPilihSuaraTimbangan.Click
        OpenFileDialog1.InitialDirectory = startupPath & "wav"
        OpenFileDialog1.Title = "Open an Audio File"
        OpenFileDialog1.Filter = "Audio File|*.wav"
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            suaratimbangan = OpenFileDialog1.FileName
            Lblnamafilesuaratimbangan.Text = OpenFileDialog1.FileName
        End If
    End Sub
#End Region


End Class