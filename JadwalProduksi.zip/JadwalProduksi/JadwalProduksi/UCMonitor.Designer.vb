﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UCMonitor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblnomesin = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblhari = New System.Windows.Forms.Label()
        Me.lblmodel = New System.Windows.Forms.Label()
        Me.lbltarget = New System.Windows.Forms.Label()
        Me.lblaktual = New System.Windows.Forms.Label()
        Me.lbltanggal = New System.Windows.Forms.Label()
        Me.lblefisiensi = New System.Windows.Forms.Label()
        Me.lblstatus = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.10425!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.89575!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.lblnomesin, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.lblhari, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblmodel, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lbltarget, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblaktual, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.lbltanggal, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblefisiensi, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblstatus, 2, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(282, 199)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'lblnomesin
        '
        Me.lblnomesin.AutoSize = True
        Me.lblnomesin.BackColor = System.Drawing.Color.LightCoral
        Me.TableLayoutPanel1.SetColumnSpan(Me.lblnomesin, 2)
        Me.lblnomesin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblnomesin.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnomesin.Location = New System.Drawing.Point(4, 1)
        Me.lblnomesin.Name = "lblnomesin"
        Me.lblnomesin.Size = New System.Drawing.Size(140, 43)
        Me.lblnomesin.TabIndex = 0
        Me.lblnomesin.Text = "NomorMesin"
        Me.lblnomesin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 28)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Hari / Tgl"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Silver
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 40)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Model"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Silver
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(4, 115)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 44)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Target"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Silver
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 160)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 38)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Aktual"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblhari
        '
        Me.lblhari.AutoSize = True
        Me.lblhari.BackColor = System.Drawing.Color.Silver
        Me.lblhari.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblhari.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhari.Location = New System.Drawing.Point(73, 45)
        Me.lblhari.Name = "lblhari"
        Me.lblhari.Size = New System.Drawing.Size(71, 28)
        Me.lblhari.TabIndex = 5
        Me.lblhari.Text = "hari"
        Me.lblhari.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblmodel
        '
        Me.lblmodel.AutoSize = True
        Me.lblmodel.BackColor = System.Drawing.Color.Silver
        Me.lblmodel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmodel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmodel.Location = New System.Drawing.Point(73, 74)
        Me.lblmodel.Name = "lblmodel"
        Me.lblmodel.Size = New System.Drawing.Size(71, 40)
        Me.lblmodel.TabIndex = 6
        Me.lblmodel.Text = "model"
        Me.lblmodel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltarget
        '
        Me.lbltarget.AutoSize = True
        Me.lbltarget.BackColor = System.Drawing.Color.Silver
        Me.lbltarget.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltarget.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltarget.Location = New System.Drawing.Point(73, 115)
        Me.lbltarget.Name = "lbltarget"
        Me.lbltarget.Size = New System.Drawing.Size(71, 44)
        Me.lbltarget.TabIndex = 7
        Me.lbltarget.Text = "target"
        Me.lbltarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblaktual
        '
        Me.lblaktual.AutoSize = True
        Me.lblaktual.BackColor = System.Drawing.Color.Silver
        Me.lblaktual.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblaktual.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaktual.Location = New System.Drawing.Point(73, 160)
        Me.lblaktual.Name = "lblaktual"
        Me.lblaktual.Size = New System.Drawing.Size(71, 38)
        Me.lblaktual.TabIndex = 8
        Me.lblaktual.Text = "aktual"
        Me.lblaktual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltanggal
        '
        Me.lbltanggal.AutoSize = True
        Me.lbltanggal.BackColor = System.Drawing.Color.Silver
        Me.lbltanggal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltanggal.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltanggal.Location = New System.Drawing.Point(151, 45)
        Me.lbltanggal.Name = "lbltanggal"
        Me.lbltanggal.Size = New System.Drawing.Size(127, 28)
        Me.lbltanggal.TabIndex = 9
        Me.lbltanggal.Text = "tanggal"
        Me.lbltanggal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblefisiensi
        '
        Me.lblefisiensi.AutoSize = True
        Me.lblefisiensi.BackColor = System.Drawing.Color.ForestGreen
        Me.lblefisiensi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblefisiensi.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblefisiensi.ForeColor = System.Drawing.Color.White
        Me.lblefisiensi.Location = New System.Drawing.Point(151, 74)
        Me.lblefisiensi.Name = "lblefisiensi"
        Me.TableLayoutPanel1.SetRowSpan(Me.lblefisiensi, 3)
        Me.lblefisiensi.Size = New System.Drawing.Size(127, 124)
        Me.lblefisiensi.TabIndex = 10
        Me.lblefisiensi.Text = "Efisiensi"
        Me.lblefisiensi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblstatus
        '
        Me.lblstatus.AutoSize = True
        Me.lblstatus.BackColor = System.Drawing.Color.LightCoral
        Me.lblstatus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblstatus.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus.Location = New System.Drawing.Point(151, 1)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(127, 43)
        Me.lblstatus.TabIndex = 11
        Me.lblstatus.Text = "status"
        Me.lblstatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 3000
        '
        'UCMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "UCMonitor"
        Me.Size = New System.Drawing.Size(282, 199)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents lblnomesin As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblhari As Label
    Friend WithEvents lblmodel As Label
    Friend WithEvents lbltarget As Label
    Friend WithEvents lblaktual As Label
    Friend WithEvents lbltanggal As Label
    Friend WithEvents lblefisiensi As Label
    Friend WithEvents lblstatus As Label
    Friend WithEvents Timer1 As Timer
End Class
